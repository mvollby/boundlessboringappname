export const T = {
  // Colors
  bg:         "#F5F3FF",
  card:       "#FFFFFF",
  dark:       "#1E1B4B",
  primary:    "#7C3AED",
  primaryLt:  "#8B5CF6",
  pink:       "#EC4899",
  teal:       "#0D9488",
  amber:      "#F59E0B",
  muted:      "#6B7280",
  border:     "#E9E4FF",
  success:    "#10B981",
  danger:     "#EF4444",

  // Gradients
  grad:       "linear-gradient(135deg, #7C3AED 0%, #EC4899 100%)",
  gradSoft:   "linear-gradient(135deg, #EDE9FE 0%, #FCE7F3 100%)",
  gradDark:   "linear-gradient(135deg, #1E1B4B 0%, #4C1D95 60%, #7C3AED 100%)",
  gradHeader: "linear-gradient(135deg, #1E1B4B 0%, #3B1D8B 50%, #6D28D9 100%)",

  // Discipline colors
  disc: {
    Runner:     { bg: "#D1FAE5", color: "#065F46", grad: "linear-gradient(135deg,#059669,#10B981)" },
    Cyclist:    { bg: "#DBEAFE", color: "#1E40AF", grad: "linear-gradient(135deg,#2563EB,#60A5FA)" },
    Multisport: { bg: "#FEF3C7", color: "#92400E", grad: "linear-gradient(135deg,#D97706,#F59E0B)" },
  },

  // Typography
  fontBase: "'Inter', -apple-system, sans-serif",

  // Shadows
  shadow:   "0 4px 24px rgba(124,58,237,0.10)",
  shadowLg: "0 8px 40px rgba(124,58,237,0.18)",
  shadowSm: "0 2px 10px rgba(0,0,0,0.06)",

  // Radii
  r:  "12px",
  rL: "20px",
  rXL:"28px",
  rPill: "999px",
};
