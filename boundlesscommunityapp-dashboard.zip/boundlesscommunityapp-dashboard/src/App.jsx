import { useState, useEffect } from "react";
import { authStorage, profileStorage, eventStorage, coachStorage, storage } from "./utils/storage";
import { runSeed, ADMIN_ID } from "./utils/seed";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfileSetup from "./pages/ProfileSetup";
import MainApp from "./pages/MainApp";

export default function App() {
  const [session,    setSession]    = useState(null);
  const [hasProfile, setHasProfile] = useState(false);
  const [authView,   setAuthView]   = useState("login");
  const [ready,      setReady]      = useState(false);

  useEffect(() => {
    // One-time wipe (bump version to force fresh wipe)
    if (!storage.get("wipe_v6_done")) {
      // Wipe all user profiles
      authStorage.getUsers().forEach((u) => storage.remove("profile_" + u.id));
      // Wipe registered user accounts (non-admin) so login screen is clean
      authStorage.saveUsers([]);
      // Wipe conversations, forum data, memberships
      Object.keys(localStorage)
        .filter((k) =>
          k.startsWith("boundless_forum_") ||
          k.startsWith("boundless_conversations") ||
          k.startsWith("boundless_messages")
        )
        .forEach((k) => localStorage.removeItem(k));
      // Wipe events and coaches so they get re-seeded
      storage.remove("events");
      storage.remove("coaches");
      storage.remove("coaches_seeded_v1");
      storage.remove("events_seeded_v1");
      // Clear session — return to login screen
      authStorage.clearSession();
      storage.set("wipe_v6_done", true);
    }

    // Always seed admin + data (idempotent)
    runSeed();

    const saved = authStorage.getSession();
    if (saved) {
      setSession(saved);
      setHasProfile(!!profileStorage.get(saved.id));
    }
    setReady(true);
  }, []);

  const handleLogin = (user) => {
    setSession(user);
    setHasProfile(!!profileStorage.get(user.id));
  };

  const handleProfileComplete = (profileData) => {
    profileStorage.set(session.id, profileData);
    setHasProfile(true);
  };

  const handleLogout = () => {
    authStorage.clearSession();
    setSession(null);
    setHasProfile(false);
    setAuthView("login");
  };

  if (!ready) return null;

  if (!session) {
    return authView === "login"
      ? <LoginPage onLogin={handleLogin} onGoRegister={() => setAuthView("register")} />
      : <RegisterPage onLogin={handleLogin} onGoLogin={() => setAuthView("login")} />;
  }

  // Admin has a complete profile seeded — skip setup
  if (!hasProfile && session.id !== ADMIN_ID) {
    return <ProfileSetup user={session} onComplete={handleProfileComplete} />;
  }

  return <MainApp user={session} onLogout={handleLogout} />;
}
