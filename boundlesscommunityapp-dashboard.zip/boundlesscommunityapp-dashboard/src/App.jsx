import { useState, useEffect } from "react";
import { authStorage, profileStorage, storage } from "./utils/storage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfileSetup from "./pages/ProfileSetup";
import MainApp from "./pages/MainApp";

export default function App() {
  const [session, setSession] = useState(null);
  const [hasProfile, setHasProfile] = useState(false);
  const [authView, setAuthView] = useState("login");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // One-time wipe: if "wipe_v3" flag not set, clear all profiles/forums/convos
    if (!storage.get("wipe_v3_done")) {
      authStorage.getUsers().forEach((u) => storage.remove("profile_" + u.id));
      Object.keys(localStorage)
        .filter((k) => k.startsWith("boundless_forum_") || k.startsWith("boundless_conversations") || k.startsWith("boundless_messages"))
        .forEach((k) => localStorage.removeItem(k));
      authStorage.clearSession();
      storage.set("wipe_v3_done", true);
      setReady(true);
      return;
    }

    const saved = authStorage.getSession();
    if (saved) {
      setSession(saved);
      setHasProfile(!!profileStorage.get(saved.id));
    }
    setReady(true);
  }, []);

  const handleLogin = (user) => {
    setSession(user);
    setHasProfile(!!profileStorage.get(user.id));
  };

  const handleProfileComplete = (profileData) => {
    profileStorage.set(session.id, profileData);
    setHasProfile(true);
  };

  const handleLogout = () => {
    authStorage.clearSession();
    setSession(null);
    setHasProfile(false);
    setAuthView("login");
  };

  if (!ready) return null;

  if (!session) {
    return authView === "login"
      ? <LoginPage onLogin={handleLogin} onGoRegister={() => setAuthView("register")} />
      : <RegisterPage onLogin={handleLogin} onGoLogin={() => setAuthView("login")} />;
  }

  if (!hasProfile) {
    return <ProfileSetup user={session} onComplete={handleProfileComplete} />;
  }

  return <MainApp user={session} onLogout={handleLogout} />;
}
