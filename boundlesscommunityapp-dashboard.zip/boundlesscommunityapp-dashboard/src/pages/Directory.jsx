import { useState } from "react";
import { distanceMiles } from "../utils/geocoding";
import { messageStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";

function canSee(myDisc, theirDisc) {
  if (myDisc === "Multisport") return true;
  return myDisc === theirDisc;
}

function matchScore(me, them) {
  let score = 0;
  const myEvents = new Set(me.events || []);
  (them.events || []).forEach((e) => { if (myEvents.has(e)) score += 30; });
  if (me.lat && them.lat) {
    const miles = distanceMiles(me.lat, me.lng, them.lat, them.lng);
    if (miles < 25)  score += 40;
    else if (miles < 100) score += 20;
    else if (miles < 300) score += 10;
  }
  return score;
}

export default function Directory({ myProfile, allProfiles, currentUser }) {
  const [selected,  setSelected]  = useState(null);
  const [sent,      setSent]      = useState(new Set());
  const [confirmId, setConfirmId] = useState(null);
  const [search,    setSearch]    = useState("");

  const visible = allProfiles
    .filter((p) => p.userId !== currentUser.id && canSee(myProfile.discipline, p.discipline))
    .map((p) => {
      const miles = (myProfile.lat && p.lat)
        ? distanceMiles(myProfile.lat, myProfile.lng, p.lat, p.lng) : Infinity;
      return { ...p, _miles: miles, _score: matchScore(myProfile, p) };
    })
    .filter((p) => {
      const q = search.toLowerCase();
      return !q || p.name.toLowerCase().includes(q) || (p.location || "").toLowerCase().includes(q) || (p.discipline || "").toLowerCase().includes(q);
    })
    .sort((a, b) => a._miles !== Infinity || b._miles !== Infinity ? a._miles - b._miles : b._score - a._score);

  const handleConnect = (profile) => {
    messageStorage.send({
      fromUserId: currentUser.id,
      toUserId:   profile.userId,
      fromName:   currentUser.name,
      fromEmail:  currentUser.email,
      fromPhone:  myProfile.phone || "",
      preview: `Hey! I'd love to connect. Reach me at ${currentUser.email}${myProfile.phone ? " or " + myProfile.phone : ""}.`,
    });
    setSent((s) => new Set([...s, profile.userId]));
    setConfirmId(null);
    setSelected(null);
  };

  return (
    <div style={S.root}>
      {/* Header */}
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Athlete Directory</h2>
          <p style={S.sub}>
            {myProfile.discipline === "Multisport"
              ? "All athletes · sorted nearest first"
              : `${myProfile.discipline}s near you · sorted by distance`}
          </p>
        </div>
        <div style={S.searchWrap}>
          <Icon.Search style={{ width: 16, height: 16, color: T.muted, flexShrink: 0 }} />
          <input style={S.searchInput} placeholder="Search athletes…"
            value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      {visible.length === 0 && (
        <div style={S.empty}>
          <Icon.Users style={{ width: 40, height: 40, color: T.border, margin: "0 auto 16px", display: "block" }} />
          <p style={{ color: T.muted, fontSize: 15 }}>No athletes found yet.</p>
        </div>
      )}

      <div style={S.grid}>
        {visible.map((p) => <AthleteCard key={p.userId} p={p} sent={sent} onSelect={setSelected} onConfirm={setConfirmId} />)}
      </div>

      {/* Profile modal */}
      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={S.modalTop}>
            <Avatar profile={selected} size={88} />
            <div style={{ textAlign: "center" }}>
              <h3 style={S.modalName}>{selected.name}</h3>
              <DiscBadge d={selected.discipline} />
            </div>
          </div>
          <div style={S.modalDetails}>
            {selected.location && (
              <div style={S.detailRow}>
                <Icon.MapPin style={{ width: 15, height: 15, color: T.muted, flexShrink: 0 }} />
                <span>{selected.location}
                  {selected._miles !== Infinity && <span style={S.milesTag}> · {Math.round(selected._miles)} mi away</span>}
                </span>
              </div>
            )}
            {selected.coach && (
              <div style={S.detailRow}>
                <Icon.Star style={{ width: 13, height: 13, color: T.amber }} />
                <span>Coach: {selected.coach}</span>
              </div>
            )}
            {selected.events?.length > 0 && (
              <div style={S.detailRow}>
                <Icon.Flag style={{ width: 14, height: 14, color: T.primary }} />
                <span>{selected.events.join(", ")}</span>
              </div>
            )}
          </div>
          {selected.bio && <p style={S.bio}>{selected.bio}</p>}
          <button
            style={sent.has(selected.userId) ? S.btnSent : S.btnPri}
            disabled={sent.has(selected.userId)}
            onClick={() => setConfirmId(selected.userId)}>
            {sent.has(selected.userId)
              ? <><Icon.Check style={{ width: 15, height: 15 }} /> Request Sent</>
              : `Connect with ${selected.name.split(" ")[0]}`}
          </button>
        </Modal>
      )}

      {/* Confirm */}
      {confirmId && (() => {
        const target = visible.find((p) => p.userId === confirmId);
        return (
          <Modal onClose={() => setConfirmId(null)} narrow>
            <div style={{ textAlign: "center", padding: "8px 0 16px" }}>
              <Avatar profile={target} size={60} style={{ margin: "0 auto 12px" }} />
              <p style={S.confirmText}>
                Send your contact info to <strong>{target?.name}</strong>?
              </p>
              <p style={S.confirmSub}>They'll receive your email{myProfile.phone ? " & phone number" : ""} in their inbox.</p>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button style={S.btnSec} onClick={() => setConfirmId(null)}>Cancel</button>
              <button style={{ ...S.btnPri, flex: 1 }} onClick={() => handleConnect(target)}>Yes, Connect</button>
            </div>
          </Modal>
        );
      })()}
    </div>
  );
}

function AthleteCard({ p, sent, onSelect, onConfirm }) {
  const miles = p._miles !== Infinity ? Math.round(p._miles) : null;
  return (
    <div style={S.card} onClick={() => onSelect(p)}>
      <Avatar profile={p} size={58} style={{ marginBottom: 12 }} />
      <div style={S.cardName}>{p.name}</div>
      <DiscBadge d={p.discipline} />
      {p.location && (
        <div style={S.cardMeta}>
          <Icon.MapPin style={{ width: 12, height: 12, flexShrink: 0 }} />
          <span>{p.location}</span>
        </div>
      )}
      {miles !== null && (
        <div style={S.milesBadge}>{miles} mi away</div>
      )}
      {p.events?.length > 0 && (
        <div style={S.cardMeta}>
          <Icon.Flag style={{ width: 12, height: 12, flexShrink: 0, color: T.primary }} />
          <span style={{ fontSize: 11 }}>{p.events.slice(0, 2).join(", ")}{p.events.length > 2 ? "…" : ""}</span>
        </div>
      )}
      <button
        style={{ ...S.btnConnect, ...(sent.has(p.userId) ? S.btnSentSm : {}) }}
        disabled={sent.has(p.userId)}
        onClick={(e) => { e.stopPropagation(); onConfirm(p.userId); }}>
        {sent.has(p.userId) ? "Sent" : "Connect"}
      </button>
    </div>
  );
}

function Avatar({ profile, size, style }) {
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const d = T.disc[profile.discipline] || { bg: "#EDE9FE", color: T.primary };
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt={profile.name} style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover", border: `3px solid ${T.border}`, display: "block", ...style }} />
    : <div style={{ width: size, height: size, borderRadius: "50%", background: d.grad || d.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.32, fontWeight: 800, color: "#fff", flexShrink: 0, ...style }}>{initials}</div>;
}

function DiscBadge({ d }) {
  const c = T.disc[d] || { bg: "#EDE9FE", color: T.primary };
  return <span style={{ display: "inline-block", padding: "3px 10px", borderRadius: T.rPill, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color, marginBottom: 8 }}>{d}</span>;
}

function Modal({ children, onClose, narrow }) {
  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={{ ...S.modal, maxWidth: narrow ? 360 : 420 }} onClick={(e) => e.stopPropagation()}>
        <button style={S.closeBtn} onClick={onClose}><Icon.X style={{ width: 18, height: 18 }} /></button>
        {children}
      </div>
    </div>
  );
}

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28, flexWrap: "wrap", gap: 14 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  searchWrap: { display: "flex", alignItems: "center", gap: 8, background: "#fff", border: `1.5px solid ${T.border}`, borderRadius: T.rPill, padding: "10px 16px", minWidth: 220 },
  searchInput: { border: "none", outline: "none", fontSize: 14, background: "transparent", color: T.dark, width: "100%" },
  empty: { textAlign: "center", padding: "60px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(210px,1fr))", gap: 16 },
  card: { background: "#fff", borderRadius: T.rXL, padding: "24px 20px 20px", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", boxShadow: T.shadowSm, cursor: "pointer", border: `1.5px solid ${T.border}`, transition: "box-shadow 0.15s, transform 0.15s" },
  cardName: { fontSize: 15, fontWeight: 700, color: T.dark, marginBottom: 6 },
  cardMeta: { display: "flex", alignItems: "center", gap: 5, color: T.muted, fontSize: 12, marginBottom: 4 },
  milesBadge: { fontSize: 11, fontWeight: 600, color: T.primary, background: "#EDE9FE", borderRadius: T.rPill, padding: "2px 10px", marginBottom: 6 },
  btnConnect: { marginTop: 12, width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "10px", fontSize: 13, fontWeight: 700, cursor: "pointer", boxShadow: "0 3px 12px rgba(124,58,237,0.3)" },
  btnSentSm: { background: T.disc.Runner.bg, color: T.disc.Runner.color, boxShadow: "none" },

  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 24 },
  modal: { background: "#fff", borderRadius: T.rXL, padding: "36px 32px 32px", width: "100%", position: "relative", boxShadow: T.shadowLg },
  closeBtn: { position: "absolute", top: 14, right: 14, background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4, borderRadius: 8 },
  modalTop: { display: "flex", flexDirection: "column", alignItems: "center", gap: 12, marginBottom: 20 },
  modalName: { fontSize: 22, fontWeight: 800, margin: "0 0 6px", color: T.dark },
  modalDetails: { display: "flex", flexDirection: "column", gap: 8, background: T.bg, borderRadius: T.r, padding: "14px 16px", marginBottom: 16 },
  detailRow: { display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: T.dark },
  milesTag: { color: T.primary, fontWeight: 600 },
  bio: { fontSize: 14, color: T.muted, lineHeight: 1.6, marginBottom: 20, padding: "12px 14px", background: T.bg, borderRadius: T.r },
  confirmText: { fontSize: 16, fontWeight: 700, color: T.dark, margin: "0 0 6px" },
  confirmSub: { fontSize: 13, color: T.muted, margin: "0 0 20px" },

  btnPri: { width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "14px", fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.3)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 },
  btnSent: { width: "100%", background: T.disc.Runner.bg, color: T.disc.Runner.color, border: "none", borderRadius: T.r, padding: "14px", fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 },
  btnSec: { flex: 1, background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
};
