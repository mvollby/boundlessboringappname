import { useState, useEffect } from "react";
import { forumStorage, conversationStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";

export default function ForumView({ event, myProfile, currentUser, allProfiles, onClose, onDMRequest }) {
  const [posts,       setPosts]       = useState([]);
  const [activePost,  setActivePost]  = useState(null); // post detail view
  const [showCompose, setShowCompose] = useState(false);
  const [viewed,      setViewed]      = useState(null); // profile mini-modal
  const [newTitle,    setNewTitle]    = useState("");
  const [newBody,     setNewBody]     = useState("");
  const [commentText, setCommentText] = useState("");

  const eventKey = event.replace(/\s+/g, "_").toLowerCase();

  const reload = () => {
    const fresh = forumStorage.getPosts(eventKey);
    setPosts(fresh);
    if (activePost) setActivePost(fresh.find((p) => p.id === activePost.id) || null);
  };

  useEffect(() => { reload(); }, [eventKey]);

  // ── Post actions ──────────────────────────────────────────────────────────────
  const handleSubmitPost = () => {
    if (!newTitle.trim()) return;
    forumStorage.addPost(eventKey, {
      userId:   currentUser.id,
      userName: currentUser.name,
      photoUrl: myProfile.photoUrl || null,
      title:    newTitle.trim(),
      body:     newBody.trim(),
    });
    setNewTitle(""); setNewBody(""); setShowCompose(false);
    reload();
  };

  const handleVotePost = (postId, type) => {
    forumStorage.votePost(eventKey, postId, currentUser.id, type);
    reload();
  };

  // ── Comment actions ───────────────────────────────────────────────────────────
  const handleSubmitComment = (postId) => {
    if (!commentText.trim()) return;
    forumStorage.addComment(eventKey, postId, {
      userId:   currentUser.id,
      userName: currentUser.name,
      photoUrl: myProfile.photoUrl || null,
      text:     commentText.trim(),
    });
    setCommentText("");
    reload();
  };

  const handleVoteComment = (postId, commentId, type) => {
    forumStorage.voteComment(eventKey, postId, commentId, currentUser.id, type);
    reload();
  };

  // ── DM flow ───────────────────────────────────────────────────────────────────
  const handleDM = (profile) => {
    const existing = conversationStorage.existing(currentUser.id, profile.userId);
    if (existing) { onDMRequest(existing, profile); return; }
    const conv = conversationStorage.create({
      initiatorId:    currentUser.id,
      recipientId:    profile.userId,
      initiatorName:  currentUser.name,
      initiatorEmail: currentUser.email,
      note: `Hey ${profile.name.split(" ")[0]}! I saw you in the ${event} forum — I'd love to connect!`,
    });
    onDMRequest(conv, profile);
    setViewed(null);
  };

  const dc = T.disc[myProfile.discipline] || T.disc.Runner;

  // ── Post detail view ──────────────────────────────────────────────────────────
  if (activePost) {
    const post = posts.find((p) => p.id === activePost.id) || activePost;
    const myVote = post.upvotes.includes(currentUser.id) ? "up" : post.downvotes.includes(currentUser.id) ? "down" : null;
    const score  = post.upvotes.length - post.downvotes.length;
    const poster = allProfiles.find((p) => p.userId === post.userId);
    return (
      <div style={S.root}>
        {/* Header */}
        <div style={S.header}>
          <div style={S.headerLeft}>
            <button style={S.exitBtn} onClick={() => setActivePost(null)}>
              <Icon.ChevronRight style={{ width: 16, height: 16, transform: "rotate(180deg)" }} /> Back to Posts
            </button>
            <div style={{ ...S.strip, background: dc.grad }} />
            <div>
              <p style={S.forumLabel}>Event Forum</p>
              <h2 style={S.forumTitle}>{event}</h2>
            </div>
          </div>
          <button style={S.exitBtn} onClick={onClose}>Exit Forum</button>
        </div>

        {/* Post detail */}
        <div style={S.detailBody}>
          {/* Vote + title row */}
          <div style={S.postDetailCard}>
            <div style={S.voteCol}>
              <VoteBtn type="up" active={myVote === "up"} onClick={() => handleVotePost(post.id, myVote === "up" ? null : "up")} />
              <span style={{ ...S.score, color: score > 0 ? T.primary : score < 0 ? T.danger : T.muted }}>{score}</span>
              <VoteBtn type="down" active={myVote === "down"} onClick={() => handleVotePost(post.id, myVote === "down" ? null : "down")} />
            </div>
            <div style={S.postDetailContent}>
              <div style={S.postDetailMeta}>
                <PostAvatar name={post.userName} photoUrl={post.photoUrl} size={28}
                  onClick={() => post.userId !== currentUser.id && setViewed(poster || { userId: post.userId, name: post.userName, photoUrl: post.photoUrl })} />
                <span style={S.byLine}>
                  <span style={post.userId !== currentUser.id ? S.nameLink : {}} onClick={() => post.userId !== currentUser.id && setViewed(poster || { userId: post.userId, name: post.userName, photoUrl: post.photoUrl })}>
                    {post.userId === currentUser.id ? "You" : post.userName}
                  </span>
                  <span style={S.timeDot}>·</span>
                  <span style={S.timeSmall}>{timeAgo(post.ts)}</span>
                </span>
              </div>
              <h3 style={S.postDetailTitle}>{post.title}</h3>
              {post.body && <p style={S.postDetailBody}>{post.body}</p>}
            </div>
          </div>

          {/* Comments */}
          <div style={S.commentsSection}>
            <p style={S.commentsLabel}>{post.comments.length} comment{post.comments.length !== 1 ? "s" : ""}</p>

            {/* Comment input */}
            <div style={S.commentCompose}>
              <PostAvatar name={currentUser.name} photoUrl={myProfile.photoUrl} size={32} />
              <div style={{ flex: 1 }}>
                <textarea
                  style={S.commentInput}
                  placeholder="Add a comment…"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  rows={2}
                />
                <button style={{ ...S.btnSm, opacity: !commentText.trim() ? 0.5 : 1 }}
                  onClick={() => handleSubmitComment(post.id)} disabled={!commentText.trim()}>
                  Comment
                </button>
              </div>
            </div>

            {/* Comment list */}
            {post.comments.length === 0 && <p style={{ color: T.muted, fontSize: 13, textAlign: "center", padding: "20px 0" }}>No comments yet — be the first!</p>}
            {post.comments.map((c) => {
              const cScore  = c.upvotes.length - c.downvotes.length;
              const cMyVote = c.upvotes.includes(currentUser.id) ? "up" : c.downvotes.includes(currentUser.id) ? "down" : null;
              const cPoster = allProfiles.find((p) => p.userId === c.userId);
              return (
                <div key={c.id} style={S.commentCard}>
                  <div style={S.commentLeft}>
                    <PostAvatar name={c.userName} photoUrl={c.photoUrl} size={32}
                      onClick={() => c.userId !== currentUser.id && setViewed(cPoster || { userId: c.userId, name: c.userName, photoUrl: c.photoUrl })} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <span style={c.userId !== currentUser.id ? S.nameLink : S.byLine}
                        onClick={() => c.userId !== currentUser.id && setViewed(cPoster || { userId: c.userId, name: c.userName, photoUrl: c.photoUrl })}>
                        {c.userId === currentUser.id ? "You" : c.userName}
                      </span>
                      <span style={S.timeSmall}>{timeAgo(c.ts)}</span>
                    </div>
                    <p style={S.commentText}>{c.text}</p>
                    <div style={S.commentVoteRow}>
                      <VoteBtn type="up" active={cMyVote === "up"} small onClick={() => handleVoteComment(post.id, c.id, cMyVote === "up" ? null : "up")} />
                      <span style={{ ...S.scoreSmall, color: cScore > 0 ? T.primary : cScore < 0 ? T.danger : T.muted }}>{cScore}</span>
                      <VoteBtn type="down" active={cMyVote === "down"} small onClick={() => handleVoteComment(post.id, c.id, cMyVote === "down" ? null : "down")} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Profile modal */}
        {viewed && <ProfileModal viewed={viewed} onClose={() => setViewed(null)} onDM={handleDM} />}
      </div>
    );
  }

  // ── Post list view ────────────────────────────────────────────────────────────
  const sorted = [...posts].sort((a, b) => (b.upvotes.length - b.downvotes.length) - (a.upvotes.length - a.downvotes.length));

  return (
    <div style={S.root}>
      {/* Header */}
      <div style={S.header}>
        <div style={S.headerLeft}>
          <button style={S.exitBtn} onClick={onClose}>
            <Icon.ChevronRight style={{ width: 16, height: 16, transform: "rotate(180deg)" }} /> Exit Forum
          </button>
          <div style={{ ...S.strip, background: dc.grad }} />
          <div>
            <p style={S.forumLabel}>Event Forum</p>
            <h2 style={S.forumTitle}>{event}</h2>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={S.postCount}>{posts.length} post{posts.length !== 1 ? "s" : ""}</span>
          <button style={S.newPostBtn} onClick={() => setShowCompose((v) => !v)}>
            + New Post
          </button>
        </div>
      </div>

      {/* New post form */}
      {showCompose && (
        <div style={S.composeCard}>
          <h4 style={S.composeTitle}>Create a Post</h4>
          <input
            style={S.titleInput}
            placeholder="Post title…"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            maxLength={120}
          />
          <textarea
            style={S.bodyInput}
            placeholder="Description (optional)…"
            value={newBody}
            onChange={(e) => setNewBody(e.target.value)}
            rows={3}
          />
          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <button style={S.btnCancel} onClick={() => { setShowCompose(false); setNewTitle(""); setNewBody(""); }}>Cancel</button>
            <button style={{ ...S.btnPost, opacity: !newTitle.trim() ? 0.5 : 1 }}
              onClick={handleSubmitPost} disabled={!newTitle.trim()}>Post</button>
          </div>
        </div>
      )}

      {/* Post feed */}
      <div style={S.feed}>
        {sorted.length === 0 && (
          <div style={S.emptyForum}>
            <Icon.Flag style={{ width: 36, height: 36, color: T.border, display: "block", margin: "0 auto 12px" }} />
            <p style={{ color: T.muted }}>Be the first to post in this forum!</p>
            <button style={S.newPostBtn} onClick={() => setShowCompose(true)}>Create a Post</button>
          </div>
        )}
        {sorted.map((post) => {
          const score  = post.upvotes.length - post.downvotes.length;
          const myVote = post.upvotes.includes(currentUser.id) ? "up" : post.downvotes.includes(currentUser.id) ? "down" : null;
          const poster = allProfiles.find((p) => p.userId === post.userId);
          return (
            <div key={post.id} style={S.postCard}>
              {/* Vote column */}
              <div style={S.voteCol}>
                <VoteBtn type="up" active={myVote === "up"} onClick={() => handleVotePost(post.id, myVote === "up" ? null : "up")} />
                <span style={{ ...S.score, color: score > 0 ? T.primary : score < 0 ? T.danger : T.muted }}>{score}</span>
                <VoteBtn type="down" active={myVote === "down"} onClick={() => handleVotePost(post.id, myVote === "down" ? null : "down")} />
              </div>
              {/* Content */}
              <div style={S.postContent} onClick={() => setActivePost(post)}>
                <div style={S.postMeta}>
                  <PostAvatar name={post.userName} photoUrl={post.photoUrl} size={22}
                    onClick={(e) => { e.stopPropagation(); post.userId !== currentUser.id && setViewed(poster || { userId: post.userId, name: post.userName, photoUrl: post.photoUrl }); }} />
                  <span style={post.userId !== currentUser.id ? S.nameLink : S.postAuthor}
                    onClick={(e) => { e.stopPropagation(); post.userId !== currentUser.id && setViewed(poster || { userId: post.userId, name: post.userName, photoUrl: post.photoUrl }); }}>
                    {post.userId === currentUser.id ? "You" : post.userName}
                  </span>
                  <span style={S.timeDot}>·</span>
                  <span style={S.timeSmall}>{timeAgo(post.ts)}</span>
                </div>
                <h3 style={S.postTitle}>{post.title}</h3>
                {post.body && <p style={S.postBodyPreview}>{post.body.length > 120 ? post.body.slice(0, 120) + "…" : post.body}</p>}
                <div style={S.postFooter}>
                  <span style={S.commentCount}>
                    <Icon.Users style={{ width: 13, height: 13 }} /> {post.comments.length} comment{post.comments.length !== 1 ? "s" : ""}
                  </span>
                  <span style={S.readMore}>Read more →</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Profile modal */}
      {viewed && <ProfileModal viewed={viewed} onClose={() => setViewed(null)} onDM={handleDM} />}
    </div>
  );
}

// ── Shared sub-components ────────────────────────────────────────────────────

function VoteBtn({ type, active, onClick, small }) {
  const sz = small ? 14 : 18;
  return (
    <button style={{ ...S.voteBtn, color: active ? (type === "up" ? T.primary : T.danger) : T.muted, width: sz + 10, height: sz + 10 }} onClick={(e) => { e.stopPropagation(); onClick(); }}>
      {type === "up"
        ? <svg width={sz} height={sz} viewBox="0 0 20 20" fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2"><path d="M10 3L18 15H2L10 3Z" strokeLinejoin="round" /></svg>
        : <svg width={sz} height={sz} viewBox="0 0 20 20" fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2"><path d="M10 17L2 5H18L10 17Z" strokeLinejoin="round" /></svg>
      }
    </button>
  );
}

function PostAvatar({ name, photoUrl, size = 36, onClick, style }) {
  const initials = name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return photoUrl
    ? <img src={photoUrl} alt="" onClick={onClick} style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover", flexShrink: 0, border: `2px solid ${T.border}`, cursor: onClick ? "pointer" : "default", ...style }} />
    : <div onClick={onClick} style={{ width: size, height: size, borderRadius: "50%", background: T.grad, display: "flex", alignItems: "center", justifyContent: "center", fontSize: Math.max(9, size * 0.3), fontWeight: 800, color: "#fff", flexShrink: 0, cursor: onClick ? "pointer" : "default", ...style }}>{initials}</div>;
}

function ProfileModal({ viewed, onClose, onDM }) {
  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={S.miniModal} onClick={(e) => e.stopPropagation()}>
        <button style={S.closeBtn} onClick={onClose}><Icon.X style={{ width: 16, height: 16 }} /></button>
        <PostAvatar name={viewed.name} photoUrl={viewed.photoUrl} size={64} style={{ margin: "0 auto 12px", display: "block" }} />
        <h3 style={S.viewedName}>{viewed.name}</h3>
        {viewed.discipline && (
          <span style={{ ...S.discPill, background: (T.disc[viewed.discipline]||T.disc.Runner).bg, color: (T.disc[viewed.discipline]||T.disc.Runner).color }}>
            {viewed.discipline}
          </span>
        )}
        {viewed.location && <p style={S.viewedMeta}><Icon.MapPin style={{ width: 13, height: 13 }} /> {viewed.location}</p>}
        {viewed.bio && <p style={S.viewedBio}>{viewed.bio}</p>}
        <button style={S.btnDM} onClick={() => onDM(viewed)}>
          <Icon.Mail style={{ width: 14, height: 14 }} /> Send Message
        </button>
      </div>
    </div>
  );
}

function timeAgo(ts) {
  const diff = (Date.now() - new Date(ts)) / 1000;
  if (diff < 60)    return "just now";
  if (diff < 3600)  return Math.floor(diff / 60) + "m ago";
  if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
  return new Date(ts).toLocaleDateString();
}

const S = {
  root: { display: "flex", flexDirection: "column", minHeight: "calc(100vh - 140px)", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm, border: `1.5px solid ${T.border}`, overflow: "hidden" },

  header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 24px", borderBottom: `1.5px solid ${T.border}`, gap: 16, flexShrink: 0 },
  headerLeft: { display: "flex", alignItems: "center", gap: 12 },
  strip: { width: 4, height: 34, borderRadius: 4 },
  exitBtn: { display: "flex", alignItems: "center", gap: 6, background: T.bg, border: `1.5px solid ${T.border}`, borderRadius: T.rPill, padding: "7px 14px", fontSize: 13, fontWeight: 600, color: T.dark, cursor: "pointer" },
  forumLabel: { fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: T.muted, margin: "0 0 2px" },
  forumTitle: { fontSize: 16, fontWeight: 800, color: T.dark, margin: 0 },
  postCount: { fontSize: 13, color: T.muted },
  newPostBtn: { display: "flex", alignItems: "center", background: T.grad, color: "#fff", border: "none", borderRadius: T.rPill, padding: "8px 16px", fontSize: 13, fontWeight: 700, cursor: "pointer" },

  composeCard: { margin: "0 24px 0", padding: "20px 24px", borderBottom: `1.5px solid ${T.border}`, background: T.bg },
  composeTitle: { fontSize: 15, fontWeight: 800, color: T.dark, margin: "0 0 12px" },
  titleInput: { width: "100%", padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 15, fontWeight: 600, outline: "none", background: "#fff", fontFamily: "inherit", boxSizing: "border-box", color: T.dark, marginBottom: 10 },
  bodyInput: { width: "100%", padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: "#fff", fontFamily: "inherit", boxSizing: "border-box", color: T.dark, resize: "vertical", marginBottom: 12 },
  btnCancel: { padding: "8px 18px", borderRadius: T.r, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer", color: T.muted },
  btnPost: { padding: "8px 24px", borderRadius: T.r, border: "none", background: T.grad, color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer" },

  feed: { flex: 1, overflowY: "auto", padding: "0 0 24px" },
  emptyForum: { textAlign: "center", padding: "60px 20px", color: T.muted },

  postCard: { display: "flex", gap: 12, padding: "16px 24px", borderBottom: `1px solid ${T.border}`, cursor: "default", transition: "background 0.1s" },
  voteCol: { display: "flex", flexDirection: "column", alignItems: "center", gap: 2, flexShrink: 0 },
  voteBtn: { background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 4, padding: 2, transition: "color 0.1s" },
  score: { fontSize: 13, fontWeight: 800, minWidth: 20, textAlign: "center" },
  scoreSmall: { fontSize: 11, fontWeight: 700, minWidth: 16, textAlign: "center" },

  postContent: { flex: 1, cursor: "pointer" },
  postMeta: { display: "flex", alignItems: "center", gap: 6, marginBottom: 6 },
  postAuthor: { fontSize: 12, fontWeight: 600, color: T.muted },
  nameLink: { fontSize: 12, fontWeight: 700, color: T.primary, cursor: "pointer", textDecoration: "underline" },
  timeDot: { fontSize: 12, color: T.muted },
  timeSmall: { fontSize: 11, color: T.muted },
  postTitle: { fontSize: 16, fontWeight: 700, color: T.dark, margin: "0 0 6px", lineHeight: 1.35 },
  postBodyPreview: { fontSize: 13, color: T.muted, margin: "0 0 10px", lineHeight: 1.5 },
  postFooter: { display: "flex", alignItems: "center", gap: 14 },
  commentCount: { display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: T.muted, fontWeight: 600 },
  readMore: { fontSize: 12, color: T.primary, fontWeight: 600 },

  // Post detail
  detailBody: { flex: 1, overflowY: "auto", padding: "24px 28px" },
  postDetailCard: { display: "flex", gap: 16, marginBottom: 24 },
  postDetailContent: { flex: 1 },
  postDetailMeta: { display: "flex", alignItems: "center", gap: 8, marginBottom: 10 },
  byLine: { display: "flex", alignItems: "center", gap: 5, fontSize: 13, color: T.muted },
  postDetailTitle: { fontSize: 22, fontWeight: 800, color: T.dark, margin: "0 0 12px", lineHeight: 1.3 },
  postDetailBody: { fontSize: 15, color: T.dark, lineHeight: 1.65, margin: 0, background: T.bg, borderRadius: T.r, padding: "14px 18px" },

  commentsSection: { borderTop: `1.5px solid ${T.border}`, paddingTop: 20 },
  commentsLabel: { fontSize: 14, fontWeight: 800, color: T.dark, margin: "0 0 16px" },
  commentCompose: { display: "flex", gap: 12, marginBottom: 20, alignItems: "flex-start" },
  commentInput: { width: "100%", padding: "10px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: "inherit", resize: "vertical", boxSizing: "border-box", color: T.dark, display: "block", marginBottom: 8 },
  btnSm: { padding: "7px 16px", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, fontSize: 13, fontWeight: 700, cursor: "pointer" },
  commentCard: { display: "flex", gap: 12, padding: "14px 0", borderTop: `1px solid ${T.border}` },
  commentLeft: { flexShrink: 0 },
  commentText: { fontSize: 14, color: T.dark, margin: "0 0 8px", lineHeight: 1.55 },
  commentVoteRow: { display: "flex", alignItems: "center", gap: 4 },

  discPill: { display: "inline-block", padding: "3px 12px", borderRadius: T.rPill, fontSize: 11, fontWeight: 700, marginBottom: 10 },
  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.4)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, padding: 24 },
  miniModal: { background: "#fff", borderRadius: T.rXL, padding: "32px 28px", maxWidth: 360, width: "100%", textAlign: "center", position: "relative", boxShadow: T.shadowLg },
  closeBtn: { position: "absolute", top: 12, right: 12, background: "none", border: "none", cursor: "pointer", color: T.muted },
  viewedName: { fontSize: 20, fontWeight: 800, color: T.dark, margin: "0 0 8px" },
  viewedMeta: { display: "flex", alignItems: "center", gap: 5, justifyContent: "center", fontSize: 13, color: T.muted, margin: "4px 0" },
  viewedBio: { fontSize: 13, color: T.muted, margin: "10px 0 14px", lineHeight: 1.5 },
  btnDM: { display: "flex", alignItems: "center", gap: 8, background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "12px 24px", fontSize: 14, fontWeight: 700, cursor: "pointer", margin: "0 auto", boxShadow: "0 4px 14px rgba(124,58,237,0.3)" },
};
