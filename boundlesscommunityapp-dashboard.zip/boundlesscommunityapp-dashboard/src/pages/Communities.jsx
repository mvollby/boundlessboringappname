import { distanceMiles } from "../utils/geocoding";
import { T } from "../theme";
import { Icon } from "../Icons";

const CITIES = [
  { name: "Denver",         lat: 39.7392, lng: -104.9903, state: "CO" },
  { name: "Boulder",        lat: 40.0150, lng: -105.2705, state: "CO" },
  { name: "San Francisco",  lat: 37.7749, lng: -122.4194, state: "CA" },
  { name: "Atlanta",        lat: 33.7490, lng:  -84.3880, state: "GA" },
  { name: "New York",       lat: 40.7128, lng:  -74.0060, state: "NY" },
  { name: "Boston",         lat: 42.3601, lng:  -71.0589, state: "MA" },
  { name: "Austin",         lat: 30.2672, lng:  -97.7431, state: "TX" },
  { name: "Dallas",         lat: 32.7767, lng:  -96.7970, state: "TX" },
  { name: "Salt Lake City", lat: 40.7608, lng: -111.8910, state: "UT" },
];

const RADIUS_MILES = 50;

export default function Communities({ myProfile, allProfiles }) {
  const cityData = CITIES.map((city) => {
    const members = allProfiles.filter((p) =>
      p.lat && distanceMiles(p.lat, p.lng, city.lat, city.lng) <= RADIUS_MILES
    );
    const isMember = myProfile.lat
      ? distanceMiles(myProfile.lat, myProfile.lng, city.lat, city.lng) <= RADIUS_MILES
      : false;
    const myMiles = myProfile.lat
      ? Math.round(distanceMiles(myProfile.lat, myProfile.lng, city.lat, city.lng))
      : null;
    return { ...city, members, isMember, myMiles };
  });

  const myCities    = cityData.filter((c) => c.isMember);
  const otherCities = cityData.filter((c) => !c.isMember).sort((a, b) => (a.myMiles ?? 99999) - (b.myMiles ?? 99999));

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Local Communities</h2>
          <p style={S.sub}>Athletes within 50 miles of each city are auto-added to that community.</p>
        </div>
      </div>

      {!myProfile.lat && (
        <div style={S.banner}>
          <Icon.MapPin style={{ width: 16, height: 16, flexShrink: 0 }} />
          Add a location to your profile to be placed in your local community automatically.
        </div>
      )}

      {myCities.length > 0 && (
        <>
          <SectionLabel>Your Communities</SectionLabel>
          <div style={S.grid}>
            {myCities.map((c) => <CityCard key={c.name} city={c} isMember />)}
          </div>
        </>
      )}

      <SectionLabel style={{ marginTop: myCities.length > 0 ? 32 : 0 }}>
        {myCities.length > 0 ? "Other Cities" : "All City Communities"}
      </SectionLabel>
      <div style={S.grid}>
        {otherCities.map((c) => <CityCard key={c.name} city={c} />)}
      </div>

      <p style={S.hint}>Update your location in My Profile to auto-join the nearest community.</p>
    </div>
  );
}

function CityCard({ city, isMember }) {
  const { name, state, members, myMiles } = city;
  const preview = members.slice(0, 5);

  const discCounts = members.reduce((acc, p) => {
    acc[p.discipline] = (acc[p.discipline] || 0) + 1;
    return acc;
  }, {});

  return (
    <div style={{ ...S.card, border: isMember ? `2px solid ${T.primary}` : `1.5px solid ${T.border}` }}>
      <div style={S.cardTop}>
        <div style={S.cityLeft}>
          <div style={S.cityName}>{name}</div>
          <div style={S.cityState}>{state}</div>
        </div>
        <div style={S.cardRight}>
          {isMember && (
            <span style={S.memberBadge}>
              <Icon.Check style={{ width: 10, height: 10 }} /> Member
            </span>
          )}
          {myMiles !== null && !isMember && (
            <span style={S.milesBadge}>{myMiles} mi</span>
          )}
        </div>
      </div>

      {/* Avatar strip */}
      <div style={S.avatarRow}>
        {preview.map((p) => <MiniAvatar key={p.userId} profile={p} />)}
        {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
        {members.length === 0 && <span style={S.emptyLabel}>No members yet</span>}
      </div>

      <div style={S.statsRow}>
        <span style={S.statNum}>{members.length}</span>
        <span style={S.statLabel}> athlete{members.length !== 1 ? "s" : ""}</span>
        <div style={S.discRow}>
          {Object.entries(discCounts).map(([d, n]) => {
            const dc = T.disc[d] || T.disc.Runner;
            return <span key={d} style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{n} {d}</span>;
          })}
        </div>
      </div>
    </div>
  );
}

function MiniAvatar({ profile }) {
  const dc       = T.disc[profile.discipline] || T.disc.Runner;
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt="" title={profile.name} style={S.miniAvatarImg} />
    : <div style={{ ...S.miniAvatar, background: dc.grad }} title={profile.name}>{initials}</div>;
}

function SectionLabel({ children, style }) {
  return <p style={{ ...S.sectionLabel, ...style }}>{children}</p>;
}

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { marginBottom: 24 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  banner: { display: "flex", alignItems: "center", gap: 10, background: "#FEF3C7", border: "1px solid #FDE68A", color: "#92400E", borderRadius: T.r, padding: "12px 16px", fontSize: 13, fontWeight: 500, marginBottom: 24 },
  sectionLabel: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: T.muted, marginBottom: 14 },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(250px,1fr))", gap: 16 },
  card: { background: "#fff", borderRadius: T.rXL, padding: "20px 20px 18px", boxShadow: T.shadowSm },
  cardTop: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 },
  cityLeft: {},
  cityName: { fontSize: 17, fontWeight: 800, color: T.dark, marginBottom: 2 },
  cityState: { fontSize: 12, color: T.muted, fontWeight: 600 },
  cardRight: { display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 },
  memberBadge: { display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700, color: T.primary, background: "#EDE9FE", padding: "3px 10px", borderRadius: T.rPill },
  milesBadge: { fontSize: 11, fontWeight: 600, color: T.muted, background: T.bg, padding: "3px 10px", borderRadius: T.rPill },
  avatarRow: { display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12, alignItems: "center" },
  miniAvatar: { width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#fff" },
  miniAvatarImg: { width: 32, height: 32, borderRadius: "50%", objectFit: "cover", border: `2px solid ${T.border}` },
  morePill: { width: 32, height: 32, borderRadius: "50%", background: T.bg, color: T.muted, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 },
  emptyLabel: { fontSize: 12, color: T.muted, fontStyle: "italic" },
  statsRow: { display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" },
  statNum: { fontSize: 15, fontWeight: 800, color: T.dark },
  statLabel: { fontSize: 13, color: T.muted, marginRight: 6 },
  discRow: { display: "flex", gap: 4, flexWrap: "wrap" },
  discPill: { fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: T.rPill },
  hint: { marginTop: 32, textAlign: "center", fontSize: 13, color: "#C4B5FD", fontStyle: "italic" },
};
