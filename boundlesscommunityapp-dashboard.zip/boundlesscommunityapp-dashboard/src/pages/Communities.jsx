import { useState, useMemo } from "react";
import { distanceMiles } from "../utils/geocoding";
import { conversationStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";

const ALL_EVENTS = [
  "London Marathon 2026","Oxford Half Marathon","Parkrun Series Summer","Cross Country Nationals","Track & Field Open",
  "Tour of Britain Stage","Cotswolds Sportive","Velodrome Cup","Hill Climb Championship",
  "Blenheim Triathlon","Ironman 70.3 Staffordshire","Aquathlon Series","Duathlon National Champs","SwimRun Cotswolds",
  "Leadville Trail 100 Run","Leadville Trail 100 Mountain Bike","UNBOUND Gravel","Big Sugar","SPT GRVL",
];
const GENDERS = ["Man","Woman","Non-binary","Prefer not to say"];
const SPORTS  = ["Runner","Cyclist","Multisport"];

function canSee(myDisc, theirDisc, sportFilter) {
  // Apply sport filter first
  if (sportFilter && theirDisc !== sportFilter) return false;
  // Then discipline rule
  if (myDisc === "Multisport") return true;
  return myDisc === theirDisc;
}

export default function Communities({ myProfile, allProfiles, currentUser, onNavigateToMessages }) {
  const [filters, setFilters] = useState({ genders: [], radius: 500, event: "", sport: "" });
  const [confirmTarget, setConfirmTarget] = useState(null);
  const [sent, setSent]               = useState(new Set());
  const [selected, setSelected]       = useState(null);

  const setFilter    = (k, v) => setFilters((f) => ({ ...f, [k]: v }));
  const toggleGender = (g) => setFilters((f) => ({
    ...f,
    genders: f.genders.includes(g) ? f.genders.filter((x) => x !== g) : [...f.genders, g],
  }));

  const athletes = useMemo(() => {
    return allProfiles
      .filter((p) => p.userId !== currentUser.id && canSee(myProfile.discipline, p.discipline, filters.sport))
      .map((p) => ({
        ...p,
        _miles: myProfile.lat && p.lat ? distanceMiles(myProfile.lat, myProfile.lng, p.lat, p.lng) : Infinity,
      }))
      .filter((p) => {
        if (filters.genders.length > 0 && !filters.genders.includes(p.gender)) return false;
        if (myProfile.lat && p._miles !== Infinity && p._miles > filters.radius) return false;
        if (filters.event && !(p.events || []).includes(filters.event)) return false;
        return true;
      })
      .sort((a, b) => a._miles - b._miles);
  }, [allProfiles, myProfile, currentUser.id, filters]);

  const activeFilters = filters.genders.length + (filters.event ? 1 : 0) + (filters.sport ? 1 : 0) + (filters.radius < 500 ? 1 : 0);

  const handleConnect = (profile) => {
    const existing = conversationStorage.existing(currentUser.id, profile.userId);
    if (existing) { setSent((s) => new Set([...s, profile.userId])); setConfirmTarget(null); setSelected(null); return; }
    conversationStorage.create({
      initiatorId:    currentUser.id,
      recipientId:    profile.userId,
      initiatorName:  currentUser.name,
      initiatorEmail: currentUser.email,
      note: `Hey ${profile.name.split(" ")[0]}! I'd love to connect — let's chat on Boundless!`,
    });
    setSent((s) => new Set([...s, profile.userId]));
    setConfirmTarget(null);
    setSelected(null);
  };

  return (
    <div style={S.root}>
      {/* Header */}
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Athletes</h2>
          <p style={S.sub}>
            {myProfile.discipline === "Multisport" ? "All athletes · sorted nearest first" : `${myProfile.discipline}s near you`}
          </p>
        </div>
        {activeFilters > 0 && (
          <button style={S.clearBtn} onClick={() => setFilters({ genders: [], radius: 500, event: "", sport: "" })}>
            Clear filters <span style={S.filterCount}>{activeFilters}</span>
          </button>
        )}
      </div>

      {/* Filter panel — always visible */}
      <div style={S.filterPanel}>
        {/* Sport */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Sport</label>
          <div style={S.chipRow}>
            {SPORTS.map((s) => (
              <button key={s} onClick={() => setFilter("sport", filters.sport === s ? "" : s)}
                style={{ ...S.chip, ...(filters.sport === s ? S.chipActive : {}) }}>
                {filters.sport === s && <Icon.Check style={{ width: 10, height: 10 }} />}{s}
              </button>
            ))}
          </div>
        </div>

        {/* Gender */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Gender</label>
          <div style={S.chipRow}>
            {GENDERS.map((g) => (
              <button key={g} onClick={() => toggleGender(g)}
                style={{ ...S.chip, ...(filters.genders.includes(g) ? S.chipActive : {}) }}>
                {filters.genders.includes(g) && <Icon.Check style={{ width: 10, height: 10 }} />}{g}
              </button>
            ))}
          </div>
        </div>

        {/* Proximity */}
        {myProfile.lat && (
          <div style={S.filterGroup}>
            <label style={S.filterLabel}>Proximity · <strong>{filters.radius === 500 ? "Any distance" : `${filters.radius} mi`}</strong></label>
            <input type="range" min={10} max={500} step={10} value={filters.radius}
              onChange={(e) => setFilter("radius", Number(e.target.value))}
              style={{ width: "100%", accentColor: T.primary }} />
            <div style={S.rangeLabels}><span>10 mi</span><span>500 mi</span></div>
          </div>
        )}

        {/* Shared event */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Shared event</label>
          <select style={S.select} value={filters.event} onChange={(e) => setFilter("event", e.target.value)}>
            <option value="">Any event</option>
            {ALL_EVENTS.map((e) => <option key={e} value={e}>{e}</option>)}
          </select>
        </div>
      </div>

      {/* Athlete grid */}
      {athletes.length === 0 ? (
        <div style={S.empty}>
          <Icon.Users style={{ width: 36, height: 36, color: T.border, display: "block", margin: "0 auto 12px" }} />
          <p style={{ color: T.muted }}>{activeFilters > 0 ? "No athletes match your filters." : "No other athletes yet."}</p>
        </div>
      ) : (
        <div style={S.grid}>
          {athletes.map((p) => (
            <AthleteCard key={p.userId} p={p} sent={sent}
              onSelect={setSelected} onConfirm={setConfirmTarget} />
          ))}
        </div>
      )}

      {/* Profile modal */}
      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <ProfileModalContent profile={selected} sent={sent} onConfirm={setConfirmTarget} />
        </Modal>
      )}

      {/* Confirm connect */}
      {confirmTarget && (
        <Modal onClose={() => setConfirmTarget(null)} narrow>
          <div style={{ textAlign: "center" }}>
            <AvatarEl profile={confirmTarget} size={60} style={{ margin: "0 auto 14px" }} />
            <p style={S.confirmText}>Send a message request to <strong>{confirmTarget.name}</strong>?</p>
            <p style={S.confirmSub}>They'll see your request in their Messages tab and can accept or decline.</p>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button style={S.btnSec} onClick={() => setConfirmTarget(null)}>Cancel</button>
              <button style={{ ...S.btnPri, flex: 1 }} onClick={() => handleConnect(confirmTarget)}>Send Request</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function AthleteCard({ p, sent, onSelect, onConfirm }) {
  const miles   = p._miles !== Infinity ? Math.round(p._miles) : null;
  const dc      = T.disc[p.discipline] || T.disc.Runner;
  const already = sent.has(p.userId);
  return (
    <div style={S.card} onClick={() => onSelect(p)}>
      <AvatarEl profile={p} size={58} style={{ marginBottom: 10 }} />
      <div style={S.cardName}>{p.name}</div>
      <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{p.discipline}</span>
      {p.gender && <div style={S.cardMeta}><Icon.User style={{ width: 11, height: 11 }} /> {p.gender}</div>}
      {miles !== null && <div style={S.milesBadge}>{miles} mi away</div>}
      {p.location && <div style={S.cardMeta}><Icon.MapPin style={{ width: 11, height: 11 }} />{p.location}</div>}
      <button style={{ ...S.btnConnect, ...(already ? S.btnSent : {}) }} disabled={already}
        onClick={(e) => { e.stopPropagation(); onConfirm(p); }}>
        {already ? "Sent" : "Connect"}
      </button>
    </div>
  );
}

function ProfileModalContent({ profile, sent, onConfirm }) {
  const dc = T.disc[profile.discipline] || T.disc.Runner;
  return (
    <>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, marginBottom: 18 }}>
        <AvatarEl profile={profile} size={80} />
        <h3 style={{ fontSize: 22, fontWeight: 800, color: T.dark, margin: 0 }}>{profile.name}</h3>
        <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{profile.discipline}</span>
      </div>
      <div style={{ background: T.bg, borderRadius: T.r, padding: "12px 16px", marginBottom: 14, display: "flex", flexDirection: "column", gap: 7 }}>
        {profile.gender   && <Row icon={<Icon.User style={{ width: 14, height: 14, color: T.muted }} />} text={profile.gender} />}
        {profile.location && <Row icon={<Icon.MapPin style={{ width: 14, height: 14, color: T.muted }} />} text={profile.location} />}
        {profile.coach    && <Row icon={<Icon.Star style={{ width: 13, height: 13, color: T.amber }} />} text={`Coach: ${profile.coach}`} />}
        {profile.events?.length > 0 && <Row icon={<Icon.Flag style={{ width: 14, height: 14, color: T.primary }} />} text={profile.events.join(", ")} />}
      </div>
      {profile.bio && <p style={{ fontSize: 14, color: T.muted, lineHeight: 1.6, marginBottom: 16 }}>{profile.bio}</p>}
      <button
        style={sent.has(profile.userId) ? { ...S.btnPri, background: T.disc.Runner.bg, color: T.disc.Runner.color, boxShadow: "none" } : S.btnPri}
        disabled={sent.has(profile.userId)}
        onClick={() => !sent.has(profile.userId) && onConfirm(profile)}>
        {sent.has(profile.userId) ? "Request Sent" : `Connect with ${profile.name.split(" ")[0]}`}
      </button>
    </>
  );
}

function Row({ icon, text }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: T.dark }}>{icon}<span>{text}</span></div>;
}

function AvatarEl({ profile, size, style }) {
  const dc       = T.disc[profile.discipline] || T.disc.Runner;
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt="" style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover", border: `3px solid ${T.border}`, display: "block", ...style }} />
    : <div style={{ width: size, height: size, borderRadius: "50%", background: dc.grad || dc.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.32, fontWeight: 800, color: "#fff", flexShrink: 0, ...style }}>{initials}</div>;
}

function Modal({ children, onClose, narrow }) {
  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={{ ...S.modal, maxWidth: narrow ? 380 : 440 }} onClick={(e) => e.stopPropagation()}>
        <button style={S.closeBtn} onClick={onClose}><Icon.X style={{ width: 18, height: 18 }} /></button>
        {children}
      </div>
    </div>
  );
}

const S = {
  root: { paddingBottom: 60 },
  pageHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, flexWrap: "wrap", gap: 12 },
  title: { fontSize: 22, fontWeight: 800, margin: "0 0 3px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  clearBtn: { display: "flex", alignItems: "center", gap: 7, background: "none", border: "none", color: T.danger, fontSize: 13, fontWeight: 600, cursor: "pointer", padding: 0 },
  filterCount: { background: T.danger, color: "#fff", borderRadius: T.rPill, padding: "1px 6px", fontSize: 11, fontWeight: 700 },

  filterPanel: { background: "#fff", borderRadius: T.rXL, padding: "20px 24px", marginBottom: 24, boxShadow: T.shadowSm, border: `1.5px solid ${T.border}`, display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 20 },
  filterGroup: { display: "flex", flexDirection: "column", gap: 8 },
  filterLabel: { fontSize: 12, fontWeight: 700, color: T.dark, textTransform: "uppercase", letterSpacing: "0.04em" },
  chipRow: { display: "flex", flexWrap: "wrap", gap: 6 },
  chip: { display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", color: T.dark },
  chipActive: { background: "#EDE9FE", borderColor: T.primary, color: T.primary },
  rangeLabels: { display: "flex", justifyContent: "space-between", fontSize: 11, color: T.muted },
  select: { padding: "9px 12px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 13, background: T.bg, color: T.dark, outline: "none", fontFamily: T.fontBase },

  empty: { textAlign: "center", padding: "48px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 14 },
  card: { background: "#fff", borderRadius: T.rXL, padding: "22px 18px 18px", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", boxShadow: T.shadowSm, cursor: "pointer", border: `1.5px solid ${T.border}` },
  cardName: { fontSize: 15, fontWeight: 700, color: T.dark, marginBottom: 6 },
  cardMeta: { display: "flex", alignItems: "center", gap: 4, color: T.muted, fontSize: 11, marginTop: 3 },
  milesBadge: { fontSize: 11, fontWeight: 600, color: T.primary, background: "#EDE9FE", borderRadius: T.rPill, padding: "2px 9px", margin: "4px 0" },
  discPill: { display: "inline-flex", alignItems: "center", gap: 3, padding: "3px 10px", borderRadius: T.rPill, fontSize: 11, fontWeight: 700, marginBottom: 4 },
  btnConnect: { marginTop: 10, width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "9px", fontSize: 12, fontWeight: 700, cursor: "pointer", boxShadow: "0 3px 10px rgba(124,58,237,0.25)" },
  btnSent: { background: T.disc.Runner.bg, color: T.disc.Runner.color, boxShadow: "none" },

  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 24 },
  modal: { background: "#fff", borderRadius: T.rXL, padding: "36px 32px 32px", width: "100%", position: "relative", boxShadow: T.shadowLg },
  closeBtn: { position: "absolute", top: 14, right: 14, background: "none", border: "none", cursor: "pointer", color: T.muted },
  confirmText: { fontSize: 16, fontWeight: 700, color: T.dark, margin: "0 0 8px" },
  confirmSub: { fontSize: 13, color: T.muted },
  btnPri: { width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 14px rgba(124,58,237,0.28)" },
  btnSec: { flex: 1, background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
};
