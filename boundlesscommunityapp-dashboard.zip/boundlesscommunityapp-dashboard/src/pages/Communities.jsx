import { useState, useMemo } from "react";
import { distanceMiles } from "../utils/geocoding";
import { conversationStorage, eventStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import Avatar from "../components/Avatar";

const GENDERS = ["Man", "Woman", "Non-binary", "Prefer not to say"];
const SPORTS  = ["Runner", "Cyclist", "Multisport"];
const GOAL_OPTIONS = ["Looking for Pacers", "Wanting to Meet People", "Finding Training Partners"];

function canSee(myDisc, theirDisc, sportFilter) {
  if (sportFilter && theirDisc !== sportFilter) return false;
  if (myDisc === "Multisport") return true;
  return myDisc === theirDisc;
}

// Resolve event IDs → names
function resolveNames(ids) {
  const all = eventStorage.getAll();
  return (ids || []).map((id) => all.find((e) => e.id === id)?.name).filter(Boolean);
}

export default function Communities({ myProfile, allProfiles, currentUser, onNavigateToMessages }) {
  const [filters,       setFilters]       = useState({ genders: [], radiusOn: false, radius: 100, eventId: "", sport: "" });
  const [confirmTarget, setConfirmTarget] = useState(null);
  const [customNote,    setCustomNote]    = useState("");
  const [selected,      setSelected]      = useState(null);
  const [refreshKey,    setRefreshKey]    = useState(0);

  const setFilter    = (k, v) => setFilters((f) => ({ ...f, [k]: v }));
  const toggleGender = (g) => setFilters((f) => ({
    ...f,
    genders: f.genders.includes(g) ? f.genders.filter((x) => x !== g) : [...f.genders, g],
  }));

  // Build map: recipientId (or other participant) → conv status
  const convStatusMap = useMemo(() => {
    const convs = conversationStorage.forUser(currentUser.id).filter((c) => c.status !== "declined");
    const map = {};
    convs.forEach((c) => {
      const otherId = c.participants.find((p) => p !== currentUser.id);
      if (otherId) map[otherId] = c.status; // "pending" | "active"
    });
    return map;
  }, [currentUser.id, refreshKey]); // eslint-disable-line

  // Events for the shared-event filter
  const allEvents = useMemo(() => eventStorage.getAll().sort((a, b) => a.name.localeCompare(b.name)), []);

  const athletes = useMemo(() => {
    return allProfiles
      .filter((p) => p.userId !== currentUser.id && !p.isAdmin && canSee(myProfile.discipline, p.discipline, filters.sport))
      .map((p) => ({
        ...p,
        _miles: myProfile.lat && p.lat ? distanceMiles(myProfile.lat, myProfile.lng, p.lat, p.lng) : Infinity,
      }))
      .filter((p) => {
        if (filters.genders.length > 0 && !filters.genders.includes(p.gender)) return false;
        if (filters.radiusOn && myProfile.lat && p._miles !== Infinity && p._miles > filters.radius) return false;
        if (filters.eventId && !(p.events || []).includes(filters.eventId)) return false;
        return true;
      })
      .sort((a, b) => a._miles - b._miles);
  }, [allProfiles, myProfile, currentUser.id, filters]);

  const activeFilters = filters.genders.length + (filters.eventId ? 1 : 0) + (filters.sport ? 1 : 0) + (filters.radiusOn ? 1 : 0);

  const openConfirm = (profile) => {
    setConfirmTarget(profile);
    setCustomNote("");
  };

  const handleConnect = () => {
    if (!confirmTarget) return;
    const existing = conversationStorage.existing(currentUser.id, confirmTarget.userId);
    if (!existing) {
      conversationStorage.create({
        initiatorId:    currentUser.id,
        recipientId:    confirmTarget.userId,
        initiatorName:  currentUser.name,
        initiatorEmail: currentUser.email,
        note: customNote.trim() || `Hey ${confirmTarget.name.split(" ")[0]}! I'd love to connect on Boundless!`,
      });
    }
    setRefreshKey((k) => k + 1);
    setConfirmTarget(null);
    setSelected(null);
  };

  return (
    <div style={S.root}>
      {/* Header */}
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Athletes</h2>
          <p style={S.sub}>
            {myProfile.discipline === "Multisport" ? "All athletes · sorted nearest first" : `${myProfile.discipline}s near you`}
          </p>
        </div>
        {activeFilters > 0 && (
          <button style={S.clearBtn} onClick={() => setFilters({ genders: [], radiusOn: false, radius: 100, eventId: "", sport: "" })}>
            Clear filters <span style={S.filterCount}>{activeFilters}</span>
          </button>
        )}
      </div>

      {/* Filter panel */}
      <div style={S.filterPanel}>
        {/* Sport */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Sport</label>
          <div style={S.chipRow}>
            {SPORTS.map((s) => (
              <button key={s} onClick={() => setFilter("sport", filters.sport === s ? "" : s)}
                style={{ ...S.chip, ...(filters.sport === s ? S.chipActive : {}) }}>
                {filters.sport === s && <Icon.Check style={{ width: 10, height: 10 }} />}{s}
              </button>
            ))}
          </div>
        </div>

        {/* Gender */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Gender</label>
          <div style={S.chipRow}>
            {GENDERS.map((g) => (
              <button key={g} onClick={() => toggleGender(g)}
                style={{ ...S.chip, ...(filters.genders.includes(g) ? S.chipActive : {}) }}>
                {filters.genders.includes(g) && <Icon.Check style={{ width: 10, height: 10 }} />}{g}
              </button>
            ))}
          </div>
        </div>

        {/* Proximity toggle + slider */}
        {myProfile.lat && (
          <div style={S.filterGroup}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <label style={S.filterLabel}>
                Proximity {filters.radiusOn ? <strong>· {filters.radius} mi</strong> : ""}
              </label>
              <Toggle on={filters.radiusOn} onToggle={(v) => setFilter("radiusOn", v)} />
            </div>
            <div style={{ opacity: filters.radiusOn ? 1 : 0.35, transition: "opacity 0.2s", pointerEvents: filters.radiusOn ? "auto" : "none" }}>
              <input type="range" min={10} max={500} step={10} value={filters.radius}
                onChange={(e) => setFilter("radius", Number(e.target.value))}
                style={{ width: "100%", accentColor: T.primary }} />
              <div style={S.rangeLabels}><span>10 mi</span><span>500 mi</span></div>
            </div>
          </div>
        )}

        {/* Shared event */}
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Shared event</label>
          <select style={S.select} value={filters.eventId} onChange={(e) => setFilter("eventId", e.target.value)}>
            <option value="">Any event</option>
            {allEvents.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      </div>

      {/* Athlete grid */}
      {athletes.length === 0 ? (
        <div style={S.empty}>
          <Icon.Users style={{ width: 36, height: 36, color: T.border, display: "block", margin: "0 auto 12px" }} />
          <p style={{ color: T.muted }}>{activeFilters > 0 ? "No athletes match your filters." : "No other athletes yet."}</p>
        </div>
      ) : (
        <div style={S.grid}>
          {athletes.map((p) => (
            <AthleteCard key={p.userId} p={p}
              status={convStatusMap[p.userId] || null}
              onSelect={setSelected}
              onConfirm={openConfirm}
            />
          ))}
        </div>
      )}

      {/* Profile modal */}
      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <ProfileModalContent
            profile={selected}
            status={convStatusMap[selected.userId] || null}
            onConfirm={openConfirm}
          />
        </Modal>
      )}

      {/* Confirm connect */}
      {confirmTarget && (
        <Modal onClose={() => setConfirmTarget(null)} narrow>
          <div style={{ textAlign: "center" }}>
            <Avatar photoUrl={confirmTarget.photoUrl} name={confirmTarget.name} discipline={confirmTarget.discipline}
              size={60} style={{ margin: "0 auto 14px" }} />
            <p style={S.confirmText}>Connect with <strong>{confirmTarget.name}</strong>?</p>
            <p style={S.confirmSub}>Add an intro message so they know who you are.</p>
            <textarea
              style={S.noteInput}
              placeholder={`Hey ${confirmTarget.name.split(" ")[0]}! I'd love to connect on Boundless!`}
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value.slice(0, 200))}
              rows={3}
            />
            <div style={S.noteCounter}>{customNote.length}/200</div>
            <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
              <button style={S.btnSec} onClick={() => setConfirmTarget(null)}>Cancel</button>
              <button style={{ ...S.btnPri, flex: 1 }} onClick={handleConnect}>Send Request</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ── Toggle switch ─────────────────────────────────────────────────────────────
function Toggle({ on, onToggle }) {
  return (
    <button onClick={() => onToggle(!on)}
      style={{ ...S.toggleTrack, background: on ? T.primary : T.border }}>
      <div style={{ ...S.toggleThumb, transform: on ? "translateX(18px)" : "translateX(2px)" }} />
    </button>
  );
}

// ── Connect button with status states ─────────────────────────────────────────
function ConnectBtn({ status, onConfirm, profile, fullWidth }) {
  if (status === "active") {
    return (
      <button style={{ ...S.btnConnect, background: T.disc.Runner.bg, color: T.disc.Runner.color, boxShadow: "none", ...(fullWidth ? { width: "100%" } : {}) }} disabled>
        Connected
      </button>
    );
  }
  if (status === "pending") {
    return (
      <button style={{ ...S.btnConnect, background: "#F3F4F6", color: T.muted, boxShadow: "none", cursor: "default", ...(fullWidth ? { width: "100%" } : {}) }} disabled>
        Requested
      </button>
    );
  }
  return (
    <button style={{ ...S.btnConnect, ...(fullWidth ? { width: "100%" } : {}) }}
      onClick={(e) => { e.stopPropagation(); onConfirm(profile); }}>
      Connect
    </button>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function AthleteCard({ p, status, onSelect, onConfirm }) {
  const miles = p._miles !== Infinity ? Math.round(p._miles) : null;
  const dc    = T.disc[p.discipline] || T.disc.Runner;
  return (
    <div style={S.card} onClick={() => onSelect(p)}>
      <Avatar photoUrl={p.photoUrl} name={p.name} discipline={p.discipline} size={58} style={{ marginBottom: 10 }} />
      <div style={S.cardName}>{p.name}</div>
      <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{p.discipline}</span>
      {p.gender && <div style={S.cardMeta}><Icon.User style={{ width: 11, height: 11 }} /> {p.gender}</div>}
      {miles !== null && <div style={S.milesBadge}>{miles} mi away</div>}
      {p.location && <div style={S.cardMeta}><Icon.MapPin style={{ width: 11, height: 11 }} />{p.location}</div>}
      <ConnectBtn status={status} onConfirm={onConfirm} profile={p} />
    </div>
  );
}

function ProfileModalContent({ profile, status, onConfirm }) {
  const dc        = T.disc[profile.discipline] || T.disc.Runner;
  const evNames   = resolveNames(profile.events);
  return (
    <>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, marginBottom: 18 }}>
        <Avatar photoUrl={profile.photoUrl} name={profile.name} discipline={profile.discipline} size={80} />
        <h3 style={{ fontSize: 22, fontWeight: 800, color: T.dark, margin: 0 }}>{profile.name}</h3>
        <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{profile.discipline}</span>
      </div>
      <div style={{ background: T.bg, borderRadius: T.r, padding: "12px 16px", marginBottom: 14, display: "flex", flexDirection: "column", gap: 7 }}>
        {profile.gender   && <Row icon={<Icon.User  style={{ width: 14, height: 14, color: T.muted }} />}           text={profile.gender} />}
        {profile.location && <Row icon={<Icon.MapPin style={{ width: 14, height: 14, color: T.muted }} />}           text={profile.location} />}
        {profile.coach    && <Row icon={<Icon.Star   style={{ width: 13, height: 13, color: T.amber }} />}           text={`Coach: ${profile.coach}`} />}
        {evNames.length > 0 && <Row icon={<Icon.Flag style={{ width: 14, height: 14, color: T.primary }} />}         text={evNames.join(", ")} />}
      </div>
      {/* Goals */}
      {profile.goals?.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <p style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: T.muted, margin: "0 0 7px" }}>Goals</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {profile.goals.map((g) => (
              <span key={g} style={{ background: "#EDE9FE", color: T.primary, borderRadius: T.rPill, padding: "4px 12px", fontSize: 12, fontWeight: 600 }}>
                {g}
              </span>
            ))}
          </div>
        </div>
      )}
      {profile.bio && <p style={{ fontSize: 14, color: T.muted, lineHeight: 1.6, marginBottom: 16 }}>{profile.bio}</p>}
      <ConnectBtn status={status} onConfirm={onConfirm} profile={profile} fullWidth />
    </>
  );
}

function Row({ icon, text }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: T.dark }}>{icon}<span>{text}</span></div>;
}

function Modal({ children, onClose, narrow }) {
  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={{ ...S.modal, maxWidth: narrow ? 400 : 440 }} onClick={(e) => e.stopPropagation()}>
        <button style={S.closeBtn} onClick={onClose}><Icon.X style={{ width: 18, height: 18 }} /></button>
        {children}
      </div>
    </div>
  );
}

const S = {
  root: { paddingBottom: 60 },
  pageHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, flexWrap: "wrap", gap: 12 },
  title: { fontSize: 22, fontWeight: 800, margin: "0 0 3px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  clearBtn: { display: "flex", alignItems: "center", gap: 7, background: "none", border: "none", color: T.danger, fontSize: 13, fontWeight: 600, cursor: "pointer", padding: 0 },
  filterCount: { background: T.danger, color: "#fff", borderRadius: T.rPill, padding: "1px 6px", fontSize: 11, fontWeight: 700 },

  filterPanel: { background: "#fff", borderRadius: T.rXL, padding: "20px 24px", marginBottom: 24, boxShadow: T.shadowSm, border: `1.5px solid ${T.border}`, display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 20 },
  filterGroup: { display: "flex", flexDirection: "column", gap: 0 },
  filterLabel: { fontSize: 12, fontWeight: 700, color: T.dark, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 8 },
  chipRow: { display: "flex", flexWrap: "wrap", gap: 6 },
  chip: { display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", color: T.dark },
  chipActive: { background: "#EDE9FE", borderColor: T.primary, color: T.primary },
  rangeLabels: { display: "flex", justifyContent: "space-between", fontSize: 11, color: T.muted, marginTop: 2 },
  select: { padding: "9px 12px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 13, background: T.bg, color: T.dark, outline: "none", fontFamily: T.fontBase },

  toggleTrack: { position: "relative", width: 40, height: 22, borderRadius: 11, border: "none", cursor: "pointer", transition: "background 0.2s", flexShrink: 0, padding: 0 },
  toggleThumb: { position: "absolute", top: 3, width: 16, height: 16, borderRadius: "50%", background: "#fff", transition: "transform 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.2)" },

  empty: { textAlign: "center", padding: "48px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 14 },
  card: { background: "#fff", borderRadius: T.rXL, padding: "22px 18px 18px", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", boxShadow: T.shadowSm, cursor: "pointer", border: `1.5px solid ${T.border}` },
  cardName: { fontSize: 15, fontWeight: 700, color: T.dark, marginBottom: 6 },
  cardMeta: { display: "flex", alignItems: "center", gap: 4, color: T.muted, fontSize: 11, marginTop: 3 },
  milesBadge: { fontSize: 11, fontWeight: 600, color: T.primary, background: "#EDE9FE", borderRadius: T.rPill, padding: "2px 9px", margin: "4px 0" },
  discPill: { display: "inline-flex", alignItems: "center", gap: 3, padding: "3px 10px", borderRadius: T.rPill, fontSize: 11, fontWeight: 700, marginBottom: 4 },
  btnConnect: { marginTop: 10, width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "9px", fontSize: 12, fontWeight: 700, cursor: "pointer", boxShadow: "0 3px 10px rgba(124,58,237,0.25)" },

  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 24 },
  modal: { background: "#fff", borderRadius: T.rXL, padding: "36px 32px 32px", width: "100%", position: "relative", boxShadow: T.shadowLg, maxHeight: "85vh", overflowY: "auto" },
  closeBtn: { position: "absolute", top: 14, right: 14, background: "none", border: "none", cursor: "pointer", color: T.muted },
  confirmText: { fontSize: 16, fontWeight: 700, color: T.dark, margin: "0 0 6px" },
  confirmSub: { fontSize: 13, color: T.muted, marginBottom: 14 },
  noteInput: { width: "100%", padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: "inherit", resize: "vertical", boxSizing: "border-box", color: T.dark },
  noteCounter: { fontSize: 11, color: T.muted, textAlign: "right", marginTop: 4 },
  btnPri: { width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 14px rgba(124,58,237,0.28)" },
  btnSec: { flex: 1, background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
};
