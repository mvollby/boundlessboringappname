import { useState } from "react";
import { authStorage } from "../utils/storage";
import { T } from "../theme";

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export default function RegisterPage({ onLogin, onGoLogin }) {
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");

  const set = (key) => (e) => { setForm((f) => ({ ...f, [key]: e.target.value })); setError(""); };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim())           { setError("Name is required."); return; }
    if (form.password.length < 6)    { setError("Password must be at least 6 characters."); return; }
    if (form.password !== form.confirm) { setError("Passwords don't match."); return; }

    const users = authStorage.getUsers();
    if (users.find((u) => u.email.toLowerCase() === form.email.trim().toLowerCase())) {
      setError("An account with that email already exists."); return;
    }

    const isAdmin  = users.length === 0;
    const newUser  = { id: generateId(), name: form.name.trim(), email: form.email.trim().toLowerCase(), password: form.password, isAdmin };
    authStorage.saveUsers([...users, newUser]);
    authStorage.setSession({ id: newUser.id, email: newUser.email, isAdmin, name: newUser.name });
    onLogin({ id: newUser.id, email: newUser.email, isAdmin, name: newUser.name });
  };

  return (
    <div style={S.page}>
      <div style={S.blob1} />
      <div style={S.blob2} />
      <div style={S.card}>
        <div style={S.logoWrap}>
          <div style={S.logoMark}>
            <svg viewBox="0 0 32 32" width="28" height="28" fill="none">
              <circle cx="16" cy="16" r="16" fill="url(#lg2)"/>
              <defs><linearGradient id="lg2" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                <stop stopColor="#7C3AED"/><stop offset="1" stopColor="#EC4899"/>
              </linearGradient></defs>
              <path d="M11 22l2-5 3 2 3-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="19" cy="10" r="2" fill="#fff"/>
            </svg>
          </div>
          <span style={S.logoText}>Boundless</span>
        </div>

        <h1 style={S.heading}>Join Boundless</h1>
        <p style={S.sub}>Connect with athletes near you</p>

        <form onSubmit={handleSubmit} style={S.form}>
          {[
            { key: "name",     label: "Full name",        type: "text",     ph: "Alex Johnson" },
            { key: "email",    label: "Email address",    type: "email",    ph: "you@example.com" },
            { key: "password", label: "Password",         type: "password", ph: "Min. 6 characters" },
            { key: "confirm",  label: "Confirm password", type: "password", ph: "••••••••" },
          ].map(({ key, label, type, ph }) => (
            <div key={key} style={S.fieldWrap}>
              <label style={S.label}>{label}</label>
              <input style={S.input} type={type} placeholder={ph} value={form[key]} onChange={set(key)} required />
            </div>
          ))}
          {error && <div style={S.error}>{error}</div>}
          <button type="submit" style={S.btnPri}>Create account</button>
        </form>

        <p style={S.footer}>
          Already have an account?{" "}
          <button style={S.link} onClick={onGoLogin}>Sign in →</button>
        </p>
        <p style={S.note}>First account created becomes admin.</p>
      </div>
    </div>
  );
}

const S = {
  page: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: T.bg, padding: 20, position: "relative", overflow: "hidden", fontFamily: T.fontBase },
  blob1: { position: "absolute", top: -120, right: -120, width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(124,58,237,0.15) 0%, transparent 70%)", pointerEvents: "none" },
  blob2: { position: "absolute", bottom: -100, left: -100, width: 350, height: 350, borderRadius: "50%", background: "radial-gradient(circle, rgba(236,72,153,0.12) 0%, transparent 70%)", pointerEvents: "none" },
  card: { background: "#fff", borderRadius: T.rXL, padding: "44px 40px", width: "100%", maxWidth: 420, boxShadow: T.shadowLg, position: "relative", zIndex: 1 },
  logoWrap: { display: "flex", alignItems: "center", gap: 10, marginBottom: 32 },
  logoMark: { width: 36, height: 36 },
  logoText: { fontSize: 20, fontWeight: 800, background: T.grad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  heading: { fontSize: 26, fontWeight: 800, color: T.dark, margin: "0 0 6px" },
  sub: { fontSize: 14, color: T.muted, margin: "0 0 28px" },
  form: { display: "flex", flexDirection: "column", gap: 16 },
  fieldWrap: { display: "flex", flexDirection: "column", gap: 6 },
  label: { fontSize: 13, fontWeight: 600, color: T.dark },
  input: { padding: "12px 16px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: T.fontBase, color: T.dark },
  error: { background: "#FEE2E2", color: "#991B1B", borderRadius: T.r, padding: "10px 14px", fontSize: 13, fontWeight: 500 },
  btnPri: { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "14px", fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.35)" },
  footer: { marginTop: 24, textAlign: "center", fontSize: 14, color: T.muted },
  link: { background: "none", border: "none", color: T.primary, fontWeight: 700, cursor: "pointer", fontSize: 14 },
  note: { marginTop: 12, fontSize: 11, color: "#C4B5FD", textAlign: "center", fontStyle: "italic" },
};
