import { useState } from "react";
import { authStorage } from "../utils/storage";
import { T } from "../theme";

export default function LoginPage({ onLogin, onGoRegister }) {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const users = authStorage.getUsers();
    const user  = users.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
    );
    if (!user) { setError("Invalid email or password."); return; }
    authStorage.setSession({ id: user.id, email: user.email, isAdmin: user.isAdmin, name: user.name });
    onLogin({ id: user.id, email: user.email, isAdmin: user.isAdmin, name: user.name });
  };

  return (
    <div style={S.page}>
      {/* Decorative blobs */}
      <div style={S.blob1} />
      <div style={S.blob2} />

      <div style={S.card}>
        {/* Logo mark */}
        <div style={S.logoWrap}>
          <div style={S.logoMark}>
            <svg viewBox="0 0 32 32" width="28" height="28" fill="none">
              <circle cx="16" cy="16" r="16" fill="url(#lg1)"/>
              <defs><linearGradient id="lg1" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                <stop stopColor="#7C3AED"/><stop offset="1" stopColor="#EC4899"/>
              </linearGradient></defs>
              <path d="M11 22l2-5 3 2 3-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="19" cy="10" r="2" fill="#fff"/>
            </svg>
          </div>
          <span style={S.logoText}>Boundless</span>
        </div>

        <h1 style={S.heading}>Welcome back</h1>
        <p style={S.sub}>Sign in to your athlete profile</p>

        <form onSubmit={handleSubmit} style={S.form}>
          <div style={S.fieldWrap}>
            <label style={S.label}>Email address</label>
            <input style={S.input} type="email" autoComplete="email" placeholder="you@example.com"
              value={email} onChange={(e) => { setEmail(e.target.value); setError(""); }} required />
          </div>
          <div style={S.fieldWrap}>
            <label style={S.label}>Password</label>
            <input style={S.input} type="password" autoComplete="current-password" placeholder="••••••••"
              value={password} onChange={(e) => { setPassword(e.target.value); setError(""); }} required />
          </div>
          {error && <div style={S.error}>{error}</div>}
          <button type="submit" style={S.btnPri}>Sign in</button>
        </form>

        <p style={S.footer}>
          New to Boundless?{" "}
          <button style={S.link} onClick={onGoRegister}>Create an account →</button>
        </p>
      </div>
    </div>
  );
}

const S = {
  page: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: T.bg, padding: 20, position: "relative", overflow: "hidden", fontFamily: T.fontBase },
  blob1: { position: "absolute", top: -120, right: -120, width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(124,58,237,0.15) 0%, transparent 70%)", pointerEvents: "none" },
  blob2: { position: "absolute", bottom: -100, left: -100, width: 350, height: 350, borderRadius: "50%", background: "radial-gradient(circle, rgba(236,72,153,0.12) 0%, transparent 70%)", pointerEvents: "none" },
  card: { background: "#fff", borderRadius: T.rXL, padding: "44px 40px", width: "100%", maxWidth: 420, boxShadow: T.shadowLg, position: "relative", zIndex: 1 },
  logoWrap: { display: "flex", alignItems: "center", gap: 10, marginBottom: 32 },
  logoMark: { width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" },
  logoText: { fontSize: 20, fontWeight: 800, background: T.grad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  heading: { fontSize: 26, fontWeight: 800, color: T.dark, margin: "0 0 6px" },
  sub: { fontSize: 14, color: T.muted, margin: "0 0 28px" },
  form: { display: "flex", flexDirection: "column", gap: 18 },
  fieldWrap: { display: "flex", flexDirection: "column", gap: 6 },
  label: { fontSize: 13, fontWeight: 600, color: T.dark },
  input: { padding: "12px 16px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: T.fontBase, transition: "border 0.2s", color: T.dark },
  error: { background: "#FEE2E2", color: "#991B1B", borderRadius: T.r, padding: "10px 14px", fontSize: 13, fontWeight: 500 },
  btnPri: { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "14px", fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.35)", letterSpacing: "-0.01em" },
  footer: { marginTop: 24, textAlign: "center", fontSize: 14, color: T.muted },
  link: { background: "none", border: "none", color: T.primary, fontWeight: 700, cursor: "pointer", fontSize: 14 },
};
