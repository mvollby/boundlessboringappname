import { T } from "../theme";
import { Icon } from "../Icons";

const DISC_EVENTS = {
  Runner:     ["London Marathon 2026", "Oxford Half Marathon", "Parkrun Series Summer", "Cross Country Nationals", "Track & Field Open"],
  Cyclist:    ["Tour of Britain Stage", "Cotswolds Sportive", "Velodrome Cup", "Hill Climb Championship"],
  Multisport: ["Blenheim Triathlon", "Ironman 70.3 Staffordshire", "Aquathlon Series", "Duathlon National Champs", "SwimRun Cotswolds"],
};

export default function Events({ myProfile, allProfiles }) {
  const communityMap = {};
  allProfiles.forEach((p) => {
    (p.events || []).forEach((ev) => {
      if (!communityMap[ev]) communityMap[ev] = { members: [], discipline: p.discipline };
      communityMap[ev].members.push(p);
    });
  });

  const myEvents  = new Set(myProfile.events || []);
  const allGroups = Object.entries(communityMap).sort((a, b) => b[1].members.length - a[1].members.length);
  const mine      = allGroups.filter(([ev]) => myEvents.has(ev));
  const others    = allGroups.filter(([ev]) => !myEvents.has(ev));

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Events</h2>
          <p style={S.sub}>Every race has its own group — auto-populated by registered athletes.</p>
        </div>
      </div>

      {mine.length === 0 && others.length === 0 && (
        <div style={S.empty}>
          <Icon.Flag style={{ width: 40, height: 40, color: T.border, display: "block", margin: "0 auto 16px" }} />
          <p style={{ color: T.muted }}>No events yet — add races to your profile to join a group.</p>
        </div>
      )}

      {mine.length > 0 && (
        <>
          <SectionLabel>Your Event Groups</SectionLabel>
          <div style={S.grid}>
            {mine.map(([ev, data]) => <EventCard key={ev} event={ev} data={data} isMember />)}
          </div>
        </>
      )}

      {others.length > 0 && (
        <>
          <SectionLabel style={{ marginTop: 32 }}>Other Active Events</SectionLabel>
          <div style={S.grid}>
            {others.map(([ev, data]) => <EventCard key={ev} event={ev} data={data} />)}
          </div>
        </>
      )}

      <p style={S.hint}>Add races under My Profile to automatically join that event's community.</p>
    </div>
  );
}

function EventCard({ event, data, isMember }) {
  const disc    = data.discipline;
  const members = data.members;
  const preview = members.slice(0, 5);
  const dc      = T.disc[disc] || T.disc.Runner;

  return (
    <div style={{ ...S.card, border: isMember ? `2px solid ${T.primary}` : `1.5px solid ${T.border}` }}>
      {/* Gradient top strip */}
      <div style={{ ...S.cardStrip, background: dc.grad }} />

      <div style={S.cardBody}>
        <div style={S.cardTopRow}>
          <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{disc}</span>
          {isMember && (
            <span style={S.memberBadge}>
              <Icon.Check style={{ width: 10, height: 10 }} /> You're in
            </span>
          )}
        </div>
        <h4 style={S.eventName}>{event}</h4>

        <div style={S.avatarRow}>
          {preview.map((p) => <MiniAvatar key={p.userId} profile={p} />)}
          {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
          {members.length === 0 && <span style={S.emptyLabel}>No members yet</span>}
        </div>

        <p style={S.memberCount}>
          <strong>{members.length}</strong> athlete{members.length !== 1 ? "s" : ""}
        </p>
      </div>
    </div>
  );
}

function MiniAvatar({ profile }) {
  const dc       = T.disc[profile.discipline] || T.disc.Runner;
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt="" title={profile.name} style={S.miniAvatarImg} />
    : <div style={{ ...S.miniAvatar, background: dc.grad }} title={profile.name}>{initials}</div>;
}

function SectionLabel({ children, style }) {
  return <p style={{ ...S.sectionLabel, ...style }}>{children}</p>;
}

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { marginBottom: 28 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  empty: { textAlign: "center", padding: "60px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  sectionLabel: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: T.muted, marginBottom: 14 },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 16 },
  card: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm },
  cardStrip: { height: 6 },
  cardBody: { padding: "18px 20px 20px" },
  cardTopRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  discPill: { fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: T.rPill },
  memberBadge: { display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700, color: T.primary, background: "#EDE9FE", padding: "3px 10px", borderRadius: T.rPill },
  eventName: { fontSize: 15, fontWeight: 700, color: T.dark, margin: "0 0 14px", lineHeight: 1.35 },
  avatarRow: { display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 10, alignItems: "center" },
  miniAvatar: { width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#fff" },
  miniAvatarImg: { width: 30, height: 30, borderRadius: "50%", objectFit: "cover", border: `2px solid ${T.border}` },
  morePill: { width: 30, height: 30, borderRadius: "50%", background: T.bg, color: T.muted, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 },
  emptyLabel: { fontSize: 12, color: T.muted, fontStyle: "italic" },
  memberCount: { fontSize: 13, color: T.muted, margin: 0 },
  hint: { marginTop: 32, textAlign: "center", fontSize: 13, color: "#C4B5FD", fontStyle: "italic" },
};
