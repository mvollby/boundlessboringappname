import { useState, useEffect } from "react";
import { forumMembershipStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import ForumView from "./ForumView";

// ── Hardcoded Boundless Featured Events ───────────────────────────────────────
const BOUNDLESS_EVENTS = [
  { name: "Leadville Trail 100 Run",          discipline: "Runner",     desc: "The Race Across the Sky — 100 miles at altitude" },
  { name: "Leadville Trail 100 Mountain Bike", discipline: "Cyclist",    desc: "Epic MTB race through Colorado high country" },
  { name: "UNBOUND Gravel",                   discipline: "Cyclist",    desc: "200 miles of gravel across the Flint Hills" },
  { name: "Big Sugar",                        discipline: "Cyclist",    desc: "Gravel race through the Ozarks of Arkansas" },
  { name: "SPT GRVL",                         discipline: "Multisport", desc: "Multi-discipline gravel and endurance event" },
];

export default function Events({ myProfile, allProfiles, currentUser, onNavigateToMessages }) {
  const [activeForumEvent, setActiveForumEvent] = useState(null);
  const [forumJoined, setForumJoined] = useState([]);
  const [joiningKey, setJoiningKey] = useState(null); // loading state

  useEffect(() => {
    setForumJoined(forumMembershipStorage.getJoined(currentUser.id));
  }, [currentUser.id]);

  const handleDMRequest = () => {
    setActiveForumEvent(null);
    onNavigateToMessages?.();
  };

  const handleJoin = (eventName) => {
    const key = toKey(eventName);
    setJoiningKey(key);
    forumMembershipStorage.join(currentUser.id, key);
    const updated = forumMembershipStorage.getJoined(currentUser.id);
    setForumJoined(updated);
    setJoiningKey(null);
    setActiveForumEvent(eventName);
  };

  const handleOpenForum = (eventName) => {
    setActiveForumEvent(eventName);
  };

  if (activeForumEvent) {
    return (
      <ForumView
        event={activeForumEvent}
        myProfile={myProfile}
        currentUser={currentUser}
        allProfiles={allProfiles}
        onClose={() => setActiveForumEvent(null)}
        onDMRequest={handleDMRequest}
      />
    );
  }

  // Build the set of all live events across all profiles
  const allLiveEventMap = {};
  allProfiles.forEach((p) => {
    (p.events || []).forEach((ev) => {
      if (!allLiveEventMap[ev]) allLiveEventMap[ev] = { members: [], discipline: p.discipline };
      allLiveEventMap[ev].members.push(p);
    });
  });

  // My joined events = profile events + forum-joined events
  const myProfileEvents = new Set(myProfile.events || []);
  const myForumJoinedSet = new Set(forumJoined.map((k) => fromKey(k, allLiveEventMap)));

  // "Live Events" = events in my profile OR events I joined via forum
  const myLiveEvents = [
    // Profile events (with member data from allLiveEventMap)
    ...(myProfile.events || []).map((ev) => ({
      name: ev,
      members: (allLiveEventMap[ev]?.members || []),
      discipline: allLiveEventMap[ev]?.discipline || myProfile.discipline,
      fromProfile: true,
    })),
    // Forum-joined events not already in profile
    ...forumJoined
      .map((k) => {
        // k is a slug like "leadville_trail_100_run" — find original name
        const match = findEventByKey(k, allLiveEventMap);
        if (!match || myProfileEvents.has(match.name)) return null;
        return { name: match.name, members: match.members, discipline: match.discipline, fromForum: true };
      })
      .filter(Boolean),
  ];

  // "Other Live Events" = events other athletes have that aren't in myLiveEvents
  const myLiveEventNames = new Set(myLiveEvents.map((e) => e.name));

  const otherLiveEvents = Object.entries(allLiveEventMap)
    .filter(([ev]) => !myLiveEventNames.has(ev))
    .map(([ev, data]) => ({ name: ev, ...data }))
    .sort((a, b) => b.members.length - a.members.length);

  return (
    <div style={S.root}>
      {/* ── Tier 1: Boundless Events ── */}
      <SectionHeader
        title="Boundless Events"
        sub="Flagship races curated by the Boundless team"
        badge="Featured"
      />
      <div style={S.grid}>
        {BOUNDLESS_EVENTS.map((ev) => {
          const key      = toKey(ev.name);
          const isJoined = forumJoined.includes(key) || myProfileEvents.has(ev.name);
          const liveData = allLiveEventMap[ev.name];
          const members  = liveData?.members || [];
          return (
            <BoundlessEventCard
              key={ev.name}
              event={ev}
              members={members}
              isJoined={isJoined}
              loading={joiningKey === key}
              onOpen={() => handleOpenForum(ev.name)}
              onJoin={() => handleJoin(ev.name)}
            />
          );
        })}
      </div>

      {/* ── Tier 2: My Live Events ── */}
      <div style={S.divider} />
      <SectionHeader
        title="Live Events"
        sub="Events you're actively part of"
      />
      {myLiveEvents.length === 0 ? (
        <div style={S.emptyTier}>
          <Icon.Flag style={{ width: 28, height: 28, color: T.border, display: "block", margin: "0 auto 10px" }} />
          <p style={{ color: T.muted, margin: 0 }}>No live events yet — add races under My Profile or join an event below.</p>
        </div>
      ) : (
        <div style={S.grid}>
          {myLiveEvents.map((ev) => (
            <LiveEventCard
              key={ev.name}
              event={ev}
              onOpen={() => handleOpenForum(ev.name)}
            />
          ))}
        </div>
      )}

      {/* ── Tier 3: Other Live Events ── */}
      <div style={S.divider} />
      <SectionHeader
        title="Other Live Events"
        sub="Join an event's chat — won't change your profile"
      />
      {otherLiveEvents.length === 0 ? (
        <div style={S.emptyTier}>
          <p style={{ color: T.muted, margin: 0 }}>No other active events right now.</p>
        </div>
      ) : (
        <div style={S.grid}>
          {otherLiveEvents.map((ev) => {
            const key     = toKey(ev.name);
            const loading = joiningKey === key;
            return (
              <OtherEventCard
                key={ev.name}
                event={ev}
                loading={loading}
                onJoin={() => handleJoin(ev.name)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function toKey(name) {
  return name.replace(/\s+/g, "_").toLowerCase();
}
function fromKey(k, map) {
  return Object.entries(map).find(([ev]) => toKey(ev) === k)?.[0] ? { name: Object.entries(map).find(([ev]) => toKey(ev) === k)[0], ...Object.entries(map).find(([ev]) => toKey(ev) === k)[1] } : null;
}
function findEventByKey(k, map) {
  const entry = Object.entries(map).find(([ev]) => toKey(ev) === k);
  if (!entry) return null;
  return { name: entry[0], ...entry[1] };
}

// ── Sub-components ────────────────────────────────────────────────────────────

function SectionHeader({ title, sub, badge }) {
  return (
    <div style={S.sectionHeader}>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 3 }}>
          <h2 style={S.sectionTitle}>{title}</h2>
          {badge && <span style={S.featuredBadge}>{badge}</span>}
        </div>
        <p style={S.sectionSub}>{sub}</p>
      </div>
    </div>
  );
}

function BoundlessEventCard({ event, members, isJoined, loading, onOpen, onJoin }) {
  const dc = T.disc[event.discipline] || T.disc.Runner;
  return (
    <div style={{ ...S.card, border: isJoined ? `2px solid ${T.primary}` : `1.5px solid ${T.border}` }}>
      <div style={{ ...S.cardStrip, background: dc.grad }} />
      <div style={S.cardBody}>
        <div style={S.cardTopRow}>
          <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{event.discipline}</span>
          {isJoined && <span style={S.memberBadge}><Icon.Check style={{ width: 10, height: 10 }} /> Joined</span>}
        </div>
        <h4 style={S.eventName}>{event.name}</h4>
        <p style={S.eventDesc}>{event.desc}</p>
        {members.length > 0 && (
          <div style={S.avatarRow}>
            {members.slice(0, 5).map((p) => <MiniAvatar key={p.userId} profile={p} />)}
            {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
          </div>
        )}
        <div style={S.cardFooter}>
          <p style={S.memberCount}><strong>{members.length}</strong> athlete{members.length !== 1 ? "s" : ""}</p>
          <button style={S.forumBtn} onClick={isJoined ? onOpen : onJoin} disabled={loading}>
            {loading ? "Joining…" : isJoined ? <>Open Forum <Icon.ChevronRight style={{ width: 13, height: 13 }} /></> : "Join Forum"}
          </button>
        </div>
      </div>
    </div>
  );
}

function LiveEventCard({ event, onOpen }) {
  const dc = T.disc[event.discipline] || T.disc.Runner;
  const members = event.members || [];
  return (
    <div style={{ ...S.card, border: `2px solid ${T.primary}` }}>
      <div style={{ ...S.cardStrip, background: dc.grad }} />
      <div style={S.cardBody}>
        <div style={S.cardTopRow}>
          <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{event.discipline || "Event"}</span>
          <span style={S.memberBadge}><Icon.Check style={{ width: 10, height: 10 }} /> {event.fromForum ? "Forum joined" : "In your profile"}</span>
        </div>
        <h4 style={S.eventName}>{event.name}</h4>
        {members.length > 0 && (
          <div style={S.avatarRow}>
            {members.slice(0, 5).map((p) => <MiniAvatar key={p.userId} profile={p} />)}
            {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
          </div>
        )}
        <div style={S.cardFooter}>
          <p style={S.memberCount}><strong>{members.length}</strong> athlete{members.length !== 1 ? "s" : ""}</p>
          <button style={S.forumBtn} onClick={onOpen}>
            Open Forum <Icon.ChevronRight style={{ width: 13, height: 13 }} />
          </button>
        </div>
      </div>
    </div>
  );
}

function OtherEventCard({ event, loading, onJoin }) {
  const dc = T.disc[event.discipline] || T.disc.Runner;
  const members = event.members || [];
  return (
    <div style={{ ...S.card, border: `1.5px solid ${T.border}`, opacity: 0.9 }}>
      <div style={{ ...S.cardStrip, background: dc.grad }} />
      <div style={S.cardBody}>
        <div style={S.cardTopRow}>
          <span style={{ ...S.discPill, background: dc.bg, color: dc.color }}>{event.discipline}</span>
        </div>
        <h4 style={S.eventName}>{event.name}</h4>
        {members.length > 0 && (
          <div style={S.avatarRow}>
            {members.slice(0, 5).map((p) => <MiniAvatar key={p.userId} profile={p} />)}
            {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
          </div>
        )}
        <div style={S.cardFooter}>
          <p style={S.memberCount}><strong>{members.length}</strong> athlete{members.length !== 1 ? "s" : ""}</p>
          <button style={{ ...S.forumBtn, background: "none", color: T.primary, border: `1.5px solid ${T.primary}`, boxShadow: "none" }}
            onClick={onJoin} disabled={loading}>
            {loading ? "Joining…" : "Join Forum"}
          </button>
        </div>
      </div>
    </div>
  );
}

function MiniAvatar({ profile }) {
  const dc       = T.disc[profile.discipline] || T.disc.Runner;
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt="" title={profile.name} style={S.miniAvatarImg} />
    : <div style={{ ...S.miniAvatar, background: dc.grad }} title={profile.name}>{initials}</div>;
}

const S = {
  root: { paddingBottom: 60 },
  sectionHeader: { marginBottom: 16 },
  sectionTitle: { fontSize: 20, fontWeight: 800, margin: 0, color: T.dark },
  sectionSub: { fontSize: 13, color: T.muted, margin: 0 },
  featuredBadge: { fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.06em", background: T.grad, color: "#fff", padding: "3px 10px", borderRadius: T.rPill },
  divider: { height: 1, background: T.border, margin: "36px 0 28px" },

  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 16, marginBottom: 8 },
  card: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm },
  cardStrip: { height: 6 },
  cardBody: { padding: "18px 20px 20px" },
  cardTopRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  discPill: { fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: T.rPill },
  memberBadge: { display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700, color: T.primary, background: "#EDE9FE", padding: "3px 10px", borderRadius: T.rPill },
  eventName: { fontSize: 15, fontWeight: 700, color: T.dark, margin: "0 0 6px", lineHeight: 1.35 },
  eventDesc: { fontSize: 12, color: T.muted, margin: "0 0 12px", lineHeight: 1.45 },
  avatarRow: { display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12, alignItems: "center" },
  miniAvatar: { width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "#fff" },
  miniAvatarImg: { width: 28, height: 28, borderRadius: "50%", objectFit: "cover", border: `2px solid ${T.border}` },
  morePill: { width: 28, height: 28, borderRadius: "50%", background: T.bg, color: T.muted, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 },
  cardFooter: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  memberCount: { fontSize: 12, color: T.muted, margin: 0 },
  forumBtn: { display: "flex", alignItems: "center", gap: 4, background: T.grad, color: "#fff", border: "none", borderRadius: T.rPill, padding: "7px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer" },

  emptyTier: { textAlign: "center", padding: "28px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },
};
