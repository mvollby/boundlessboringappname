import { useState, useEffect } from "react";
import { forumMembershipStorage, eventStorage } from "../utils/storage";
import { eventYear } from "../utils/seed";
import { T } from "../theme";
import { Icon } from "../Icons";
import ForumView from "./ForumView";

const SPORT_FILTERS = ["All", "Running", "MTB", "Gravel"];

const SPORT_THEME = {
  Running: { bg: "#D1FAE5", color: "#065F46", grad: "linear-gradient(135deg,#059669,#10B981)" },
  MTB:     { bg: "#DBEAFE", color: "#1E40AF", grad: "linear-gradient(135deg,#2563EB,#60A5FA)" },
  Gravel:  { bg: "#FEF3C7", color: "#92400E", grad: "linear-gradient(135deg,#D97706,#F59E0B)" },
};

function sportTheme(type) { return SPORT_THEME[type] || SPORT_THEME.Running; }

export default function Events({ myProfile, allProfiles, currentUser, onNavigateToMessages }) {
  const [activeForumEvent, setActiveForumEvent] = useState(null);
  const [forumJoined,      setForumJoined]      = useState([]);
  const [sportFilter,      setSportFilter]      = useState("All");
  const [joiningId,        setJoiningId]        = useState(null);

  const allEvents = eventStorage.getAll();

  useEffect(() => {
    setForumJoined(forumMembershipStorage.getJoined(currentUser.id));
  }, [currentUser.id]);

  const reloadJoined = () => setForumJoined(forumMembershipStorage.getJoined(currentUser.id));

  const handleJoin = (ev) => {
    setJoiningId(ev.id);
    forumMembershipStorage.join(currentUser.id, ev.id);
    reloadJoined();
    setJoiningId(null);
    setActiveForumEvent(ev);
  };

  const handleOpenForum = (ev) => setActiveForumEvent(ev);
  const handleDMRequest = () => { setActiveForumEvent(null); onNavigateToMessages?.(); };

  if (activeForumEvent) {
    return (
      <ForumView
        event={activeForumEvent}
        myProfile={myProfile}
        currentUser={currentUser}
        allProfiles={allProfiles}
        onClose={() => setActiveForumEvent(null)}
        onDMRequest={handleDMRequest}
      />
    );
  }

  // Build member map: eventId → [profile, ...]
  const memberMap = {};
  allProfiles.filter((p) => !p.isAdmin).forEach((p) => {
    (p.events || []).forEach((evId) => {
      if (!memberMap[evId]) memberMap[evId] = [];
      memberMap[evId].push(p);
    });
  });

  const myEventsSet  = new Set(myProfile.events || []);
  const myJoinedSet  = new Set(forumJoined);
  const myLiveIds    = new Set([...myEventsSet, ...myJoinedSet]);

  // ── Tier 1: Featured events ────────────────────────────────────────────────
  const featuredAll    = allEvents.filter((ev) => ev.featured);
  const featuredShown  = sportFilter === "All" ? featuredAll : featuredAll.filter((ev) => ev.sportType === sportFilter);

  // ── Tier 2: My live events ─────────────────────────────────────────────────
  const myLiveEvents = allEvents.filter((ev) => myLiveIds.has(ev.id));

  // ── Tier 3: Other live events (events with any profile member, not mine) ──
  const popularIds    = new Set(Object.keys(memberMap));
  const otherLiveAll  = allEvents.filter((ev) => popularIds.has(ev.id) && !myLiveIds.has(ev.id));
  const otherLiveShown = sportFilter === "All" ? otherLiveAll : otherLiveAll.filter((ev) => ev.sportType === sportFilter);

  return (
    <div style={S.root}>
      {/* Sport type filter */}
      <div style={S.filterRow}>
        {SPORT_FILTERS.map((f) => (
          <button key={f} onClick={() => setSportFilter(f)}
            style={{ ...S.filterChip, ...(sportFilter === f ? S.filterChipActive : {}) }}>
            {f}
          </button>
        ))}
      </div>

      {/* ── Tier 1: Boundless Featured Events ── */}
      <SectionHeader title="Boundless Events" sub="Flagship races curated by the Boundless team" badge="Featured" />
      {featuredShown.length === 0 ? (
        <EmptyTile msg="No featured events match this filter." />
      ) : (
        <div style={S.grid}>
          {featuredShown.map((ev) => {
            const isJoined = myLiveIds.has(ev.id);
            const members  = memberMap[ev.id] || [];
            return (
              <EventCard key={ev.id} ev={ev} members={members} isJoined={isJoined}
                loading={joiningId === ev.id}
                onOpen={() => handleOpenForum(ev)}
                onJoin={() => handleJoin(ev)}
              />
            );
          })}
        </div>
      )}

      {/* ── Tier 2: My Live Events ── */}
      <div style={S.divider} />
      <SectionHeader title="Live Events" sub="Events you're actively part of" />
      {myLiveEvents.length === 0 ? (
        <EmptyTile icon msg="No live events yet — add races under My Profile or join an event below." />
      ) : (
        <div style={S.grid}>
          {myLiveEvents.map((ev) => {
            const members    = memberMap[ev.id] || [];
            const fromForum  = !myEventsSet.has(ev.id);
            return (
              <EventCard key={ev.id} ev={ev} members={members} isJoined joined
                fromForum={fromForum}
                onOpen={() => handleOpenForum(ev)}
              />
            );
          })}
        </div>
      )}

      {/* ── Tier 3: Other Live Events ── */}
      <div style={S.divider} />
      <SectionHeader title="Other Live Events" sub="Join an event's chat — won't change your profile" />
      {otherLiveShown.length === 0 ? (
        <EmptyTile msg="No other active events right now." />
      ) : (
        <div style={S.grid}>
          {otherLiveShown.map((ev) => {
            const members = memberMap[ev.id] || [];
            return (
              <EventCard key={ev.id} ev={ev} members={members} isJoined={false}
                loading={joiningId === ev.id}
                outline
                onJoin={() => handleJoin(ev)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── EventCard ─────────────────────────────────────────────────────────────────
function EventCard({ ev, members, isJoined, joined, fromForum, loading, outline, onOpen, onJoin }) {
  const st      = sportTheme(ev.sportType);
  const year    = eventYear(ev.month);
  return (
    <div style={{ ...S.card, border: (isJoined || joined) ? `2px solid ${T.primary}` : `1.5px solid ${T.border}` }}>
      <div style={{ ...S.cardStrip, background: st.grad }} />
      <div style={S.cardBody}>
        <div style={S.cardTopRow}>
          <span style={{ ...S.sportPill, background: st.bg, color: st.color }}>{ev.sportType}</span>
          {(isJoined || joined) && (
            <span style={S.joinedBadge}>
              <Icon.Check style={{ width: 10, height: 10 }} />
              {fromForum ? "Forum joined" : "In profile"}
            </span>
          )}
        </div>
        <h4 style={S.eventName}>{ev.name}</h4>
        <p style={S.eventMeta}>
          {ev.distance} · {ev.city}, {ev.state} · {ev.month} {year}
        </p>
        {members.length > 0 && (
          <div style={S.avatarRow}>
            {members.slice(0, 5).map((p) => <MiniAvatar key={p.userId} profile={p} />)}
            {members.length > 5 && <div style={S.morePill}>+{members.length - 5}</div>}
          </div>
        )}
        <div style={S.cardFooter}>
          <p style={S.memberCount}><strong>{members.length}</strong> athlete{members.length !== 1 ? "s" : ""}</p>
          {(isJoined || joined)
            ? <button style={S.forumBtn} onClick={onOpen}>Open Forum <Icon.ChevronRight style={{ width: 13, height: 13 }} /></button>
            : outline
              ? <button style={{ ...S.forumBtn, background: "none", color: T.primary, border: `1.5px solid ${T.primary}`, boxShadow: "none" }} onClick={onJoin} disabled={loading}>{loading ? "Joining…" : "Join Forum"}</button>
              : <button style={S.forumBtn} onClick={onJoin} disabled={loading}>{loading ? "Joining…" : "Join Forum"}</button>
          }
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title, sub, badge }) {
  return (
    <div style={S.sectionHeader}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 3 }}>
        <h2 style={S.sectionTitle}>{title}</h2>
        {badge && <span style={S.featuredBadge}>{badge}</span>}
      </div>
      <p style={S.sectionSub}>{sub}</p>
    </div>
  );
}

function EmptyTile({ msg, icon }) {
  return (
    <div style={S.emptyTier}>
      {icon && <Icon.Flag style={{ width: 28, height: 28, color: T.border, display: "block", margin: "0 auto 10px" }} />}
      <p style={{ color: T.muted, margin: 0 }}>{msg}</p>
    </div>
  );
}

function MiniAvatar({ profile }) {
  const dc       = T.disc[profile.discipline] || T.disc.Runner;
  const initials = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return profile.photoUrl
    ? <img src={profile.photoUrl} alt="" title={profile.name} style={S.miniAvatarImg} />
    : <div style={{ ...S.miniAvatar, background: dc.grad }} title={profile.name}>{initials}</div>;
}

const S = {
  root: { paddingBottom: 60 },
  filterRow: { display: "flex", gap: 6, marginBottom: 28 },
  filterChip: { padding: "7px 18px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 13, fontWeight: 600, color: T.muted, cursor: "pointer" },
  filterChipActive: { background: T.grad, color: "#fff", border: "1.5px solid transparent", boxShadow: "0 2px 8px rgba(124,58,237,0.25)" },

  sectionHeader: { marginBottom: 16 },
  sectionTitle: { fontSize: 20, fontWeight: 800, margin: 0, color: T.dark },
  sectionSub: { fontSize: 13, color: T.muted, margin: 0 },
  featuredBadge: { fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.06em", background: T.grad, color: "#fff", padding: "3px 10px", borderRadius: T.rPill },
  divider: { height: 1, background: T.border, margin: "36px 0 28px" },

  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 16, marginBottom: 8 },
  card: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm },
  cardStrip: { height: 6 },
  cardBody: { padding: "18px 20px 20px" },
  cardTopRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  sportPill: { fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: T.rPill },
  joinedBadge: { display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700, color: T.primary, background: "#EDE9FE", padding: "3px 10px", borderRadius: T.rPill },
  eventName: { fontSize: 15, fontWeight: 700, color: T.dark, margin: "0 0 4px", lineHeight: 1.35 },
  eventMeta: { fontSize: 12, color: T.muted, margin: "0 0 12px" },
  avatarRow: { display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12, alignItems: "center" },
  miniAvatar: { width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "#fff" },
  miniAvatarImg: { width: 28, height: 28, borderRadius: "50%", objectFit: "cover", border: `2px solid ${T.border}` },
  morePill: { width: 28, height: 28, borderRadius: "50%", background: T.bg, color: T.muted, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 },
  cardFooter: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  memberCount: { fontSize: 12, color: T.muted, margin: 0 },
  forumBtn: { display: "flex", alignItems: "center", gap: 4, background: T.grad, color: "#fff", border: "none", borderRadius: T.rPill, padding: "7px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer" },
  emptyTier: { textAlign: "center", padding: "28px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },
};
