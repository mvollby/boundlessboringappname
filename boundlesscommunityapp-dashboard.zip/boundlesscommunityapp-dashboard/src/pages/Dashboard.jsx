// Placeholder home for non-admin athletes once they log in.
// Expand this with personal profile, upcoming events, etc.
export default function Dashboard({ user, onLogout }) {
  return (
    <div style={S.root}>
      <header style={S.header}>
        <div style={S.inner}>
          <div style={S.logo}>
            <span style={S.icon}>🏃</span>
            <h1 style={S.title}>Boundless Community</h1>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <span style={S.userBadge}>👤 {user.name}</span>
            <button onClick={onLogout} style={S.btnLogout}>Sign out</button>
          </div>
        </div>
      </header>
      <main style={S.main}>
        <div style={S.card}>
          <h2 style={S.heading}>Welcome, {user.name}! 👋</h2>
          <p style={S.body}>
            Your athlete dashboard is coming soon. This is where you'll see your upcoming races,
            training schedule, and community updates.
          </p>
          {!user.isAdmin && (
            <p style={S.note}>
              Admin access is required to view the full Athlete Database. Contact your administrator
              to have your account upgraded.
            </p>
          )}
        </div>
      </main>
    </div>
  );
}

const S = {
  root: { fontFamily: "'Inter',-apple-system,sans-serif", minHeight: "100vh", background: "#f6f7f9" },
  header: { background: "linear-gradient(135deg,#1a1a2e,#16213e)", color: "#fff", padding: "20px 0" },
  inner: { maxWidth: 1200, margin: "0 auto", padding: "0 20px", display: "flex", justifyContent: "space-between", alignItems: "center" },
  logo: { display: "flex", alignItems: "center", gap: 12 },
  icon: { fontSize: 28 },
  title: { margin: 0, fontSize: 22, fontWeight: 700, letterSpacing: "-0.02em" },
  userBadge: { fontSize: 13, color: "rgba(255,255,255,0.7)" },
  btnLogout: { background: "transparent", color: "rgba(255,255,255,0.7)", border: "1px solid rgba(255,255,255,0.3)", borderRadius: 8, padding: "6px 12px", fontSize: 13, cursor: "pointer" },
  main: { maxWidth: 800, margin: "40px auto", padding: "0 20px" },
  card: { background: "#fff", borderRadius: 16, padding: 36, boxShadow: "0 2px 12px rgba(0,0,0,0.06)" },
  heading: { fontSize: 22, fontWeight: 700, marginBottom: 12, color: "#1a1a2e" },
  body: { fontSize: 15, color: "#555", lineHeight: 1.6 },
  note: { marginTop: 16, fontSize: 13, color: "#888", fontStyle: "italic", padding: "12px 16px", background: "#f8f8f8", borderRadius: 8, borderLeft: "3px solid #ddd" },
};
