import { useState, useEffect, useRef } from "react";
import { conversationStorage, eventStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import Avatar from "../components/Avatar";

function resolveNames(ids) {
  const all = eventStorage.getAll();
  return (ids || []).map((id) => all.find((e) => e.id === id)?.name).filter(Boolean);
}

export default function Messages({ currentUser, allProfiles }) {
  const [convs,        setConvs]        = useState([]);
  const [openConv,     setOpenConv]     = useState(null);
  const [draft,        setDraft]        = useState("");
  // viewedProfile: { profile, name, conv, mode: "request"|"view" }
  const [viewedProfile, setViewedProfile] = useState(null);
  const bottomRef = useRef();

  const reload = () => setConvs(conversationStorage.forUser(currentUser.id).filter((c) => c.status !== "declined"));

  useEffect(() => { reload(); }, [currentUser.id]);
  useEffect(() => {
    if (openConv) setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  }, [openConv]);

  const requests = convs.filter((c) => c.status === "pending" && c.initiatorId !== currentUser.id);
  const active   = convs.filter((c) => c.status === "active").sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

  const getOtherProfile = (conv) => {
    const otherId = conv.participants.find((p) => p !== currentUser.id);
    return allProfiles?.find((p) => p.userId === otherId);
  };

  const getOtherName = (conv) => {
    const p = getOtherProfile(conv);
    return p ? p.name : (conv.initiatorId === currentUser.id ? "Them" : conv.initiatorName);
  };

  const getMyProfile = () => allProfiles?.find((p) => p.userId === currentUser.id);

  const handleAccept  = (convId) => { conversationStorage.accept(convId);  setViewedProfile(null); reload(); };
  const handleDecline = (convId) => { conversationStorage.decline(convId); setViewedProfile(null); reload(); };

  const handleSend = () => {
    if (!draft.trim() || !openConv) return;
    conversationStorage.addMessage(openConv.id, { fromUserId: currentUser.id, fromName: currentUser.name, text: draft.trim() });
    setDraft("");
    const updated = conversationStorage.getAll().find((c) => c.id === openConv.id);
    setOpenConv(updated);
    reload();
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  const openChat = (conv) => {
    const fresh = conversationStorage.getAll().find((c) => c.id === conv.id);
    setOpenConv(fresh || conv);
  };

  // Open profile sheet helper
  const viewProfile = (profile, name, conv, mode = "view") => {
    setViewedProfile({ profile, name, conv, mode });
  };

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <h2 style={S.title}>
          Messages
          {requests.length > 0 && <span style={S.badge}>{requests.length} new</span>}
        </h2>
        <p style={S.sub}>Direct messages and connection requests.</p>
      </div>

      {requests.length === 0 && active.length === 0 && (
        <div style={S.empty}>
          <Icon.Mail style={{ width: 44, height: 44, color: T.border, display: "block", margin: "0 auto 16px" }} />
          <p style={{ color: T.muted, fontWeight: 600, fontSize: 15 }}>No messages yet</p>
          <p style={{ color: T.muted, fontSize: 13, marginTop: 6 }}>Connect with athletes in the Communities tab to start a conversation.</p>
        </div>
      )}

      {/* ── Pending requests ── */}
      {requests.length > 0 && (
        <div style={S.section}>
          <p style={S.sectionLabel}>Connection Requests</p>
          <div style={S.list}>
            {requests.map((conv) => {
              const op   = getOtherProfile(conv);
              const name = getOtherName(conv);
              return (
                <div key={conv.id} style={S.requestRow}>
                  {/* Clickable avatar */}
                  <div style={S.avatarBtn} onClick={() => viewProfile(op, name, conv, "request")}>
                    <ConvAvatar name={name} profile={op} size={44} />
                  </div>
                  <div style={S.rowBody}>
                    <span style={S.rowNameLink} onClick={() => viewProfile(op, name, conv, "request")}>
                      {name}
                    </span>
                    <div style={S.rowNote}>{conv.note}</div>
                  </div>
                  <div style={S.requestActions}>
                    <button style={S.btnAccept}  onClick={() => handleAccept(conv.id)}>Accept</button>
                    <button style={S.btnDecline} onClick={() => handleDecline(conv.id)}>Decline</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Active conversations ── */}
      {active.length > 0 && (
        <div style={S.section}>
          <p style={S.sectionLabel}>Conversations</p>
          <div style={S.list}>
            {active.map((conv) => {
              const op   = getOtherProfile(conv);
              const name = getOtherName(conv);
              const last = conv.messages[conv.messages.length - 1];
              return (
                <div key={conv.id} style={S.convoRow} onClick={() => openChat(conv)}>
                  {/* Clickable avatar — stops row click */}
                  <div style={S.avatarBtn} onClick={(e) => { e.stopPropagation(); viewProfile(op, name, conv, "view"); }}>
                    <ConvAvatar name={name} profile={op} size={44} />
                  </div>
                  <div style={S.rowBody}>
                    {/* Clickable name — stops row click */}
                    <div style={S.rowNameLink}
                      onClick={(e) => { e.stopPropagation(); viewProfile(op, name, conv, "view"); }}>
                      {name}
                    </div>
                    <div style={S.rowPreview}>
                      {last ? `${last.fromUserId === currentUser.id ? "You" : last.fromName}: ${last.text}` : "Say hello!"}
                    </div>
                  </div>
                  <Icon.ChevronRight style={{ width: 16, height: 16, color: T.border }} />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Profile sheet ── renders above chat (zIndex 200 > chat's 100) */}
      {viewedProfile && (
        <div style={{ ...S.overlay, zIndex: 200 }} onClick={() => setViewedProfile(null)}>
          <div style={S.profileModal} onClick={(e) => e.stopPropagation()}>
            <button style={S.sheetClose} onClick={() => setViewedProfile(null)}>
              <Icon.X style={{ width: 18, height: 18 }} />
            </button>
            <ProfileSheet
              name={viewedProfile.name}
              profile={viewedProfile.profile}
              conv={viewedProfile.conv}
              mode={viewedProfile.mode}
              onAccept={handleAccept}
              onDecline={handleDecline}
              onOpenChat={(conv) => { setViewedProfile(null); openChat(conv); }}
            />
          </div>
        </div>
      )}

      {/* ── Chat modal ── */}
      {openConv && (
        <div style={S.overlay} onClick={() => setOpenConv(null)}>
          <div style={S.chatModal} onClick={(e) => e.stopPropagation()}>
            {/* Chat header — clicking avatar/name opens profile */}
            <div style={S.chatHeader}>
              <div style={S.avatarBtn}
                onClick={(e) => {
                  e.stopPropagation();
                  const op   = getOtherProfile(openConv);
                  const name = getOtherName(openConv);
                  viewProfile(op, name, openConv, "view");
                }}>
                <ConvAvatar name={getOtherName(openConv)} profile={getOtherProfile(openConv)} size={36} />
              </div>
              <span style={{ ...S.chatTitle, cursor: "pointer" }}
                onClick={(e) => {
                  e.stopPropagation();
                  const op   = getOtherProfile(openConv);
                  const name = getOtherName(openConv);
                  viewProfile(op, name, openConv, "view");
                }}>
                {getOtherName(openConv)}
              </span>
              <button style={S.chatClose} onClick={() => setOpenConv(null)}>
                <Icon.X style={{ width: 18, height: 18 }} />
              </button>
            </div>

            {/* Chat body */}
            <div style={S.chatBody}>
              {openConv.messages.length === 0 && (
                <p style={S.chatEmpty}>No messages yet — say hello!</p>
              )}
              {openConv.messages.map((msg) => {
                const mine       = msg.fromUserId === currentUser.id;
                const msgProfile = mine ? getMyProfile() : getOtherProfile(openConv);
                const msgName    = mine ? currentUser.name : getOtherName(openConv);
                return (
                  <div key={msg.id} style={{ ...S.bubbleRow, ...(mine ? S.bubbleRowMine : {}) }}>
                    {/* Other person's avatar — clickable */}
                    {!mine && (
                      <div style={S.avatarBtn}
                        onClick={(e) => {
                          e.stopPropagation();
                          viewProfile(msgProfile, msgName, openConv, "view");
                        }}>
                        <ConvAvatar name={msgName} profile={msgProfile} size={30} />
                      </div>
                    )}
                    <div style={{ ...S.bubble, ...(mine ? S.bubbleMine : S.bubbleTheirs) }}>
                      {!mine && (
                        <div style={{ ...S.bubbleSender, cursor: "pointer" }}
                          onClick={(e) => {
                            e.stopPropagation();
                            viewProfile(msgProfile, msgName, openConv, "view");
                          }}>
                          {msgName}
                        </div>
                      )}
                      <div style={mine ? S.bubbleTextMine : S.bubbleText}>{msg.text}</div>
                      <div style={S.bubbleTime}>
                        {new Date(msg.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                    {/* My avatar — not clickable (it's your own profile) */}
                    {mine && <ConvAvatar name={currentUser.name} profile={getMyProfile()} size={30} />}
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>

            <div style={S.chatInput}>
              <input style={S.chatInputField} placeholder="Type a message…"
                value={draft} onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()} />
              <button style={S.sendBtn} onClick={handleSend} disabled={!draft.trim()}>
                <Icon.ChevronRight style={{ width: 18, height: 18 }} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Profile sheet — handles both "request" and "view" modes ──────────────────
function ProfileSheet({ name, profile, conv, mode, onAccept, onDecline, onOpenChat }) {
  const dc      = T.disc[profile?.discipline] || T.disc.Runner;
  const evNames = resolveNames(profile?.events);
  return (
    <div style={{ textAlign: "center" }}>
      <ConvAvatar name={name} profile={profile} size={72} style={{ margin: "0 auto 14px" }} />
      <h3 style={{ fontSize: 20, fontWeight: 800, color: T.dark, margin: "0 0 6px" }}>{name}</h3>

      {profile?.discipline && (
        <span style={{ display: "inline-block", padding: "3px 14px", borderRadius: T.rPill, fontSize: 11, fontWeight: 700, background: dc.bg, color: dc.color, marginBottom: 14 }}>
          {profile.discipline}
        </span>
      )}

      {(profile?.location || evNames.length > 0 || profile?.coach) && (
        <div style={S2.metaBox}>
          {profile?.location && <ProfileRow icon={<Icon.MapPin style={{ width: 13, height: 13, color: T.muted }} />} text={profile.location} />}
          {evNames.length > 0   && <ProfileRow icon={<Icon.Flag  style={{ width: 13, height: 13, color: T.primary }} />} text={evNames.join(", ")} />}
          {profile?.coach       && <ProfileRow icon={<Icon.Star  style={{ width: 13, height: 13, color: T.amber }} />}   text={`Coach: ${profile.coach}`} />}
        </div>
      )}

      {profile?.goals?.length > 0 && (
        <div style={{ marginBottom: 14, textAlign: "left" }}>
          <p style={S2.goalsLabel}>Goals</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {profile.goals.map((g) => (
              <span key={g} style={S2.goalChip}>{g}</span>
            ))}
          </div>
        </div>
      )}

      {profile?.bio && (
        <p style={{ fontSize: 13, color: T.muted, lineHeight: 1.55, marginBottom: 16, textAlign: "left" }}>{profile.bio}</p>
      )}

      {/* Request note */}
      {mode === "request" && conv?.note && (
        <div style={S2.noteBox}>"{conv.note}"</div>
      )}

      {/* Footer actions */}
      {mode === "request" && conv && (
        <div style={{ display: "flex", gap: 10 }}>
          <button style={S.btnDecline} onClick={() => onDecline(conv.id)}>Decline</button>
          <button style={{ ...S.btnAccept, flex: 1 }} onClick={() => onAccept(conv.id)}>Accept Request</button>
        </div>
      )}
      {mode === "view" && conv && (
        <button style={S2.btnOpenChat} onClick={() => onOpenChat(conv)}>
          <Icon.Mail style={{ width: 14, height: 14 }} /> Open Conversation
        </button>
      )}
    </div>
  );
}

function ProfileRow({ icon, text }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: T.dark }}>{icon}<span>{text}</span></div>;
}

function ConvAvatar({ name, profile, size = 44, style }) {
  return <Avatar photoUrl={profile?.photoUrl} name={name} discipline={profile?.discipline} size={size} style={style} />;
}

const S2 = {
  metaBox:   { background: T.bg, borderRadius: T.r, padding: "12px 16px", marginBottom: 14, textAlign: "left", display: "flex", flexDirection: "column", gap: 6 },
  goalsLabel:{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: T.muted, margin: "0 0 7px" },
  goalChip:  { background: "#EDE9FE", color: T.primary, borderRadius: T.rPill, padding: "4px 12px", fontSize: 12, fontWeight: 600 },
  noteBox:   { background: "#EDE9FE", borderRadius: T.r, padding: "10px 14px", fontSize: 13, color: T.dark, fontStyle: "italic", marginBottom: 16, textAlign: "left" },
  btnOpenChat:{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "13px", fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 14px rgba(124,58,237,0.28)" },
};

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { marginBottom: 28 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark, display: "flex", alignItems: "center", gap: 12 },
  badge: { background: T.grad, color: "#fff", borderRadius: T.rPill, padding: "3px 12px", fontSize: 12, fontWeight: 700 },
  sub:   { fontSize: 14, color: T.muted, margin: 0 },
  empty: { textAlign: "center", padding: "64px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },

  section:      { marginBottom: 28 },
  sectionLabel: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: T.muted, marginBottom: 10 },
  list:         { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },

  requestRow:    { display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", borderBottom: `1px solid ${T.border}`, background: "#FEFBFF" },
  convoRow:      { display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", borderBottom: `1px solid ${T.border}`, cursor: "pointer", transition: "background 0.1s" },
  avatarBtn:     { cursor: "pointer", flexShrink: 0, display: "flex" },
  rowBody:       { flex: 1, minWidth: 0 },
  rowName:       { fontSize: 14, fontWeight: 700, color: T.dark, marginBottom: 3 },
  rowNameLink:   { fontSize: 14, fontWeight: 700, color: T.primary, cursor: "pointer", textDecoration: "underline", display: "block", marginBottom: 3 },
  rowNote:       { fontSize: 13, color: T.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  rowPreview:    { fontSize: 13, color: T.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  requestActions:{ display: "flex", gap: 8, flexShrink: 0 },
  btnAccept:     { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "8px 16px", fontSize: 13, fontWeight: 700, cursor: "pointer" },
  btnDecline:    { background: T.bg, color: T.muted, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" },

  overlay:      { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100 },
  profileModal: { background: "#fff", borderRadius: `${T.rXL} ${T.rXL} 0 0`, width: "100%", maxWidth: 440, padding: "44px 32px 40px", position: "relative", boxShadow: T.shadowLg, maxHeight: "82vh", overflowY: "auto" },
  sheetClose:   { position: "absolute", top: 14, right: 16, background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4 },

  chatModal:  { background: "#fff", borderRadius: `${T.rXL} ${T.rXL} 0 0`, width: "100%", maxWidth: 520, height: "80vh", display: "flex", flexDirection: "column", boxShadow: T.shadowLg },
  chatHeader: { display: "flex", alignItems: "center", gap: 12, padding: "14px 20px", borderBottom: `1.5px solid ${T.border}`, flexShrink: 0 },
  chatTitle:  { flex: 1, fontSize: 16, fontWeight: 700, color: T.dark },
  chatClose:  { background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4, flexShrink: 0 },
  chatBody:   { flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 10 },
  chatEmpty:  { textAlign: "center", color: T.muted, fontSize: 14, margin: "auto" },

  bubbleRow:      { display: "flex", alignItems: "flex-end", gap: 8 },
  bubbleRowMine:  { flexDirection: "row-reverse" },
  bubble:         { display: "flex", flexDirection: "column", maxWidth: "70%" },
  bubbleMine:     { alignItems: "flex-end" },
  bubbleTheirs:   { alignItems: "flex-start" },
  bubbleSender:   { fontSize: 11, fontWeight: 700, color: T.muted, marginBottom: 2, paddingLeft: 4 },
  bubbleTextMine: { background: T.grad, color: "#fff", borderRadius: "18px 18px 4px 18px", padding: "10px 14px", fontSize: 14, lineHeight: 1.5 },
  bubbleText:     { background: T.bg, color: T.dark, borderRadius: "18px 18px 18px 4px", padding: "10px 14px", fontSize: 14, lineHeight: 1.5 },
  bubbleTime:     { fontSize: 10, color: T.muted, marginTop: 3, padding: "0 4px" },

  chatInput:      { display: "flex", gap: 10, padding: "12px 16px", borderTop: `1.5px solid ${T.border}`, flexShrink: 0 },
  chatInputField: { flex: 1, padding: "11px 16px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: T.fontBase, color: T.dark },
  sendBtn:        { width: 44, height: 44, borderRadius: "50%", background: T.grad, border: "none", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
};
