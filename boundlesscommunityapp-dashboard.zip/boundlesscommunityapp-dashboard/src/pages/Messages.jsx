import { useState, useEffect, useRef } from "react";
import { conversationStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";

export default function Messages({ currentUser, allProfiles }) {
  const [convs,    setConvs]    = useState([]);
  const [openConv, setOpenConv] = useState(null);
  const [draft,    setDraft]    = useState("");
  const bottomRef               = useRef();

  const reload = () => setConvs(conversationStorage.forUser(currentUser.id).filter(c => c.status !== "declined"));

  useEffect(() => { reload(); }, [currentUser.id]);

  // Scroll to bottom when chat opens or new message arrives
  useEffect(() => {
    if (openConv) setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  }, [openConv]);

  const requests = convs.filter((c) => c.status === "pending" && c.initiatorId !== currentUser.id);
  const active   = convs.filter((c) => c.status === "active").sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  const totalNew = requests.length;

  const getOtherProfile = (conv) => {
    const otherId = conv.participants.find((p) => p !== currentUser.id);
    return allProfiles?.find((p) => p.userId === otherId);
  };

  const getOtherName = (conv) => {
    const p = getOtherProfile(conv);
    if (p) return p.name;
    return conv.initiatorId === currentUser.id ? "Them" : conv.initiatorName;
  };

  const handleAccept = (convId) => {
    conversationStorage.accept(convId);
    reload();
  };

  const handleDecline = (convId) => {
    conversationStorage.decline(convId);
    reload();
  };

  const handleSend = () => {
    if (!draft.trim() || !openConv) return;
    conversationStorage.addMessage(openConv.id, {
      fromUserId: currentUser.id,
      fromName: currentUser.name,
      text: draft.trim(),
    });
    setDraft("");
    // Refresh the open conversation
    const updated = conversationStorage.getAll().find((c) => c.id === openConv.id);
    setOpenConv(updated);
    reload();
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  const openChat = (conv) => {
    const fresh = conversationStorage.getAll().find((c) => c.id === conv.id);
    setOpenConv(fresh || conv);
  };

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <h2 style={S.title}>
          Messages
          {totalNew > 0 && <span style={S.badge}>{totalNew} new</span>}
        </h2>
        <p style={S.sub}>Direct messages and connection requests.</p>
      </div>

      {requests.length === 0 && active.length === 0 && (
        <div style={S.empty}>
          <Icon.Mail style={{ width: 44, height: 44, color: T.border, display: "block", margin: "0 auto 16px" }} />
          <p style={{ color: T.muted, fontWeight: 600, fontSize: 15 }}>No messages yet</p>
          <p style={{ color: T.muted, fontSize: 13, marginTop: 6 }}>Connect with athletes in the Communities tab to start a conversation.</p>
        </div>
      )}

      {/* Pending requests */}
      {requests.length > 0 && (
        <div style={S.section}>
          <p style={S.sectionLabel}>Connection Requests</p>
          <div style={S.list}>
            {requests.map((conv) => {
              const otherProfile = getOtherProfile(conv);
              const name = getOtherName(conv);
              return (
                <div key={conv.id} style={S.requestRow}>
                  <ConvAvatar name={name} profile={otherProfile} />
                  <div style={S.rowBody}>
                    <div style={S.rowName}>{name}</div>
                    <div style={S.rowNote}>{conv.note}</div>
                  </div>
                  <div style={S.requestActions}>
                    <button style={S.btnAccept} onClick={() => handleAccept(conv.id)}>Accept</button>
                    <button style={S.btnDecline} onClick={() => handleDecline(conv.id)}>Decline</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Active conversations */}
      {active.length > 0 && (
        <div style={S.section}>
          <p style={S.sectionLabel}>Conversations</p>
          <div style={S.list}>
            {active.map((conv) => {
              const otherProfile = getOtherProfile(conv);
              const name  = getOtherName(conv);
              const last  = conv.messages[conv.messages.length - 1];
              return (
                <div key={conv.id} style={S.convoRow} onClick={() => openChat(conv)}>
                  <ConvAvatar name={name} profile={otherProfile} />
                  <div style={S.rowBody}>
                    <div style={S.rowName}>{name}</div>
                    <div style={S.rowPreview}>{last ? `${last.fromName === currentUser.name ? "You" : last.fromName}: ${last.text}` : "Say hello!"}</div>
                  </div>
                  <Icon.ChevronRight style={{ width: 16, height: 16, color: T.border }} />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Chat modal */}
      {openConv && (
        <div style={S.overlay} onClick={() => setOpenConv(null)}>
          <div style={S.chatModal} onClick={(e) => e.stopPropagation()}>
            {/* Chat header */}
            <div style={S.chatHeader}>
              <ConvAvatar name={getOtherName(openConv)} profile={getOtherProfile(openConv)} size={36} />
              <span style={S.chatTitle}>{getOtherName(openConv)}</span>
              <button style={S.closeBtn} onClick={() => setOpenConv(null)}>
                <Icon.X style={{ width: 18, height: 18 }} />
              </button>
            </div>

            {/* Messages */}
            <div style={S.chatBody}>
              {openConv.messages.length === 0 && (
                <p style={S.chatEmpty}>No messages yet — say hello!</p>
              )}
              {openConv.messages.map((msg) => {
                const mine = msg.fromUserId === currentUser.id;
                return (
                  <div key={msg.id} style={{ ...S.bubble, ...(mine ? S.bubbleMine : S.bubbleTheirs) }}>
                    <div style={{ ...S.bubbleText, ...(mine ? S.bubbleTextMine : {}) }}>{msg.text}</div>
                    <div style={S.bubbleTime}>{new Date(msg.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div style={S.chatInput}>
              <input
                style={S.chatInputField}
                placeholder="Type a message…"
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />
              <button style={S.sendBtn} onClick={handleSend} disabled={!draft.trim()}>
                <Icon.ChevronRight style={{ width: 18, height: 18 }} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ConvAvatar({ name, profile, size = 44 }) {
  const initials = name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  if (profile?.photoUrl) {
    return <img src={profile.photoUrl} alt="" style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover", flexShrink: 0, border: `2px solid ${T.border}` }} />;
  }
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: T.grad, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.3, fontWeight: 800, color: "#fff", flexShrink: 0 }}>
      {initials}
    </div>
  );
}

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { marginBottom: 28 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark, display: "flex", alignItems: "center", gap: 12 },
  badge: { background: T.grad, color: "#fff", borderRadius: T.rPill, padding: "3px 12px", fontSize: 12, fontWeight: 700 },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  empty: { textAlign: "center", padding: "64px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  section: { marginBottom: 28 },
  sectionLabel: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: T.muted, marginBottom: 10 },
  list: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },

  requestRow: { display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", borderBottom: `1px solid ${T.border}`, background: "#FEFBFF" },
  convoRow:   { display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", borderBottom: `1px solid ${T.border}`, cursor: "pointer" },
  rowBody:    { flex: 1, minWidth: 0 },
  rowName:    { fontSize: 14, fontWeight: 700, color: T.dark, marginBottom: 3 },
  rowNote:    { fontSize: 13, color: T.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  rowPreview: { fontSize: 13, color: T.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  requestActions: { display: "flex", gap: 8, flexShrink: 0 },
  btnAccept:  { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "8px 16px", fontSize: 13, fontWeight: 700, cursor: "pointer" },
  btnDecline: { background: T.bg, color: T.muted, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" },

  overlay:   { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100, padding: "0 0 0 0" },
  chatModal: { background: "#fff", borderRadius: `${T.rXL} ${T.rXL} 0 0`, width: "100%", maxWidth: 520, height: "80vh", display: "flex", flexDirection: "column", boxShadow: T.shadowLg },
  chatHeader:{ display: "flex", alignItems: "center", gap: 12, padding: "16px 20px", borderBottom: `1.5px solid ${T.border}` },
  chatTitle: { flex: 1, fontSize: 16, fontWeight: 700, color: T.dark },
  closeBtn:  { background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4 },
  chatBody:  { flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 10 },
  chatEmpty: { textAlign: "center", color: T.muted, fontSize: 14, margin: "auto" },
  bubble:    { display: "flex", flexDirection: "column", maxWidth: "72%" },
  bubbleMine:   { alignSelf: "flex-end", alignItems: "flex-end" },
  bubbleTheirs: { alignSelf: "flex-start", alignItems: "flex-start" },
  bubbleText:   { background: T.bg, color: T.dark, borderRadius: "18px 18px 18px 4px", padding: "10px 14px", fontSize: 14, lineHeight: 1.5 },
  bubbleTextMine: { background: T.grad, color: "#fff", borderRadius: "18px 18px 4px 18px" },
  bubbleTime: { fontSize: 10, color: T.muted, marginTop: 3, padding: "0 4px" },
  chatInput: { display: "flex", gap: 10, padding: "12px 16px", borderTop: `1.5px solid ${T.border}` },
  chatInputField: { flex: 1, padding: "11px 16px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: T.fontBase, color: T.dark },
  sendBtn: { width: 44, height: 44, borderRadius: "50%", background: T.grad, border: "none", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
};
