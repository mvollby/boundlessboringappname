import { useState, useEffect } from "react";
import { messageStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";

export default function Messages({ currentUser }) {
  const [messages, setMessages] = useState([]);
  const [open, setOpen] = useState(null);

  useEffect(() => {
    setMessages(messageStorage.forUser(currentUser.id));
  }, [currentUser.id]);

  const handleOpen = (msg) => {
    if (!msg.read) {
      messageStorage.markRead(msg.id);
      setMessages((prev) => prev.map((m) => m.id === msg.id ? { ...m, read: true } : m));
    }
    setOpen(msg);
  };

  const unread = messages.filter((m) => !m.read).length;
  const sorted = [...messages].reverse();

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>
            Messages
            {unread > 0 && <span style={S.unreadBadge}>{unread} new</span>}
          </h2>
          <p style={S.sub}>When someone connects with you, their contact info lands here.</p>
        </div>
      </div>

      {messages.length === 0 ? (
        <div style={S.empty}>
          <Icon.Mail style={{ width: 44, height: 44, color: T.border, display: "block", margin: "0 auto 16px" }} />
          <p style={{ color: T.muted, fontWeight: 600, fontSize: 15 }}>No messages yet</p>
          <p style={{ color: T.muted, fontSize: 13, marginTop: 6 }}>When another athlete connects with you, their email and phone will appear here.</p>
        </div>
      ) : (
        <div style={S.list}>
          {sorted.map((msg) => (
            <div key={msg.id} style={{ ...S.row, background: msg.read ? "#fff" : "#F5F3FF" }} onClick={() => handleOpen(msg)}>
              <MsgAvatar name={msg.fromName} />
              <div style={S.rowBody}>
                <div style={S.rowTop}>
                  <span style={S.rowName}>{msg.fromName}</span>
                  {!msg.read && <span style={S.dot} />}
                  <span style={S.rowTime}>{new Date(msg.sentAt).toLocaleDateString()}</span>
                </div>
                <div style={S.rowPreview}>{msg.preview?.slice(0, 72)}…</div>
              </div>
              <Icon.ChevronRight style={{ width: 16, height: 16, color: T.border, flexShrink: 0 }} />
            </div>
          ))}
        </div>
      )}

      {/* Open message modal */}
      {open && (
        <div style={S.overlay} onClick={() => setOpen(null)}>
          <div style={S.modal} onClick={(e) => e.stopPropagation()}>
            <button style={S.closeBtn} onClick={() => setOpen(null)}>
              <Icon.X style={{ width: 18, height: 18 }} />
            </button>

            <MsgAvatar name={open.fromName} size={64} style={{ margin: "0 auto 14px" }} />
            <h3 style={S.modalName}>{open.fromName} wants to connect!</h3>
            <p style={S.msgBody}>{open.preview}</p>

            <div style={S.contactCard}>
              <p style={S.contactTitle}>Contact details</p>
              <div style={S.contactRow}>
                <div style={S.contactIcon}><Icon.Mail style={{ width: 14, height: 14 }} /></div>
                <div>
                  <div style={S.contactLabel}>Email</div>
                  <a href={`mailto:${open.fromEmail}`} style={S.contactVal}>{open.fromEmail}</a>
                </div>
              </div>
              {open.fromPhone && (
                <div style={S.contactRow}>
                  <div style={S.contactIcon}><Icon.User style={{ width: 14, height: 14 }} /></div>
                  <div>
                    <div style={S.contactLabel}>Phone</div>
                    <a href={`tel:${open.fromPhone}`} style={S.contactVal}>{open.fromPhone}</a>
                  </div>
                </div>
              )}
            </div>
            <p style={S.hint}>Reach out directly to arrange a meet-up!</p>
          </div>
        </div>
      )}
    </div>
  );
}

function MsgAvatar({ name, size = 44, style }) {
  const initials = name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: T.grad, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.3, fontWeight: 800, color: "#fff", flexShrink: 0, ...style }}>
      {initials}
    </div>
  );
}

const S = {
  root: { paddingBottom: 48 },
  pageHeader: { marginBottom: 28 },
  title: { fontSize: 24, fontWeight: 800, margin: "0 0 4px", color: T.dark, display: "flex", alignItems: "center", gap: 12 },
  unreadBadge: { background: T.grad, color: "#fff", borderRadius: T.rPill, padding: "3px 12px", fontSize: 12, fontWeight: 700 },
  sub: { fontSize: 14, color: T.muted, margin: 0 },
  empty: { textAlign: "center", padding: "64px 20px", background: "#fff", borderRadius: T.rXL, boxShadow: T.shadowSm },
  list: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },
  row: { display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", cursor: "pointer", borderBottom: `1px solid ${T.border}`, transition: "background 0.12s" },
  rowBody: { flex: 1, minWidth: 0 },
  rowTop: { display: "flex", alignItems: "center", gap: 7, marginBottom: 4 },
  rowName: { fontSize: 14, fontWeight: 700, color: T.dark },
  dot: { width: 8, height: 8, borderRadius: "50%", background: T.primary, flexShrink: 0 },
  rowTime: { fontSize: 11, color: T.muted, marginLeft: "auto" },
  rowPreview: { fontSize: 13, color: T.muted, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },

  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 24 },
  modal: { background: "#fff", borderRadius: T.rXL, padding: "40px 32px 32px", maxWidth: 440, width: "100%", position: "relative", textAlign: "center", boxShadow: T.shadowLg },
  closeBtn: { position: "absolute", top: 14, right: 14, background: "none", border: "none", cursor: "pointer", color: T.muted },
  modalName: { fontSize: 20, fontWeight: 800, color: T.dark, margin: "0 0 10px" },
  msgBody: { fontSize: 14, color: T.muted, lineHeight: 1.6, marginBottom: 22 },
  contactCard: { background: T.bg, borderRadius: T.rL, padding: "16px 18px", textAlign: "left", marginBottom: 16 },
  contactTitle: { fontSize: 11, fontWeight: 700, color: T.muted, textTransform: "uppercase", letterSpacing: "0.06em", margin: "0 0 12px" },
  contactRow: { display: "flex", alignItems: "flex-start", gap: 12, padding: "8px 0", borderBottom: `1px solid ${T.border}` },
  contactIcon: { width: 30, height: 30, borderRadius: "50%", background: "#EDE9FE", color: T.primary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  contactLabel: { fontSize: 11, color: T.muted, marginBottom: 2 },
  contactVal: { fontSize: 14, fontWeight: 700, color: T.dark, textDecoration: "none" },
  hint: { fontSize: 12, color: T.muted, fontStyle: "italic" },
};
