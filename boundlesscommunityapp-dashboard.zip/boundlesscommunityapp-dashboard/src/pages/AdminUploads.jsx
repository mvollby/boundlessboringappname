import { useState, useRef } from "react";
import { eventStorage, coachStorage } from "../utils/storage";
import { eventYear } from "../utils/seed";
import { T } from "../theme";
import { Icon } from "../Icons";
import LocationInput from "../components/LocationInput";

const DISTANCES = ["50K","50 Miles","75 Miles","100K","100 Miles","125 Miles","150 Miles","200 Miles","250 Miles","350 Miles","Trail Marathon","Custom"];
const SPORT_TYPES = ["Running","MTB","Gravel"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const EMPTY_EVENT_FORM = { name:"", sportType:"Running", distance:"100 Miles", customDistance:"", month:"June", city:"", state:"", country:"", lat:null, lng:null, photos:[], description:"", featured:false };

export default function AdminUploads() {
  const [section, setSection] = useState("coaches"); // coaches | events | add
  const [coaches, setCoaches] = useState(coachStorage.getAll());
  const [events,  setEvents]  = useState(eventStorage.getAll());

  // Coach state
  const [editCoachId,   setEditCoachId]   = useState(null);
  const [editCoachName, setEditCoachName] = useState("");
  const [newCoachName,  setNewCoachName]  = useState("");

  // Event state
  const [editingEvent, setEditingEvent] = useState(null); // event object being edited
  const [eventForm,    setEventForm]    = useState(EMPTY_EVENT_FORM);

  const reload = () => { setCoaches(coachStorage.getAll()); setEvents(eventStorage.getAll()); };

  // ── Coach actions ────────────────────────────────────────────────────────────
  const addCoach = () => {
    if (!newCoachName.trim()) return;
    coachStorage.add(newCoachName.trim());
    setNewCoachName("");
    reload();
  };
  const saveCoach = (id) => {
    if (!editCoachName.trim()) return;
    coachStorage.update(id, editCoachName.trim());
    setEditCoachId(null);
    reload();
  };
  const deleteCoach = (id) => {
    if (!confirm("Delete this coach?")) return;
    coachStorage.delete(id);
    reload();
  };

  // ── Event actions ─────────────────────────────────────────────────────────────
  const startEdit = (ev) => {
    setEditingEvent(ev);
    setEventForm({ ...EMPTY_EVENT_FORM, ...ev, customDistance: DISTANCES.includes(ev.distance) ? "" : ev.distance, distance: DISTANCES.includes(ev.distance) ? ev.distance : "Custom" });
  };
  const cancelEdit = () => { setEditingEvent(null); };

  const saveEvent = (form) => {
    const dist = form.distance === "Custom" ? (form.customDistance || "Custom") : form.distance;
    const payload = { ...form, distance: dist };
    delete payload.customDistance;
    if (editingEvent) {
      eventStorage.update(editingEvent.id, payload);
    } else {
      eventStorage.add({ ...payload, createdBy: "Admin" });
    }
    setEditingEvent(null);
    setEventForm(EMPTY_EVENT_FORM);
    reload();
    setSection("events");
  };

  const deleteEvent = (id) => {
    if (!confirm("Delete this event?")) return;
    eventStorage.delete(id);
    reload();
  };

  const startAdd = () => {
    setEditingEvent(null);
    setEventForm(EMPTY_EVENT_FORM);
    setSection("add");
  };

  const TABS = [
    { id: "coaches", label: "Coaches" },
    { id: "events",  label: "Events"  },
    { id: "add",     label: "+ Add Event" },
  ];

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <h2 style={S.title}>Uploads</h2>
        <p style={S.sub}>Manage coaches, events, and featured races.</p>
      </div>

      {/* Section tabs */}
      <div style={S.tabRow}>
        {TABS.map((t) => (
          <button key={t.id} onClick={() => { setSection(t.id); if (t.id !== "add") setEditingEvent(null); }}
            style={{ ...S.tab, ...(section === t.id ? S.tabActive : {}) }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Coaches ── */}
      {section === "coaches" && (
        <div style={S.panel}>
          <div style={S.panelHead}>
            <h3 style={S.panelTitle}>Coaches <span style={S.count}>{coaches.length}</span></h3>
          </div>
          <div style={S.coachList}>
            {coaches.sort((a,b) => a.name.localeCompare(b.name)).map((c) => (
              <div key={c.id} style={S.coachRow}>
                {editCoachId === c.id ? (
                  <>
                    <input style={{ ...S.inlineInput, flex: 1 }} value={editCoachName}
                      onChange={(e) => setEditCoachName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && saveCoach(c.id)} autoFocus />
                    <button style={S.btnSm} onClick={() => saveCoach(c.id)}>Save</button>
                    <button style={S.btnSmGhost} onClick={() => setEditCoachId(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    <span style={S.coachName}>{c.name}</span>
                    <button style={S.btnSmGhost} onClick={() => { setEditCoachId(c.id); setEditCoachName(c.name); }}>Edit</button>
                    <button style={S.btnSmDanger} onClick={() => deleteCoach(c.id)}>Delete</button>
                  </>
                )}
              </div>
            ))}
          </div>

          {/* Add new coach */}
          <div style={S.addCoachRow}>
            <input style={{ ...S.inlineInput, flex: 1 }}
              placeholder="Add new coach name…"
              value={newCoachName}
              onChange={(e) => setNewCoachName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addCoach()} />
            <button style={S.btnPri} onClick={addCoach}>Add Coach</button>
          </div>
        </div>
      )}

      {/* ── Events list ── */}
      {section === "events" && (
        <div style={S.panel}>
          <div style={S.panelHead}>
            <h3 style={S.panelTitle}>Events <span style={S.count}>{events.length}</span></h3>
            <button style={S.btnPri} onClick={startAdd}>+ Add Event</button>
          </div>
          {events.length === 0 && <p style={{ color: T.muted, padding: 16 }}>No events yet.</p>}
          <div style={S.eventList}>
            {events.map((ev) => (
              <div key={ev.id} style={S.eventRow}>
                <div style={{ ...S.sportDot, background: sportColor(ev.sportType) }} />
                <div style={S.eventRowInfo}>
                  <div style={S.eventRowName}>{ev.name} {ev.featured && <span style={S.featuredDot}>★</span>}</div>
                  <div style={S.eventRowMeta}>{ev.sportType} · {ev.distance} · {ev.city}, {ev.state} · {ev.month} {eventYear(ev.month)}</div>
                </div>
                <div style={S.eventRowActions}>
                  <button style={S.btnSmGhost} onClick={() => { startEdit(ev); setSection("add"); }}>Edit</button>
                  <button style={S.btnSmDanger} onClick={() => deleteEvent(ev.id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Add / Edit event form ── */}
      {section === "add" && (
        <div style={S.panel}>
          <h3 style={S.panelTitle}>{editingEvent ? `Edit: ${editingEvent.name}` : "Add New Event"}</h3>
          <EventForm
            form={eventForm}
            setForm={setEventForm}
            onSubmit={saveEvent}
            onCancel={() => { setSection("events"); setEditingEvent(null); }}
          />
        </div>
      )}
    </div>
  );
}

// ── Event form component ───────────────────────────────────────────────────────
function EventForm({ form, setForm, onSubmit, onCancel }) {
  const photoRef = useRef();
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleLocationSelect = (item) => {
    if (!item) { setForm((f) => ({ ...f, city: "", state: "", country: "", lat: null, lng: null })); return; }
    setForm((f) => ({ ...f, city: item.city || "", state: item.state || "", country: item.country || "United States", lat: item.lat, lng: item.lng }));
  };

  const handlePhotos = (e) => {
    const files = Array.from(e.target.files).slice(0, 3);
    files.forEach((file) => {
      if (file.size > 5 * 1024 * 1024) return;
      const reader = new FileReader();
      reader.onload = (ev) => setForm((f) => ({ ...f, photos: [...(f.photos || []).slice(0, 2), ev.target.result] }));
      reader.readAsDataURL(file);
    });
  };

  const locationDisplay = [form.city, form.state].filter(Boolean).join(", ");

  return (
    <div style={S.formGrid}>
      <FG label="Event Name">
        <input style={S.input} value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Western States 100" />
      </FG>

      <FG label="Sport Type">
        <div style={S.radioRow}>
          {SPORT_TYPES.map((s) => (
            <label key={s} style={S.radioLabel}>
              <input type="radio" name="sportType" value={s} checked={form.sportType === s} onChange={() => set("sportType", s)} />
              {s}
            </label>
          ))}
        </div>
      </FG>

      <FG label="Distance">
        <select style={S.input} value={form.distance} onChange={(e) => set("distance", e.target.value)}>
          {DISTANCES.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        {form.distance === "Custom" && (
          <input style={{ ...S.input, marginTop: 8 }} placeholder="Enter custom distance…" value={form.customDistance || ""} onChange={(e) => set("customDistance", e.target.value)} />
        )}
      </FG>

      <FG label="Month">
        <select style={S.input} value={form.month} onChange={(e) => set("month", e.target.value)}>
          {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
      </FG>

      <FG label="Location" fullWidth>
        <LocationInput
          value={locationDisplay}
          onSelect={handleLocationSelect}
          placeholder="e.g. Leadville, CO"
          inputStyle={{ background: T.bg }}
        />
        {form.lat && <span style={S.geoTag}>Geocoded · {form.lat.toFixed(3)}, {form.lng.toFixed(3)}</span>}
      </FG>

      <FG label="Description" fullWidth>
        <textarea style={{ ...S.input, minHeight: 80, resize: "vertical" }} value={form.description || ""} onChange={(e) => set("description", e.target.value)} placeholder="Optional race description…" />
      </FG>

      <FG label="Photos (up to 3, max 5MB each)" fullWidth>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <button style={S.btnSmGhost} type="button" onClick={() => photoRef.current.click()}>
            <Icon.Camera style={{ width: 12, height: 12 }} /> Add Photos
          </button>
          {(form.photos || []).map((src, i) => (
            <div key={i} style={{ position: "relative" }}>
              <img src={src} alt="" style={{ width: 60, height: 60, borderRadius: T.r, objectFit: "cover", border: `1.5px solid ${T.border}` }} />
              <button style={S.photoRemove} onClick={() => setForm((f) => ({ ...f, photos: f.photos.filter((_,j) => j !== i) }))}>✕</button>
            </div>
          ))}
          <input ref={photoRef} type="file" accept="image/jpeg,image/png" multiple style={{ display: "none" }} onChange={handlePhotos} />
        </div>
      </FG>

      <FG label="Featured" fullWidth>
        <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
          <input type="checkbox" checked={!!form.featured} onChange={(e) => set("featured", e.target.checked)} style={{ width: 16, height: 16, accentColor: T.primary }} />
          <span style={{ fontSize: 14, color: T.dark }}>Mark as a Boundless Featured Event</span>
        </label>
      </FG>

      <div style={{ gridColumn: "1 / -1", display: "flex", gap: 12, marginTop: 8 }}>
        <button style={S.btnSecFull} onClick={onCancel}>Cancel</button>
        <button style={{ ...S.btnPri, flex: 1 }} onClick={() => form.name.trim() && onSubmit(form)} disabled={!form.name.trim()}>
          Save Event
        </button>
      </div>
    </div>
  );
}

function FG({ label, children, fullWidth }) {
  return (
    <div style={{ gridColumn: fullWidth ? "1 / -1" : undefined, display: "flex", flexDirection: "column", gap: 6 }}>
      <label style={{ fontSize: 12, fontWeight: 700, color: T.muted, textTransform: "uppercase", letterSpacing: "0.04em" }}>{label}</label>
      {children}
    </div>
  );
}

function sportColor(type) {
  if (type === "Running") return "#059669";
  if (type === "MTB")     return "#2563EB";
  if (type === "Gravel")  return "#D97706";
  return T.muted;
}

const S = {
  root: { paddingBottom: 60 },
  pageHeader: { marginBottom: 24 },
  title: { fontSize: 22, fontWeight: 800, margin: "0 0 3px", color: T.dark },
  sub: { fontSize: 14, color: T.muted, margin: 0 },

  tabRow: { display: "flex", gap: 4, marginBottom: 24, background: "#fff", borderRadius: T.r, padding: 4, boxShadow: T.shadowSm, width: "fit-content", border: `1.5px solid ${T.border}` },
  tab: { padding: "9px 20px", borderRadius: T.r, border: "none", background: "none", fontSize: 14, fontWeight: 600, color: T.muted, cursor: "pointer" },
  tabActive: { background: T.grad, color: "#fff", boxShadow: "0 2px 8px rgba(124,58,237,0.25)" },

  panel: { background: "#fff", borderRadius: T.rXL, padding: "24px 28px", boxShadow: T.shadowSm, border: `1.5px solid ${T.border}` },
  panelHead: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  panelTitle: { fontSize: 17, fontWeight: 800, color: T.dark, margin: 0 },
  count: { fontSize: 13, fontWeight: 600, color: T.muted, marginLeft: 8 },

  coachList: { display: "flex", flexDirection: "column", gap: 0, marginBottom: 20 },
  coachRow: { display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${T.border}` },
  coachName: { flex: 1, fontSize: 14, color: T.dark, fontWeight: 500 },
  addCoachRow: { display: "flex", gap: 10, paddingTop: 16 },

  inlineInput: { padding: "8px 12px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: "inherit", color: T.dark },

  eventList: { display: "flex", flexDirection: "column", gap: 0 },
  eventRow: { display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: `1px solid ${T.border}` },
  sportDot: { width: 10, height: 10, borderRadius: "50%", flexShrink: 0 },
  eventRowInfo: { flex: 1 },
  eventRowName: { fontSize: 14, fontWeight: 700, color: T.dark },
  eventRowMeta: { fontSize: 12, color: T.muted, marginTop: 2 },
  featuredDot: { color: "#F59E0B", marginLeft: 4 },
  eventRowActions: { display: "flex", gap: 8, flexShrink: 0 },

  formGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 },
  input: { width: "100%", padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: "inherit", boxSizing: "border-box", color: T.dark },
  radioRow: { display: "flex", gap: 16 },
  radioLabel: { display: "flex", alignItems: "center", gap: 6, fontSize: 14, color: T.dark, cursor: "pointer" },
  geoTag: { fontSize: 11, color: T.primary, fontWeight: 600, marginTop: 4 },
  photoRemove: { position: "absolute", top: -6, right: -6, width: 18, height: 18, borderRadius: "50%", background: T.danger, color: "#fff", border: "none", fontSize: 10, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 },

  btnPri: { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "9px 18px", fontSize: 13, fontWeight: 700, cursor: "pointer" },
  btnSm: { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "6px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer" },
  btnSmGhost: { background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" },
  btnSmDanger: { background: "#FEE2E2", color: "#991B1B", border: "none", borderRadius: T.r, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" },
  btnSecFull: { background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "12px 24px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
};
