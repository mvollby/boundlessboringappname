import { useState, useRef, useEffect, useMemo } from "react";
import { eventStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import routesData from "../routes.json";

const DIST_COLORS = {
  "100 Miles":     { bg:"#EDE9FE", color:"#7C3AED", border:"#C4B5FD" },
  "200 Miles":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "250 Miles":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "350 Miles":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "150 Miles":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "125 Miles":     { bg:"#E0E7FF", color:"#4338CA", border:"#A5B4FC" },
  "100K":          { bg:"#DBEAFE", color:"#2563EB", border:"#93C5FD" },
  "75 Miles":      { bg:"#D1FAE5", color:"#059669", border:"#6EE7B7" },
  "50 Miles":      { bg:"#D1FAE5", color:"#059669", border:"#6EE7B7" },
  "50K":           { bg:"#FEF3C7", color:"#D97706", border:"#FCD34D" },
  "Trail Marathon":{ bg:"#FEE2E2", color:"#DC2626", border:"#FCA5A5" },
};

const SPORT_BADGE = {
  Running: { bg:"#D1FAE5", color:"#065F46" },
  MTB:     { bg:"#DBEAFE", color:"#1E40AF" },
  Gravel:  { bg:"#FEF3C7", color:"#92400E" },
};

const ROUTE_COLORS = {
  Running: "#7C3AED",
  MTB:     "#3B82F6",
  Gravel:  "#3B82F6",
};

const ROUTE_GLOW = {
  Running: "rgba(124,58,237,0.25)",
  MTB:     "rgba(59,130,246,0.25)",
  Gravel:  "rgba(59,130,246,0.25)",
};

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export default function Heatmap({ onOpenEvent }) {
  const mapRef = useRef(null);
  const leafletReady = useRef(false);
  const mapInstance = useRef(null);
  const layersRef = useRef([]);
  const [selected, setSelected] = useState(null);
  const selectedRef = useRef(null);
  const [sport, setSport] = useState("All");
  const [filterState, setFilterState] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [filterDist, setFilterDist] = useState("All");

  const allEvents = useMemo(() => eventStorage.getAll(), []);

  const sportOptions = useMemo(() => {
    const s = new Set(allEvents.map(e => e.sportType));
    return ["All", ...Array.from(s).sort()];
  }, [allEvents]);

  const stateOptions = useMemo(() => {
    const f = sport === "All" ? allEvents : allEvents.filter(e => e.sportType === sport);
    return [...new Set(f.map(e => e.state))].sort();
  }, [allEvents, sport]);

  const distOptions = useMemo(() => {
    const f = sport === "All" ? allEvents : allEvents.filter(e => e.sportType === sport);
    return [...new Set(f.map(e => e.distance).filter(Boolean))].sort();
  }, [allEvents, sport]);

  const filtered = useMemo(() => {
    return allEvents.filter(e => {
      if (sport !== "All" && e.sportType !== sport) return false;
      if (filterState !== "All" && e.state !== filterState) return false;
      if (filterMonth !== "All" && e.month !== filterMonth) return false;
      if (filterDist !== "All" && e.distance !== filterDist) return false;
      return true;
    });
  }, [allEvents, sport, filterState, filterMonth, filterDist]);

  // Split into events with routes and without
  const { withRoutes, withoutRoutes } = useMemo(() => {
    const wr = [], wor = [];
    filtered.forEach(ev => {
      if (routesData[ev.id]) wr.push(ev);
      else wor.push(ev);
    });
    return { withRoutes: wr, withoutRoutes: wor };
  }, [filtered]);

  // Load Leaflet
  useEffect(() => {
    if (leafletReady.current) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.onload = () => { leafletReady.current = true; initMap(); };
    document.head.appendChild(script);
    return () => { if (mapInstance.current) { mapInstance.current.remove(); mapInstance.current = null; } };
  }, []);

  const initMap = () => {
    if (!mapRef.current || !window.L || mapInstance.current) return;
    const L = window.L;
    const map = L.map(mapRef.current, {
      center: [39, -98], zoom: 4, minZoom: 3, maxZoom: 14,
      zoomControl: true, attributionControl: false, scrollWheelZoom: true,
      maxBounds: [[15, -180], [72, -50]], maxBoundsViscosity: 1.0,
    });
    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 18, subdomains: "abcd",
    }).addTo(map);
    mapInstance.current = map;
    updateLayers();
  };

  useEffect(() => {
    if (leafletReady.current && mapRef.current && !mapInstance.current) initMap();
  });

  const updateLayers = () => {
    if (!mapInstance.current || !window.L) return;
    const L = window.L;
    layersRef.current.forEach(l => l.remove());
    layersRef.current = [];

    // Draw routes as polylines
    withRoutes.forEach(ev => {
      const coords = routesData[ev.id];
      if (!coords || coords.length < 2) return;
      const color = ROUTE_COLORS[ev.sportType] || ROUTE_COLORS.Running;
      const glowColor = ROUTE_GLOW[ev.sportType] || ROUTE_GLOW.Running;
      const isSelected = selected && selected.id === ev.id;

      // Glow layer (wider, transparent)
      const glow = L.polyline(coords, {
        color: glowColor,
        weight: isSelected ? 16 : 10,
        opacity: isSelected ? 0.6 : 0.3,
        lineCap: "round", lineJoin: "round",
        interactive: false,
      }).addTo(mapInstance.current);
      layersRef.current.push(glow);

      // Main route line
      const line = L.polyline(coords, {
        color: color,
        weight: isSelected ? 5 : 3,
        opacity: isSelected ? 1 : 0.75,
        lineCap: "round", lineJoin: "round",
      }).addTo(mapInstance.current);
      layersRef.current.push(line);

      // Invisible wide click target (easy to click on)
      const hitArea = L.polyline(coords, {
        color: "#000000",
        weight: 24,
        opacity: 0,
        lineCap: "round", lineJoin: "round",
        bubblingMouseEvents: false,
      }).addTo(mapInstance.current);
      layersRef.current.push(hitArea);

      // Tooltip on hover
      hitArea.bindTooltip(
        `<div style="font-family:Inter,sans-serif;font-weight:700;font-size:12px;color:#1E1B4B;">${ev.name}</div>
         <div style="font-family:Inter,sans-serif;font-size:11px;color:#6B7280;">${ev.city}, ${ev.state} · ${ev.distance}</div>`,
        { sticky: true, className: "boundless-tooltip" }
      );
      hitArea.on("click", () => setSelected(ev));
    });

    // Only show events that have routes — no dot markers for events without GPX
  };

  useEffect(() => { updateLayers(); }, [filtered, selected]);
  useEffect(() => { selectedRef.current = selected; }, [selected]);

  useEffect(() => {
    if (document.getElementById("boundless-leaflet-css")) return;
    const style = document.createElement("style");
    style.id = "boundless-leaflet-css";
    style.textContent = `
      .boundless-tooltip { background:#fff !important; border:1.5px solid #E9E4FF !important; border-radius:10px !important; padding:8px 12px !important; box-shadow:0 4px 16px rgba(124,58,237,0.12) !important; }
      .boundless-tooltip::before { border-top-color:#E9E4FF !important; }
      .leaflet-container { border-radius:20px; font-family:Inter,sans-serif; }
    `;
    document.head.appendChild(style);
  }, []);

  const handleSportChange = (s) => { setSport(s); setFilterDist("All"); setFilterState("All"); setSelected(null); };
  const clearAll = () => { setFilterState("All"); setFilterMonth("All"); setFilterDist("All"); setSelected(null); };
  const activeFilters = (filterState !== "All" ? 1 : 0) + (filterMonth !== "All" ? 1 : 0) + (filterDist !== "All" ? 1 : 0);

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Race Heatmap</h2>
          <p style={S.sub}>{withRoutes.length} race routes across the USA</p>
        </div>
        {activeFilters > 0 && (
          <button style={S.clearAllBtn} onClick={clearAll}>
            Clear filters <span style={S.filterBadge}>{activeFilters}</span>
          </button>
        )}
      </div>

      <div style={S.filterPanel}>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Sport</label>
          <select style={S.select} value={sport} onChange={e => handleSportChange(e.target.value)}>
            {sportOptions.map(s => <option key={s} value={s}>{s === "All" ? "All sports" : s}</option>)}
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>State</label>
          <select style={S.select} value={filterState} onChange={e => { setFilterState(e.target.value); setSelected(null); }}>
            <option value="All">All states</option>
            {stateOptions.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Month</label>
          <select style={S.select} value={filterMonth} onChange={e => { setFilterMonth(e.target.value); setSelected(null); }}>
            <option value="All">All months</option>
            {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Distance</label>
          <select style={S.select} value={filterDist} onChange={e => { setFilterDist(e.target.value); setSelected(null); }}>
            <option value="All">All distances</option>
            {distOptions.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>

      <div style={S.mapContainer}>
        <div ref={mapRef} style={S.mapInner} />
      </div>

      {selected && (() => {
        const ev = selected;
        const dc = DIST_COLORS[ev.distance] || { bg:"#E0E7FF", color:"#4338CA", border:"#A5B4FC" };
        const sb = SPORT_BADGE[ev.sportType] || SPORT_BADGE.Running;
        return (
          <div style={S.detailCard}>
            <div style={S.detailTop}>
              <div>
                <h3 style={S.detailCity}>{ev.name}</h3>
                <p style={S.detailSub}>{ev.city}, {ev.state} · {ev.month}</p>
              </div>
              <button style={S.closeBtn} onClick={() => setSelected(null)}>
                <Icon.X style={{width:16,height:16}}/>
              </button>
            </div>
            <div style={S.eventRow}>
              <div style={S.eventLeft}>
                <div style={S.eventMeta}>
                  <Icon.MapPin style={{width:12,height:12,color:T.muted}}/> {ev.city}, {ev.state}
                </div>
                <div style={S.eventMeta}>
                  <Icon.Flag style={{width:11,height:11,color:T.muted}}/> {ev.month}
                </div>
              </div>
              <div style={S.pillRow}>
                <span style={{...S.sportPill, background:sb.bg, color:sb.color}}>{ev.sportType}</span>
                {ev.distance && (
                  <span style={{...S.distPill, background:dc.bg, color:dc.color, borderColor:dc.border}}>{ev.distance}</span>
                )}
                <button style={S.forumBtn} onClick={() => onOpenEvent && onOpenEvent(ev)}>
                  Open Forum <Icon.ChevronRight style={{width:13,height:13}}/>
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

const S = {
  root: { paddingBottom: 60 },
  pageHeader: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:18, flexWrap:"wrap", gap:12 },
  title: { fontSize:22, fontWeight:800, margin:"0 0 3px", color:T.dark },
  sub: { fontSize:14, color:T.muted, margin:0 },
  clearAllBtn: { display:"flex", alignItems:"center", gap:7, background:"none", border:"none", color:T.danger, fontSize:13, fontWeight:600, cursor:"pointer", padding:0 },
  filterBadge: { background:T.danger, color:"#fff", borderRadius:T.rPill, padding:"1px 6px", fontSize:11, fontWeight:700 },
  filterPanel: { background:"#fff", borderRadius:T.rXL, padding:"16px 24px", marginBottom:18, boxShadow:T.shadowSm, border:`1.5px solid ${T.border}`, display:"flex", flexWrap:"wrap", gap:16, alignItems:"flex-end" },
  filterGroup: { display:"flex", flexDirection:"column", gap:4 },
  filterLabel: { fontSize:11, fontWeight:700, color:T.dark, textTransform:"uppercase", letterSpacing:"0.04em" },
  select: { padding:"9px 14px", borderRadius:T.r, border:`1.5px solid ${T.border}`, fontSize:13, background:T.bg, color:T.dark, outline:"none", fontFamily:T.fontBase, minWidth:150, cursor:"pointer" },
  mapContainer: { background:"#fff", borderRadius:T.rXL, overflow:"hidden", boxShadow:T.shadow, border:`1.5px solid ${T.border}`, marginBottom:18 },
  mapInner: { width:"100%", height:520, borderRadius:20 },
  detailCard: { background:"#fff", borderRadius:T.rXL, padding:"20px 24px", boxShadow:T.shadow, border:`1.5px solid ${T.border}`, marginBottom:18 },
  detailTop: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 },
  detailCity: { fontSize:18, fontWeight:800, color:T.dark, margin:0 },
  detailSub: { fontSize:13, color:T.primary, margin:"3px 0 0", fontWeight:600 },
  closeBtn: { background:"none", border:"none", cursor:"pointer", color:T.muted, padding:4 },
  eventRow: { display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"10px 14px", background:T.bg, borderRadius:T.r, flexWrap:"wrap" },
  eventLeft: { display:"flex", flexDirection:"column", gap:5, flex:1, minWidth:0 },
  eventName: { fontSize:14, fontWeight:700, color:T.dark },
  eventMeta: { display:"flex", alignItems:"center", gap:5, fontSize:12, color:T.muted },
  pillRow: { display:"flex", gap:6, alignItems:"center", flexShrink:0, flexWrap:"wrap" },
  sportPill: { fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:T.rPill, textTransform:"uppercase", letterSpacing:"0.03em" },
  distPill: { fontSize:11, fontWeight:700, padding:"3px 10px", borderRadius:T.rPill, border:"1.5px solid", whiteSpace:"nowrap" },
  forumBtn: { display:"flex", alignItems:"center", gap:4, background:T.grad, color:"#fff", border:"none", borderRadius:T.rPill, padding:"7px 14px", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" },
};
