import { useState, useRef } from "react";
import { profileStorage, coachStorage, eventStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import LocationInput from "../components/LocationInput";
import EventMultiSelect from "../components/EventMultiSelect";

const DISCIPLINES  = ["Runner", "Cyclist", "Multisport"];
const GOAL_OPTIONS = ["Looking for Pacers", "Wanting to Meet People", "Finding Training Partners"];

function resolveEventNames(eventIds) {
  const all = eventStorage.getAll();
  return (eventIds || []).map((id) => all.find((e) => e.id === id)?.name).filter(Boolean);
}

export default function MyProfile({ profile, currentUser, onProfileUpdate }) {
  const [editing, setEditing] = useState(false);
  const [form,    setForm]    = useState({ ...profile });
  const [saved,   setSaved]   = useState(false);
  const fileRef               = useRef();

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const toggleGoal = (g) => setForm((f) => ({
    ...f,
    goals: (f.goals || []).includes(g)
      ? (f.goals || []).filter((x) => x !== g)
      : [...(f.goals || []), g],
  }));

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    // Resize + compress to max 240×240 JPEG so it fits in localStorage
    // and is visible to other users when they load the app.
    const img = new window.Image();
    const blobUrl = URL.createObjectURL(file);
    img.onload = () => {
      const MAX = 240;
      const ratio = Math.min(MAX / img.naturalWidth, MAX / img.naturalHeight, 1);
      const canvas = document.createElement("canvas");
      canvas.width  = Math.round(img.naturalWidth  * ratio);
      canvas.height = Math.round(img.naturalHeight * ratio);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      const compressed = canvas.toDataURL("image/jpeg", 0.75);
      URL.revokeObjectURL(blobUrl);
      set("photoUrl", compressed);
    };
    img.src = blobUrl;
  };

  const handleLocationSelect = (item) => {
    if (!item) {
      setForm((f) => ({ ...f, location: "", lat: null, lng: null, city: "", state: "", country: "" }));
      return;
    }
    setForm((f) => ({
      ...f,
      location: item.shortName || item.label || "",
      lat:      item.lat,
      lng:      item.lng,
      city:     item.city || "",
      state:    item.state || "",
      country:  item.country || "",
    }));
  };

  const handleSave = () => {
    profileStorage.set(currentUser.id, form);
    onProfileUpdate(form);
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const coaches      = coachStorage.getAll().map((c) => c.name).sort();
  const dc           = T.disc[profile.discipline] || { bg: "#EDE9FE", color: T.primary, grad: T.grad };
  const initials     = profile.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const displayNames = resolveEventNames(profile.events);

  return (
    <div style={S.root}>
      {/* Profile card */}
      <div style={S.card}>
        <div style={{ ...S.banner, background: dc.grad }} />
        <div style={S.cardBody}>
          <div style={S.avatarWrap}>
            {profile.photoUrl
              ? <img src={profile.photoUrl} alt="" style={S.avatarImg} />
              : <div style={{ ...S.avatar, background: dc.grad }}>{initials}</div>
            }
          </div>
          <h2 style={S.name}>{profile.name}</h2>
          <span style={{ ...S.discBadge, background: dc.bg, color: dc.color }}>{profile.discipline || "Athlete"}</span>

          <div style={S.metaGrid}>
            {profile.location && (
              <div style={S.metaItem}><Icon.MapPin style={{ width: 14, height: 14, color: T.primary }} /><span>{profile.location}</span></div>
            )}
            {profile.coach && (
              <div style={S.metaItem}><Icon.Star style={{ width: 12, height: 12, color: T.amber }} /><span>{profile.coach}</span></div>
            )}
            {profile.gender && (
              <div style={S.metaItem}><Icon.User style={{ width: 14, height: 14, color: T.primary }} /><span>{profile.gender}</span></div>
            )}
            <div style={S.metaItem}><Icon.Mail style={{ width: 14, height: 14, color: T.primary }} /><span>{currentUser.email}</span></div>
          </div>

          {/* Events */}
          {displayNames.length > 0 && (
            <div style={S.chipsSection}>
              <p style={S.chipsLabel}>Events</p>
              <div style={S.chipRow}>
                {displayNames.map((name, i) => <span key={i} style={S.eventChip}>{name}</span>)}
              </div>
            </div>
          )}

          {/* Goals */}
          {profile.goals?.length > 0 && (
            <div style={S.chipsSection}>
              <p style={S.chipsLabel}>Goals</p>
              <div style={S.chipRow}>
                {profile.goals.map((g) => (
                  <span key={g} style={S.goalChip}>{g}</span>
                ))}
              </div>
            </div>
          )}

          {profile.bio && <p style={S.bio}>{profile.bio}</p>}
          {saved && (
            <div style={S.savedBanner}><Icon.Check style={{ width: 14, height: 14 }} /> Profile saved!</div>
          )}
          <button style={S.btnEdit} onClick={() => { setForm({ ...profile, goals: profile.goals || [] }); setEditing(true); }}>Edit Profile</button>
        </div>
      </div>

      {/* Edit modal */}
      {editing && (
        <div style={S.overlay} onClick={() => setEditing(false)}>
          <div style={S.modal} onClick={(e) => e.stopPropagation()}>
            <button style={S.closeBtn} onClick={() => setEditing(false)}><Icon.X style={{ width: 18, height: 18 }} /></button>
            <h3 style={S.modalTitle}>Edit Profile</h3>

            {/* Photo */}
            <div style={S.photoSection}>
              <div>
                {form.photoUrl
                  ? <img src={form.photoUrl} alt="" style={S.photoPreview} />
                  : <div style={{ ...S.photoPlaceholder, background: (T.disc[form.discipline]||{grad:T.grad}).grad }}>{initials}</div>
                }
              </div>
              <div style={{ flex: 1 }}>
                <p style={S.photoLabel}>Profile photo</p>
                <button style={S.btnUpload} onClick={() => fileRef.current.click()}>
                  <Icon.Camera style={{ width: 13, height: 13 }} /> Upload
                </button>
                {form.photoUrl && <button style={S.btnRemove} onClick={() => set("photoUrl", null)}>Remove</button>}
                <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handlePhotoChange} />
              </div>
            </div>

            <FG label="Discipline">
              <div style={S.discRow}>
                {DISCIPLINES.map((d) => (
                  <button key={d} onClick={() => set("discipline", d)}
                    style={{ ...S.discBtn, ...(form.discipline === d ? S.discBtnActive : {}) }}>
                    {d}
                  </button>
                ))}
              </div>
            </FG>

            <FG label="Location">
              <LocationInput
                value={form.location || ""}
                onSelect={handleLocationSelect}
                placeholder="e.g. Boulder, CO"
              />
              {form.lat && <span style={{ fontSize: 11, color: T.primary, fontWeight: 600, marginTop: 4, display: "block" }}>Geocoded · {form.lat.toFixed(3)}, {form.lng.toFixed(3)}</span>}
            </FG>

            <FG label="Coach">
              <select style={S.input} value={form.coach || ""} onChange={(e) => set("coach", e.target.value)}>
                <option value="">None / not listed</option>
                {coaches.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </FG>

            <FG label="Events">
              <EventMultiSelect
                selected={form.events || []}
                onChange={(ids) => set("events", ids)}
                placeholder="Search and select events…"
              />
            </FG>

            <FG label="Goals">
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {GOAL_OPTIONS.map((g) => {
                  const on = (form.goals || []).includes(g);
                  return (
                    <button key={g} type="button" onClick={() => toggleGoal(g)}
                      style={{ ...S.chip, ...(on ? S.chipActive : {}) }}>
                      {on && <Icon.Check style={{ width: 10, height: 10 }} />}{g}
                    </button>
                  );
                })}
              </div>
            </FG>

            <FG label="Gender">
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {["Man","Woman","Non-binary","Prefer not to say"].map((g) => (
                  <button key={g} type="button"
                    onClick={() => set("gender", form.gender === g ? "" : g)}
                    style={{ ...S.chip, ...(form.gender === g ? S.chipActive : {}) }}>
                    {g}
                  </button>
                ))}
              </div>
            </FG>

            <FG label="Bio">
              <textarea style={{ ...S.input, minHeight: 80, resize: "vertical" }}
                value={form.bio || ""} onChange={(e) => set("bio", e.target.value)} />
            </FG>

            <button style={S.btnPri} onClick={handleSave}>Save Changes</button>
          </div>
        </div>
      )}
    </div>
  );
}

function FG({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: T.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 7 }}>{label}</label>
      {children}
    </div>
  );
}

const S = {
  root: { maxWidth: 540, margin: "0 auto", paddingBottom: 48 },
  card: { background: "#fff", borderRadius: T.rXL, overflow: "hidden", boxShadow: T.shadow, border: `1.5px solid ${T.border}` },
  banner: { height: 80 },
  cardBody: { padding: "0 28px 32px", textAlign: "center" },
  avatarWrap: { marginTop: -44, marginBottom: 14 },
  avatar: { width: 88, height: 88, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, fontWeight: 800, color: "#fff", margin: "0 auto", border: "4px solid #fff", boxShadow: T.shadowSm },
  avatarImg: { width: 88, height: 88, borderRadius: "50%", objectFit: "cover", margin: "0 auto", display: "block", border: "4px solid #fff", boxShadow: T.shadowSm },
  name: { fontSize: 24, fontWeight: 800, color: T.dark, margin: "0 0 8px" },
  discBadge: { display: "inline-block", padding: "4px 14px", borderRadius: T.rPill, fontSize: 12, fontWeight: 700, marginBottom: 18 },
  metaGrid: { display: "flex", flexDirection: "column", gap: 8, alignItems: "center", marginBottom: 16 },
  metaItem: { display: "flex", alignItems: "center", gap: 7, fontSize: 14, color: T.muted },
  chipsSection: { marginBottom: 14 },
  chipsLabel: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: T.muted, margin: "0 0 7px" },
  chipRow: { display: "flex", flexWrap: "wrap", gap: 6, justifyContent: "center" },
  eventChip: { fontSize: 12, fontWeight: 600, background: T.bg, color: T.primary, padding: "4px 12px", borderRadius: T.rPill, border: `1px solid ${T.border}` },
  goalChip: { fontSize: 12, fontWeight: 600, background: "#EDE9FE", color: T.primary, padding: "4px 12px", borderRadius: T.rPill },
  bio: { fontSize: 14, color: T.muted, lineHeight: 1.6, margin: "0 0 20px", textAlign: "left", background: T.bg, borderRadius: T.r, padding: "12px 16px" },
  savedBanner: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: "#D1FAE5", color: "#065F46", borderRadius: T.r, padding: "9px 16px", fontSize: 13, fontWeight: 700, marginBottom: 14 },
  btnEdit: { background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "13px 32px", fontSize: 14, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.3)" },

  overlay: { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "flex-start", justifyContent: "center", zIndex: 100, padding: "40px 20px", overflowY: "auto" },
  modal: { background: "#fff", borderRadius: T.rXL, padding: "32px 28px 28px", maxWidth: 480, width: "100%", position: "relative", boxShadow: T.shadowLg },
  closeBtn: { position: "absolute", top: 14, right: 14, background: "none", border: "none", cursor: "pointer", color: T.muted },
  modalTitle: { fontSize: 20, fontWeight: 800, color: T.dark, marginBottom: 20 },

  photoSection: { display: "flex", alignItems: "center", gap: 16, background: T.bg, borderRadius: T.r, padding: "14px 16px", marginBottom: 20, border: `1.5px solid ${T.border}` },
  photoPreview: { width: 64, height: 64, borderRadius: "50%", objectFit: "cover", border: `3px solid ${T.border}` },
  photoPlaceholder: { width: 64, height: 64, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 800, color: "#fff" },
  photoLabel: { fontSize: 13, fontWeight: 700, color: T.dark, margin: "0 0 8px" },
  btnUpload: { display: "inline-flex", alignItems: "center", gap: 6, background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "8px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", marginBottom: 6 },
  btnRemove: { display: "block", background: "none", border: "none", color: T.danger, fontSize: 12, cursor: "pointer", fontWeight: 600 },

  input: { width: "100%", padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, outline: "none", background: T.bg, fontFamily: "inherit", boxSizing: "border-box", color: T.dark },
  discRow: { display: "flex", gap: 8, flexWrap: "wrap" },
  discBtn: { flex: 1, padding: "10px 8px", borderRadius: T.r, border: `1.5px solid ${T.border}`, background: T.bg, fontSize: 13, fontWeight: 600, cursor: "pointer", color: T.muted },
  discBtnActive: { background: T.grad, color: "#fff", border: "1.5px solid transparent" },
  chip: { display: "flex", alignItems: "center", gap: 5, padding: "7px 13px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", color: T.dark },
  chipActive: { background: "#EDE9FE", borderColor: T.primary, color: T.primary },
  btnPri: { width: "100%", background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "14px", fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.3)", marginTop: 4 },
};
