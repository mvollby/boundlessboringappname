import { useState, useEffect } from "react";
import { profileStorage, conversationStorage } from "../utils/storage";
import { T } from "../theme";
import { Icon } from "../Icons";
import Events       from "./Events";
import Communities  from "./Communities";
import Messages     from "./Messages";
import MyProfile    from "./MyProfile";
import AdminUploads from "./AdminUploads";

const BASE_TABS = [
  { id: "events",      label: "Events",      Icon: Icon.Flag   },
  { id: "communities", label: "Communities", Icon: Icon.Users  },
  { id: "messages",    label: "Messages",    Icon: Icon.Mail   },
  { id: "profile",     label: "My Profile",  Icon: Icon.User   },
];
const ADMIN_TAB = { id: "uploads", label: "Uploads", Icon: Icon.Camera };

export default function MainApp({ user, onLogout }) {
  const [tab,          setTab]          = useState("events");
  const [myProfile,    setMyProfile]    = useState(null);
  const [allProfiles,  setAllProfiles]  = useState([]);
  const [pendingCount, setPendingCount] = useState(0);

  const tabs = user.isAdmin ? [...BASE_TABS, ADMIN_TAB] : BASE_TABS;

  const reload = () => {
    const p = profileStorage.get(user.id);
    setMyProfile(p);
    setAllProfiles(profileStorage.getAll());
    setPendingCount(conversationStorage.pendingFor(user.id).length);
  };

  useEffect(() => { reload(); }, [user.id]);

  // Refresh pending count whenever tab changes back to messages
  useEffect(() => {
    if (tab === "messages") setPendingCount(0);
  }, [tab]);

  const handleProfileUpdate = (updated) => {
    setMyProfile(updated);
    setAllProfiles(profileStorage.getAll());
  };

  if (!myProfile) return null;

  // Always reflect live myProfile in allProfiles so photo updates appear
  // instantly in Communities / Messages even if the localStorage write failed
  // (e.g. base64 image too large for quota).
  const allProfilesLive = allProfiles.map((p) =>
    p.userId === user.id ? myProfile : p
  );

  const discD = T.disc[myProfile.discipline] || T.disc.Runner;

  return (
    <div style={S.root}>
      {/* Header */}
      <header style={S.header}>
        <div style={S.headerInner}>
          <div style={S.logoWrap}>
            <div style={S.logoMark}>
              <svg viewBox="0 0 32 32" width="26" height="26" fill="none">
                <circle cx="16" cy="16" r="16" fill="rgba(255,255,255,0.2)"/>
                <path d="M11 22l2-5 3 2 3-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="19" cy="10" r="2" fill="#fff"/>
              </svg>
            </div>
            <span style={S.logoText}>Boundless</span>
          </div>
          <div style={S.headerRight}>
            {user.isAdmin && <span style={S.adminBadge}>Admin</span>}
            <div style={{ ...S.discChip, background: discD.bg, color: discD.color }}>
              {myProfile.discipline || "Athlete"}
            </div>
            <div style={S.avatarBtn}>
              {myProfile.photoUrl
                ? <img src={myProfile.photoUrl} alt="" style={S.avatarImg} />
                : <span style={S.avatarInitials}>{user.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}</span>
              }
            </div>
            <button onClick={onLogout} style={S.btnLogout}>Sign out</button>
          </div>
        </div>
      </header>

      {/* Tab nav */}
      <nav style={S.nav}>
        <div style={S.navInner}>
          {tabs.map((t) => {
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                style={{ ...S.navBtn, ...(active ? S.navBtnActive : {}) }}>
                <t.Icon style={{ width: 16, height: 16 }} />
                <span>{t.label}</span>
                {t.id === "messages" && pendingCount > 0 && <span style={S.navBadge}>{pendingCount}</span>}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Content */}
      <main style={S.main}>
        {tab === "events" && (
          <Events
            myProfile={myProfile}
            allProfiles={allProfilesLive}
            currentUser={user}
            onNavigateToMessages={() => setTab("messages")}
          />
        )}
        {tab === "communities" && (
          <Communities
            myProfile={myProfile}
            allProfiles={allProfilesLive}
            currentUser={user}
            onNavigateToMessages={() => setTab("messages")}
          />
        )}
        {tab === "messages" && (
          <Messages currentUser={user} allProfiles={allProfilesLive} />
        )}
        {tab === "profile" && (
          <MyProfile profile={myProfile} currentUser={user} onProfileUpdate={handleProfileUpdate} />
        )}
        {tab === "uploads" && user.isAdmin && <AdminUploads />}
      </main>
    </div>
  );
}

const S = {
  root: { fontFamily: T.fontBase, minHeight: "100vh", background: T.bg, color: T.dark },
  header: { background: T.gradHeader, color: "#fff" },
  headerInner: { maxWidth: 1140, margin: "0 auto", padding: "14px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" },
  logoWrap: { display: "flex", alignItems: "center", gap: 10 },
  logoMark: { display: "flex" },
  logoText: { fontSize: 20, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em" },
  headerRight: { display: "flex", alignItems: "center", gap: 10 },
  discChip: { padding: "4px 12px", borderRadius: T.rPill, fontSize: 12, fontWeight: 700 },
  avatarBtn: { width: 34, height: 34, borderRadius: "50%", overflow: "hidden", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" },
  avatarImg: { width: "100%", height: "100%", objectFit: "cover" },
  avatarInitials: { fontSize: 13, fontWeight: 700, color: "#fff" },
  adminBadge: { background: "rgba(255,255,255,0.25)", color: "#fff", borderRadius: T.rPill, padding: "3px 10px", fontSize: 11, fontWeight: 800, letterSpacing: "0.06em", textTransform: "uppercase" },
  btnLogout: { background: "rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.8)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: T.r, padding: "7px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer" },
  nav: { background: "#fff", borderBottom: `1px solid ${T.border}`, position: "sticky", top: 0, zIndex: 10, boxShadow: "0 1px 12px rgba(124,58,237,0.06)" },
  navInner: { maxWidth: 1140, margin: "0 auto", padding: "0 24px", display: "flex", gap: 2 },
  navBtn: { display: "flex", alignItems: "center", gap: 7, padding: "13px 16px", fontSize: 13, fontWeight: 500, color: T.muted, background: "none", border: "none", borderBottom: "2px solid transparent", cursor: "pointer", position: "relative", whiteSpace: "nowrap" },
  navBtnActive: { color: T.primary, fontWeight: 700, borderBottom: `2px solid ${T.primary}` },
  navBadge: { background: T.danger, color: "#fff", borderRadius: T.rPill, padding: "1px 6px", fontSize: 10, fontWeight: 700 },
  main: { maxWidth: 1140, margin: "0 auto", padding: "32px 24px" },
};
