import { useState, useEffect, useRef } from "react";
import { eventStorage } from "../utils/storage";
import { T } from "../theme";

/**
 * Searchable multi-select for events.
 * Stores event IDs in `selected` array; displays resolved names as chips.
 */
export default function EventMultiSelect({ selected = [], onChange, placeholder = "Search and select events…" }) {
  const [open,   setOpen]   = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef();

  const allEvents = eventStorage.getAll().sort((a, b) => a.name.localeCompare(b.name));

  const filtered = search.trim()
    ? allEvents.filter((e) =>
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.sportType.toLowerCase().includes(search.toLowerCase()) ||
        e.city.toLowerCase().includes(search.toLowerCase())
      )
    : allEvents;

  const getEvent = (id) => allEvents.find((e) => e.id === id);

  const toggle = (id) => {
    if (selected.includes(id)) onChange(selected.filter((x) => x !== id));
    else onChange([...selected, id]);
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const SPORT_COLOR = {
    Running: "#059669",
    MTB:     "#2563EB",
    Gravel:  "#D97706",
  };

  return (
    <div ref={ref} style={{ position: "relative" }}>
      {/* Trigger */}
      <div
        onClick={() => setOpen((v) => !v)}
        style={S.trigger}
      >
        <div style={{ flex: 1, display: "flex", flexWrap: "wrap", gap: 4, minHeight: 24, alignItems: "center" }}>
          {selected.length === 0 ? (
            <span style={{ color: T.muted, fontSize: 14 }}>{placeholder}</span>
          ) : (
            selected.map((id) => {
              const ev = getEvent(id);
              return ev ? (
                <span key={id} style={S.chip}>
                  {ev.name}
                  <span
                    style={S.chipRemove}
                    onClick={(e) => { e.stopPropagation(); toggle(id); }}
                  >✕</span>
                </span>
              ) : null;
            })
          )}
        </div>
        <svg style={{ width: 16, height: 16, color: T.muted, flexShrink: 0, transform: open ? "rotate(180deg)" : "none", transition: "transform 0.15s" }}
          viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </div>

      {/* Dropdown */}
      {open && (
        <div style={S.dropdown}>
          <div style={S.searchWrap}>
            <svg style={{ width: 14, height: 14, color: T.muted, flexShrink: 0 }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, sport, or city…"
              style={S.searchInput}
              onClick={(e) => e.stopPropagation()}
            />
            {search && (
              <button style={S.clearSearch} onClick={(e) => { e.stopPropagation(); setSearch(""); }}>✕</button>
            )}
          </div>

          <div style={S.list}>
            {filtered.length === 0 && (
              <div style={S.noResults}>No events found for "{search}"</div>
            )}
            {filtered.map((ev) => {
              const sel = selected.includes(ev.id);
              return (
                <div key={ev.id} onClick={() => toggle(ev.id)}
                  style={{ ...S.option, background: sel ? "#EDE9FE" : "#fff" }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontSize: 13, fontWeight: sel ? 700 : 500, color: sel ? T.primary : T.dark }}>
                        {ev.name}
                      </span>
                    </div>
                    <div style={{ display: "flex", gap: 8, marginTop: 2 }}>
                      <span style={{ fontSize: 11, color: SPORT_COLOR[ev.sportType] || T.muted, fontWeight: 600 }}>
                        {ev.sportType}
                      </span>
                      <span style={{ fontSize: 11, color: T.muted }}>{ev.distance}</span>
                      <span style={{ fontSize: 11, color: T.muted }}>{ev.city}, {ev.state}</span>
                    </div>
                  </div>
                  {sel && (
                    <svg style={{ width: 16, height: 16, color: T.primary, flexShrink: 0 }} viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              );
            })}
          </div>

          {selected.length > 0 && (
            <div style={S.footer}>
              <span style={{ fontSize: 12, color: T.muted }}>{selected.length} selected</span>
              <button style={S.clearAll} onClick={(e) => { e.stopPropagation(); onChange([]); }}>Clear all</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const S = {
  trigger: {
    display: "flex", alignItems: "flex-start", justifyContent: "space-between",
    padding: "10px 12px", borderRadius: T.r, border: `1.5px solid ${T.border}`,
    background: "#fff", cursor: "pointer", minHeight: 46, fontFamily: T.fontBase,
    gap: 8, boxSizing: "border-box",
  },
  chip: {
    display: "inline-flex", alignItems: "center", gap: 5,
    background: "#EDE9FE", color: T.primary, borderRadius: T.rPill,
    padding: "3px 8px 3px 10px", fontSize: 12, fontWeight: 600,
  },
  chipRemove: {
    fontSize: 10, cursor: "pointer", color: T.primary, opacity: 0.7,
    lineHeight: 1,
  },
  dropdown: {
    position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0,
    background: "#fff", border: `1.5px solid ${T.border}`, borderRadius: T.r,
    boxShadow: "0 8px 32px rgba(0,0,0,0.14)", zIndex: 300, overflow: "hidden",
  },
  searchWrap: {
    display: "flex", alignItems: "center", gap: 8,
    padding: "10px 14px", borderBottom: `1px solid ${T.border}`,
    background: T.bg,
  },
  searchInput: {
    flex: 1, border: "none", background: "transparent",
    fontSize: 13, outline: "none", fontFamily: T.fontBase, color: T.dark,
  },
  clearSearch: {
    background: "none", border: "none", cursor: "pointer",
    color: T.muted, fontSize: 12, padding: "0 2px",
  },
  list: { maxHeight: 240, overflowY: "auto" },
  option: {
    display: "flex", alignItems: "center", padding: "10px 14px",
    cursor: "pointer", borderBottom: `1px solid ${T.border}`, gap: 10,
    transition: "background 0.1s",
  },
  noResults: { padding: "20px 14px", textAlign: "center", color: T.muted, fontSize: 13 },
  footer: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "8px 14px", borderTop: `1px solid ${T.border}`, background: T.bg,
  },
  clearAll: {
    background: "none", border: "none", cursor: "pointer",
    fontSize: 12, fontWeight: 600, color: T.danger, padding: 0,
  },
};
