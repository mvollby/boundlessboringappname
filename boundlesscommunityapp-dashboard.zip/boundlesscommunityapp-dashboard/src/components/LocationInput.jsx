import { useState, useEffect, useRef } from "react";
import { searchLocations } from "../utils/geocoding";
import { T } from "../theme";
import { Icon } from "../Icons";

/**
 * Location input with Nominatim autocomplete.
 *
 * Props:
 *   value      – display string for the current value (controlled)
 *   onSelect   – called with { shortName, lat, lng, city, state, country } or null on clear
 *   placeholder – input placeholder text
 *   inputStyle  – extra style for the input wrapper
 */
export default function LocationInput({ value = "", onSelect, placeholder = "e.g. Boulder, CO", inputStyle }) {
  const [query,       setQuery]       = useState(value);
  const [suggestions, setSuggestions] = useState([]);
  const [loading,     setLoading]     = useState(false);
  const [open,        setOpen]        = useState(false);
  const debounceRef = useRef(null);
  const wrapRef     = useRef(null);

  // Sync when external value changes (e.g. cleared)
  useEffect(() => { setQuery(value); }, [value]);

  // Debounced fetch
  useEffect(() => {
    clearTimeout(debounceRef.current);
    if (query.length < 3) { setSuggestions([]); setOpen(false); return; }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      const results = await searchLocations(query);
      setSuggestions(results);
      setOpen(results.length > 0);
      setLoading(false);
    }, 380);
    return () => clearTimeout(debounceRef.current);
  }, [query]);

  // Close dropdown on outside click
  useEffect(() => {
    const close = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const handleSelect = (item) => {
    const label = item.shortName || item.displayName;
    setQuery(label);
    setSuggestions([]);
    setOpen(false);
    onSelect({ ...item, label });
  };

  const handleChange = (e) => {
    setQuery(e.target.value);
    if (!e.target.value.trim()) onSelect(null);
  };

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <div style={{ ...S.wrap, ...inputStyle }}>
        <Icon.MapPin style={{ width: 16, height: 16, color: T.muted, flexShrink: 0 }} />
        <input
          style={S.input}
          placeholder={placeholder}
          value={query}
          onChange={handleChange}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
          autoComplete="off"
        />
        {loading && <span style={S.spinner}>…</span>}
      </div>

      {open && suggestions.length > 0 && (
        <div style={S.dropdown}>
          {suggestions.map((item, i) => {
            const main = item.shortName || item.city || "";
            const sub  = item.displayName.length > 80 ? item.displayName.slice(0, 80) + "…" : item.displayName;
            return (
              <button key={i} style={S.option} onMouseDown={() => handleSelect(item)}>
                <Icon.MapPin style={{ width: 13, height: 13, color: T.primary, flexShrink: 0, marginTop: 2 }} />
                <div>
                  <div style={S.optionMain}>{main}</div>
                  <div style={S.optionSub}>{sub}</div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

const S = {
  wrap:   { display: "flex", alignItems: "center", gap: 10, background: "var(--loc-bg, #F5F3FF)", border: "1.5px solid #E5E7EB", borderRadius: 12, padding: "11px 14px" },
  input:  { flex: 1, border: "none", outline: "none", background: "transparent", fontSize: 14, color: "#1E1B4B", fontFamily: "inherit" },
  spinner:{ fontSize: 13, color: "#9CA3AF", flexShrink: 0 },

  dropdown: { position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, background: "#fff", borderRadius: 12, boxShadow: "0 8px 32px rgba(30,27,75,0.14)", border: "1.5px solid #E5E7EB", zIndex: 50, overflow: "hidden", maxHeight: 260, overflowY: "auto" },
  option:   { display: "flex", alignItems: "flex-start", gap: 10, width: "100%", padding: "11px 14px", background: "none", border: "none", cursor: "pointer", textAlign: "left", transition: "background 0.1s", borderBottom: "1px solid #F3F4F6" },
  optionMain: { fontSize: 14, fontWeight: 600, color: "#1E1B4B", marginBottom: 2 },
  optionSub:  { fontSize: 11, color: "#9CA3AF", lineHeight: 1.4 },
};
