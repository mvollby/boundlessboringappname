import { T } from "../theme";

/**
 * Shared Avatar component.
 * - Shows photoUrl as a circular photo if set.
 * - Otherwise shows the first letter of the person's first name in a
 *   discipline-coloured disc. Reverts to letter automatically when photo
 *   is removed from Edit Profile.
 */
export default function Avatar({ photoUrl, name, size = 40, discipline, style = {} }) {
  if (photoUrl) {
    return (
      <img
        src={photoUrl}
        alt={name || ""}
        style={{
          width: size, height: size, borderRadius: "50%",
          objectFit: "cover", flexShrink: 0,
          border: `2px solid ${T.border}`,
          display: "block",
          ...style,
        }}
      />
    );
  }

  const initial  = (name || "?").trim().charAt(0).toUpperCase();
  const bg       = T.disc[discipline]?.bg    || "#E8E4F8";
  const fg       = T.disc[discipline]?.color || T.primary;
  const fontSize = Math.round(size * 0.4);

  return (
    <div
      style={{
        width: size, height: size, borderRadius: "50%",
        background: bg,
        display: "flex", alignItems: "center", justifyContent: "center",
        flexShrink: 0,
        border: `2px solid ${T.border}`,
        fontSize, fontWeight: 800, color: fg,
        userSelect: "none",
        ...style,
      }}
    >
      {initial}
    </div>
  );
}
