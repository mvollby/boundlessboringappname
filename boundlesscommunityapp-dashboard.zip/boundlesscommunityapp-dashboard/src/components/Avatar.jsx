import { T } from "../theme";

/**
 * Shared Avatar component.
 * Shows photoUrl if set; otherwise a generic person silhouette — never initials.
 */
export default function Avatar({ photoUrl, name, size = 40, discipline, style = {} }) {
  if (photoUrl) {
    return (
      <img
        src={photoUrl}
        alt={name || ""}
        style={{
          width: size, height: size, borderRadius: "50%",
          objectFit: "cover", flexShrink: 0,
          border: `2px solid ${T.border}`,
          display: "block",
          ...style,
        }}
      />
    );
  }

  // Generic person silhouette
  const bg = discipline ? (T.disc[discipline]?.bg || "#E5E7EB") : "#E5E7EB";
  const fg = discipline ? (T.disc[discipline]?.color || "#9CA3AF") : "#9CA3AF";

  return (
    <svg
      width={size} height={size}
      viewBox="0 0 40 40"
      xmlns="http://www.w3.org/2000/svg"
      style={{ borderRadius: "50%", flexShrink: 0, display: "block", ...style }}
    >
      <circle cx="20" cy="20" r="20" fill={bg} />
      {/* Head */}
      <circle cx="20" cy="15" r="7" fill={fg} />
      {/* Body / shoulders */}
      <ellipse cx="20" cy="34" rx="11" ry="9" fill={fg} />
    </svg>
  );
}
