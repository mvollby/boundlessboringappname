const PREFIX = "boundless_";

export const storage = {
  get(key) {
    try { const r = localStorage.getItem(PREFIX + key); return r ? JSON.parse(r) : null; } catch { return null; }
  },
  set(key, value) {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(value)); } catch {}
  },
  remove(key) { localStorage.removeItem(PREFIX + key); },
};

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authStorage = {
  getUsers: () => storage.get("users") || [],
  saveUsers: (u) => storage.set("users", u),
  getSession: () => storage.get("session"),
  setSession: (s) => storage.set("session", s),
  clearSession: () => storage.remove("session"),
};

// ── Profiles ──────────────────────────────────────────────────────────────────
// Each profile keyed by userId
export const profileStorage = {
  get: (userId) => storage.get("profile_" + userId),
  set: (userId, data) => storage.set("profile_" + userId, data),
  // Return all profiles whose userId matches any known user
  getAll: () => {
    const users = authStorage.getUsers();
    return users.map((u) => profileStorage.get(u.id)).filter(Boolean);
  },
};

// ── Messages ──────────────────────────────────────────────────────────────────
// Messages stored as array: { id, fromUserId, toUserId, fromName, fromEmail, fromPhone, sentAt, read }
export const messageStorage = {
  getAll: () => storage.get("messages") || [],
  save: (msgs) => storage.set("messages", msgs),
  forUser: (userId) => messageStorage.getAll().filter((m) => m.toUserId === userId),
  send: (msg) => {
    const all = messageStorage.getAll();
    messageStorage.save([...all, { ...msg, id: Date.now().toString(36), sentAt: new Date().toISOString(), read: false }]);
  },
  markRead: (msgId) => {
    const all = messageStorage.getAll().map((m) => m.id === msgId ? { ...m, read: true } : m);
    messageStorage.save(all);
  },
};
