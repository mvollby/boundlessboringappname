const PREFIX = "boundless_";

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export const storage = {
  get(key)        { try { const r = localStorage.getItem(PREFIX + key); return r ? JSON.parse(r) : null; } catch { return null; } },
  set(key, value) { try { localStorage.setItem(PREFIX + key, JSON.stringify(value)); } catch {} },
  remove(key)     { localStorage.removeItem(PREFIX + key); },
};

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authStorage = {
  getUsers:     () => storage.get("users") || [],
  saveUsers:    (u) => storage.set("users", u),
  getSession:   () => storage.get("session"),
  setSession:   (s) => storage.set("session", s),
  clearSession: () => storage.remove("session"),
};

// ── Profiles ──────────────────────────────────────────────────────────────────
export const profileStorage = {
  get:    (userId) => storage.get("profile_" + userId),
  set:    (userId, data) => storage.set("profile_" + userId, data),
  getAll: () => authStorage.getUsers().map((u) => profileStorage.get(u.id)).filter(Boolean),
  wipeAll: () => {
    authStorage.getUsers().forEach((u) => storage.remove("profile_" + u.id));
    Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX + "forum_") || k.startsWith(PREFIX + "conversations") || k.startsWith(PREFIX + "messages"))
      .forEach((k) => localStorage.removeItem(k));
  },
};

// ── Conversations (DM system) ─────────────────────────────────────────────────
export const conversationStorage = {
  getAll: () => storage.get("conversations") || [],
  _save:  (c) => storage.set("conversations", c),
  forUser:    (uid) => conversationStorage.getAll().filter((c) => c.participants.includes(uid)),
  pendingFor: (uid) => conversationStorage.forUser(uid).filter((c) => c.status === "pending" && c.initiatorId !== uid),
  activeFor:  (uid) => conversationStorage.forUser(uid).filter((c) => c.status === "active"),
  existing:   (u1, u2) => conversationStorage.getAll().find((c) => c.participants.includes(u1) && c.participants.includes(u2) && c.status !== "declined"),
  create: ({ initiatorId, recipientId, initiatorName, initiatorEmail, note }) => {
    const conv = { id: genId(), participants: [initiatorId, recipientId], initiatorId, initiatorName, initiatorEmail, note, status: "pending", messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    conversationStorage._save([...conversationStorage.getAll(), conv]);
    return conv;
  },
  accept: (id) => conversationStorage._save(conversationStorage.getAll().map((c) => c.id === id ? { ...c, status: "active", updatedAt: new Date().toISOString() } : c)),
  decline:(id) => conversationStorage._save(conversationStorage.getAll().map((c) => c.id === id ? { ...c, status: "declined" } : c)),
  addMessage: (id, { fromUserId, fromName, text }) => {
    conversationStorage._save(conversationStorage.getAll().map((c) =>
      c.id === id ? { ...c, messages: [...c.messages, { id: genId(), fromUserId, fromName, text, ts: new Date().toISOString() }], updatedAt: new Date().toISOString() } : c
    ));
  },
};

// ── Forum membership (join event chat without changing profile) ───────────────
export const forumMembershipStorage = {
  getJoined: (userId) => storage.get("forum_joined_" + userId) || [],
  join:  (userId, key) => { const j = forumMembershipStorage.getJoined(userId); if (!j.includes(key)) storage.set("forum_joined_" + userId, [...j, key]); },
  leave: (userId, key) => storage.set("forum_joined_" + userId, forumMembershipStorage.getJoined(userId).filter((k) => k !== key)),
  isJoined: (userId, key) => forumMembershipStorage.getJoined(userId).includes(key),
};

// ── Forum posts (Reddit-style) ────────────────────────────────────────────────
export const forumStorage = {
  getPosts: (key) => storage.get("forum_" + key) || [],
  _save:    (key, posts) => storage.set("forum_" + key, posts),

  addPost: (key, { userId, userName, photoUrl, title, body, imageUrl }) => {
    const post = { id: genId(), userId, userName, photoUrl, title, body, imageUrl: imageUrl || null, upvotes: [], downvotes: [], comments: [], ts: new Date().toISOString() };
    forumStorage._save(key, [...forumStorage.getPosts(key), post]);
    return post;
  },

  votePost: (key, postId, userId, type) => {
    const posts = forumStorage.getPosts(key).map((p) => {
      if (p.id !== postId) return p;
      let up   = p.upvotes.filter((u) => u !== userId);
      let down = p.downvotes.filter((u) => u !== userId);
      if (type === "up"   && !p.upvotes.includes(userId))   up   = [...up, userId];
      if (type === "down" && !p.downvotes.includes(userId)) down = [...down, userId];
      return { ...p, upvotes: up, downvotes: down };
    });
    forumStorage._save(key, posts);
  },

  addComment: (key, postId, { userId, userName, photoUrl, text }) => {
    const posts = forumStorage.getPosts(key).map((p) =>
      p.id === postId
        ? { ...p, comments: [...p.comments, { id: genId(), userId, userName, photoUrl, text, upvotes: [], downvotes: [], ts: new Date().toISOString() }] }
        : p
    );
    forumStorage._save(key, posts);
  },

  voteComment: (key, postId, commentId, userId, type) => {
    const posts = forumStorage.getPosts(key).map((p) => {
      if (p.id !== postId) return p;
      const comments = p.comments.map((c) => {
        if (c.id !== commentId) return c;
        let up   = c.upvotes.filter((u) => u !== userId);
        let down = c.downvotes.filter((u) => u !== userId);
        if (type === "up"   && !c.upvotes.includes(userId))   up   = [...up, userId];
        if (type === "down" && !c.downvotes.includes(userId)) down = [...down, userId];
        return { ...c, upvotes: up, downvotes: down };
      });
      return { ...p, comments };
    });
    forumStorage._save(key, posts);
  },
};

// ── Events (admin-managed) ────────────────────────────────────────────────────
export const eventStorage = {
  getAll:  () => storage.get("events") || [],
  _save:   (e) => storage.set("events", e),
  add:     (event) => { const e = { ...event, id: event.id || genId() }; eventStorage._save([...eventStorage.getAll(), e]); return e; },
  update:  (id, data) => eventStorage._save(eventStorage.getAll().map((e) => e.id === id ? { ...e, ...data } : e)),
  delete:  (id) => eventStorage._save(eventStorage.getAll().filter((e) => e.id !== id)),
  getById: (id) => eventStorage.getAll().find((e) => e.id === id) || null,
};

// ── Coaches (admin-managed) ───────────────────────────────────────────────────
export const coachStorage = {
  getAll:  () => storage.get("coaches") || [],
  _save:   (c) => storage.set("coaches", c),
  add:     (name) => { const c = { id: genId(), name }; coachStorage._save([...coachStorage.getAll(), c]); return c; },
  update:  (id, name) => coachStorage._save(coachStorage.getAll().map((c) => c.id === id ? { ...c, name } : c)),
  delete:  (id) => coachStorage._save(coachStorage.getAll().filter((c) => c.id !== id)),
};
