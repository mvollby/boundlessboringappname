export async function geocodeLocation(locationText) {
  if (!locationText?.trim()) return null;
  const encoded = encodeURIComponent(locationText.trim());
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=1`,
      { headers: { "Accept-Language": "en", "User-Agent": "BoundlessCommunityApp/1.0" } }
    );
    const data = await res.json();
    if (!data.length) return null;
    const { lat, lon, display_name } = data[0];
    return { lat: parseFloat(lat), lng: parseFloat(lon), displayName: display_name };
  } catch { return null; }
}

// Haversine distance in miles between two lat/lng points
export function distanceMiles(lat1, lng1, lat2, lng2) {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
