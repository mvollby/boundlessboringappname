// Fetch multiple autocomplete suggestions for a location query
export async function searchLocations(query) {
  if (!query?.trim() || query.trim().length < 3) return [];
  const encoded = encodeURIComponent(query.trim());
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=6&addressdetails=1`,
      { headers: { "Accept-Language": "en", "User-Agent": "BoundlessCommunityApp/1.0" } }
    );
    const data = await res.json();
    return data.map((item) => ({
      displayName: item.display_name,
      shortName: [
        item.address?.city || item.address?.town || item.address?.village || item.address?.county,
        item.address?.state || item.address?.region,
        item.address?.country,
      ].filter(Boolean).join(", "),
      lat:     parseFloat(item.lat),
      lng:     parseFloat(item.lon),
      city:    item.address?.city || item.address?.town || item.address?.village || "",
      state:   item.address?.state || item.address?.region || "",
      country: item.address?.country || "",
    }));
  } catch { return []; }
}

// Single geocode (backwards compat)
export async function geocodeLocation(locationText) {
  const results = await searchLocations(locationText);
  if (!results.length) return null;
  const r = results[0];
  return { lat: r.lat, lng: r.lng, displayName: r.displayName };
}

// Haversine distance in miles
export function distanceMiles(lat1, lng1, lat2, lng2) {
  const R    = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a    = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
