import { authStorage, profileStorage, eventStorage, coachStorage, storage } from "./storage";

export const ADMIN_ID = "boundless_admin";

// ── Year logic (used everywhere events display a date) ───────────────────────
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export function eventYear(monthName) {
  const idx  = MONTHS.indexOf(monthName);
  const now  = new Date();
  return idx >= now.getMonth() ? now.getFullYear() : now.getFullYear() + 1;
}

// ── Master seed entry point ──────────────────────────────────────────────────
export function runSeed() {
  seedAdmin();
  if (!storage.get("coaches_seeded_v1")) { seedCoaches(); storage.set("coaches_seeded_v1", true); }
  if (!storage.get("events_seeded_v1"))  { seedEvents();  storage.set("events_seeded_v1", true);  }
}

// ── Admin user + profile ──────────────────────────────────────────────────────
function seedAdmin() {
  const users = authStorage.getUsers();
  if (!users.find((u) => u.id === ADMIN_ID)) {
    authStorage.saveUsers([{ id: ADMIN_ID, name: "Admin", email: "admin@gmail.com", password: "admin123", isAdmin: true }, ...users]);
  }
  if (!profileStorage.get(ADMIN_ID)) {
    profileStorage.set(ADMIN_ID, {
      userId: ADMIN_ID, name: "Admin", email: "admin@gmail.com",
      discipline: "Multisport", isAdmin: true,
      location: "Louisville, Colorado", lat: 39.9778, lng: -105.1319,
      city: "Louisville", state: "Colorado", country: "United States",
      gender: "", bio: "", coach: "", events: [], photoUrl: null,
    });
  }
}

// ── 34 Coaches ────────────────────────────────────────────────────────────────
function seedCoaches() {
  [
    "Addie Bracy","Alysha Davis","Alyssa Rodriguez","Anna Hicks","Benjamin Davis","Ben Dicke",
    "Brad Stahlman","Colleen Miracle","Cristhian Ravelo","David Hettena","Derek Murrow",
    "Duncan Callahan","Florence Normand","Jason Friedman MD","Jeff Winkler","Jill Becker",
    "Joey Hassett","Joe Lewis","John Benson","Jonathan Clinthorne","Junko Kazukawa",
    "Justin Ross PsyD","Kathy Pidcock","Klavs Miller","Kyleigh Spearing","Lance Parker",
    "Noah Granigan","Peyton Bilo","Ryan Krol","Rylee McMullen","Travis McCabe",
    "Scott Jordan MD","Scott Tietzel","Skyler Kottenstette",
  ].forEach((name) => coachStorage.add(name));
}

// ── 24 Running + 25 Cycling events ───────────────────────────────────────────
function seedEvents() {
  const running = [
    { id:"evt_r01", name:"Western States 100",               sportType:"Running", distance:"100 Miles",     month:"June",      city:"Olympic Valley",    state:"California",   lat:39.1969, lng:-120.2358, featured:false },
    { id:"evt_r02", name:"Hardrock 100",                     sportType:"Running", distance:"100 Miles",     month:"July",      city:"Silverton",         state:"Colorado",     lat:37.8122, lng:-107.6651, featured:false },
    { id:"evt_r03", name:"Leadville Trail 100 Run",          sportType:"Running", distance:"100 Miles",     month:"August",    city:"Leadville",         state:"Colorado",     lat:39.2508, lng:-106.2925, featured:true  },
    { id:"evt_r04", name:"Gorge Waterfalls 100K",            sportType:"Running", distance:"100K",          month:"April",     city:"Cascade Locks",     state:"Oregon",       lat:45.6696, lng:-121.8988, featured:false },
    { id:"evt_r05", name:"Black Canyon Ultras",              sportType:"Running", distance:"100K",          month:"February",  city:"Mayer",             state:"Arizona",      lat:34.3953, lng:-112.2330, featured:false },
    { id:"evt_r06", name:"Cocodona 250",                     sportType:"Running", distance:"250 Miles",     month:"May",       city:"Black Canyon City", state:"Arizona",      lat:34.0602, lng:-112.1368, featured:false },
    { id:"evt_r07", name:"Javelina Jundred",                 sportType:"Running", distance:"100 Miles",     month:"October",   city:"Fountain Hills",    state:"Arizona",      lat:33.5934, lng:-111.7178, featured:false },
    { id:"evt_r08", name:"Moab Trail Marathon",              sportType:"Running", distance:"Trail Marathon", month:"November",  city:"Moab",              state:"Utah",         lat:38.5733, lng:-109.5498, featured:false },
    { id:"evt_r09", name:"Speedgoat Mountain Races",         sportType:"Running", distance:"50K",           month:"July",      city:"Snowbird",          state:"Utah",         lat:40.5830, lng:-111.6571, featured:false },
    { id:"evt_r10", name:"Run Rabbit Run 100",               sportType:"Running", distance:"100 Miles",     month:"September", city:"Steamboat Springs", state:"Colorado",     lat:40.4850, lng:-106.8317, featured:false },
    { id:"evt_r11", name:"Vermont 100",                      sportType:"Running", distance:"100 Miles",     month:"July",      city:"West Windsor",      state:"Vermont",      lat:43.5498, lng:-72.5104,  featured:false },
    { id:"evt_r12", name:"High Lonesome 100",                sportType:"Running", distance:"100 Miles",     month:"July",      city:"Buena Vista",       state:"Colorado",     lat:38.8436, lng:-106.1314, featured:false },
    { id:"evt_r13", name:"Ouray 100 Mile Endurance Run",     sportType:"Running", distance:"100 Miles",     month:"July",      city:"Ouray",             state:"Colorado",     lat:38.0228, lng:-107.6715, featured:false },
    { id:"evt_r14", name:"Zion Ultras",                      sportType:"Running", distance:"100 Miles",     month:"April",     city:"Virgin",            state:"Utah",         lat:37.2030, lng:-113.1408, featured:false },
    { id:"evt_r15", name:"Bryce Canyon Ultras",              sportType:"Running", distance:"100 Miles",     month:"May",       city:"Bryce Canyon City", state:"Utah",         lat:37.6833, lng:-112.1619, featured:false },
    { id:"evt_r16", name:"Pikes Peak Marathon",              sportType:"Running", distance:"Trail Marathon", month:"September", city:"Manitou Springs",   state:"Colorado",     lat:38.8586, lng:-104.9186, featured:false },
    { id:"evt_r17", name:"Bigfoot 200",                      sportType:"Running", distance:"200 Miles",     month:"August",    city:"Randle",            state:"Washington",   lat:46.5290, lng:-121.9527, featured:false },
    { id:"evt_r18", name:"Tahoe 200",                        sportType:"Running", distance:"200 Miles",     month:"September", city:"Homewood",          state:"California",   lat:39.0895, lng:-120.1622, featured:false },
    { id:"evt_r19", name:"Moab 240",                         sportType:"Running", distance:"250 Miles",     month:"October",   city:"Moab",              state:"Utah",         lat:38.5733, lng:-109.5498, featured:false },
    { id:"evt_r20", name:"Lake Sonoma 50",                   sportType:"Running", distance:"50 Miles",      month:"April",     city:"Healdsburg",        state:"California",   lat:38.6102, lng:-122.8697, featured:false },
    { id:"evt_r21", name:"Desert Rats Trail Running Festival",sportType:"Running",distance:"100K",          month:"April",     city:"Fruita",            state:"Colorado",     lat:39.1586, lng:-108.7278, featured:false },
    { id:"evt_r22", name:"Silver Rush 50",                   sportType:"Running", distance:"50 Miles",      month:"July",      city:"Leadville",         state:"Colorado",     lat:39.2508, lng:-106.2925, featured:false },
    { id:"evt_r23", name:"Never Summer 100K",                sportType:"Running", distance:"100K",          month:"July",      city:"Gould",             state:"Colorado",     lat:40.6178, lng:-106.1153, featured:false },
    { id:"evt_r24", name:"Grand Mesa Ultras",                sportType:"Running", distance:"50 Miles",      month:"July",      city:"Mesa",              state:"Colorado",     lat:39.1677, lng:-108.1302, featured:false },
  ];

  const cycling = [
    { id:"evt_c01", name:"Unbound Gravel",                   sportType:"Gravel", distance:"200 Miles",      month:"May",       city:"Emporia",           state:"Kansas",        lat:38.4039, lng:-96.1817,  featured:true  },
    { id:"evt_c02", name:"Leadville Trail 100 MTB",          sportType:"MTB",    distance:"100 Miles",      month:"August",    city:"Leadville",         state:"Colorado",      lat:39.2508, lng:-106.2925, featured:true  },
    { id:"evt_c03", name:"SBT GRVL",                         sportType:"Gravel", distance:"125 Miles",      month:"August",    city:"Steamboat Springs", state:"Colorado",      lat:40.4850, lng:-106.8317, featured:true  },
    { id:"evt_c04", name:"Belgian Waffle Ride California",   sportType:"Gravel", distance:"125 Miles",      month:"April",     city:"Del Mar",           state:"California",    lat:32.9595, lng:-117.2653, featured:false },
    { id:"evt_c05", name:"Big Sugar Gravel",                 sportType:"Gravel", distance:"100 Miles",      month:"October",   city:"Bentonville",       state:"Arkansas",      lat:36.3729, lng:-94.2088,  featured:true  },
    { id:"evt_c06", name:"Mid South Gravel",                 sportType:"Gravel", distance:"100 Miles",      month:"March",     city:"Stillwater",        state:"Oklahoma",      lat:36.1156, lng:-97.0584,  featured:false },
    { id:"evt_c07", name:"Sea Otter Classic Gravel",         sportType:"Gravel", distance:"100 Miles",      month:"April",     city:"Monterey",          state:"California",    lat:36.6002, lng:-121.8947, featured:false },
    { id:"evt_c08", name:"Rebecca's Private Idaho",          sportType:"Gravel", distance:"100 Miles",      month:"August",    city:"Sun Valley",        state:"Idaho",         lat:43.6963, lng:-114.3535, featured:false },
    { id:"evt_c09", name:"Gravel Worlds",                    sportType:"Gravel", distance:"150 Miles",      month:"August",    city:"Lincoln",           state:"Nebraska",      lat:40.8136, lng:-96.7026,  featured:false },
    { id:"evt_c10", name:"Oregon Trail Gravel Grinder",      sportType:"Gravel", distance:"350 Miles",      month:"June",      city:"Bend",              state:"Oregon",        lat:44.0582, lng:-121.3153, featured:false },
    { id:"evt_c11", name:"The Rift Gravel USA",              sportType:"Gravel", distance:"100 Miles",      month:"October",   city:"Fruita",            state:"Colorado",      lat:39.1586, lng:-108.7278, featured:false },
    { id:"evt_c12", name:"Lost and Found Gravel Festival",   sportType:"Gravel", distance:"100 Miles",      month:"June",      city:"Portola",           state:"California",    lat:39.8110, lng:-120.4696, featured:false },
    { id:"evt_c13", name:"Mammoth Tuff",                     sportType:"Gravel", distance:"75 Miles",       month:"September", city:"Mammoth Lakes",     state:"California",    lat:37.6485, lng:-118.9721, featured:false },
    { id:"evt_c14", name:"Rasputitsa Gravel",                sportType:"Gravel", distance:"50 Miles",       month:"April",     city:"Burke",             state:"Vermont",       lat:44.5989, lng:-71.9473,  featured:false },
    { id:"evt_c15", name:"Vermont Overland",                 sportType:"Gravel", distance:"50 Miles",       month:"August",    city:"West Windsor",      state:"Vermont",       lat:43.5498, lng:-72.5104,  featured:false },
    { id:"evt_c16", name:"The Rad Dirt Fest",                sportType:"Gravel", distance:"100 Miles",      month:"May",       city:"Trinidad",          state:"Colorado",      lat:37.1694, lng:-104.5005, featured:false },
    { id:"evt_c17", name:"HooDoo 500 Gravel",                sportType:"Gravel", distance:"350 Miles",      month:"October",   city:"St. George",        state:"Utah",          lat:37.0965, lng:-113.5684, featured:false },
    { id:"evt_c18", name:"Chequamegon MTB Festival",         sportType:"MTB",    distance:"50 Miles",       month:"September", city:"Hayward",           state:"Wisconsin",     lat:46.0130, lng:-91.4843,  featured:false },
    { id:"evt_c19", name:"Breck Epic",                       sportType:"MTB",    distance:"200 Miles",      month:"August",    city:"Breckenridge",      state:"Colorado",      lat:39.4817, lng:-106.0384, featured:false },
    { id:"evt_c20", name:"Little Sugar MTB",                 sportType:"MTB",    distance:"100K",           month:"October",   city:"Bentonville",       state:"Arkansas",      lat:36.3729, lng:-94.2088,  featured:false },
    { id:"evt_c21", name:"Pierre's Hole 100",                sportType:"MTB",    distance:"100 Miles",      month:"August",    city:"Victor",            state:"Idaho",         lat:43.6043, lng:-111.1129, featured:false },
    { id:"evt_c22", name:"High Cascades 100",                sportType:"MTB",    distance:"100 Miles",      month:"July",      city:"Bend",              state:"Oregon",        lat:44.0582, lng:-121.3153, featured:false },
    { id:"evt_c23", name:"Tahoe Trail MTB",                  sportType:"MTB",    distance:"100K",           month:"July",      city:"Truckee",           state:"California",    lat:39.3280, lng:-120.1833, featured:false },
    { id:"evt_c24", name:"Snowmass 50 MTB",                  sportType:"MTB",    distance:"50 Miles",       month:"July",      city:"Snowmass Village",  state:"Colorado",      lat:39.2137, lng:-106.9420, featured:false },
    { id:"evt_c25", name:"Telluride 100",                    sportType:"MTB",    distance:"100 Miles",      month:"June",      city:"Telluride",         state:"Colorado",      lat:37.9375, lng:-107.8123, featured:false },
  ];

  [...running, ...cycling].forEach((e) => eventStorage.add({
    ...e,
    country: "United States",
    photos: [],
    description: "",
    createdBy: "Admin",
  }));
}
