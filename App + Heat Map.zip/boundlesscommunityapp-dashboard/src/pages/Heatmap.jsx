import { useState, useRef, useEffect, useMemo } from "react";
import { T } from "../theme";
import { Icon } from "../Icons";

// ── Running races ────────────────────────────────────────────────────────────
const RUNNING = [
  { city:"Olympic Valley",state:"CA",lat:39.1968,lng:-120.2354,events:[{name:"Western States 100",distance:"100 Miler",when:"June"}]},
  { city:"Silverton",state:"CO",lat:37.8116,lng:-107.6645,events:[{name:"Hardrock 100",distance:"100 Miler",when:"July"}]},
  { city:"Leadville",state:"CO",lat:39.2508,lng:-106.2925,events:[{name:"Leadville Trail 100",distance:"100 Miler",when:"August"},{name:"Silver Rush 50",distance:"50 Miler",when:"July"}]},
  { city:"Cascade Locks",state:"OR",lat:45.6701,lng:-121.8909,events:[{name:"Gorge Waterfalls 100K",distance:"100K",when:"April"}]},
  { city:"Mayer",state:"AZ",lat:34.3961,lng:-112.2346,events:[{name:"Black Canyon Ultras",distance:"100K",when:"February"}]},
  { city:"Black Canyon City",state:"AZ",lat:34.0712,lng:-112.1510,events:[{name:"Cocodona 250",distance:"250 Miler",when:"May"}]},
  { city:"Fountain Hills",state:"AZ",lat:33.6117,lng:-111.7174,events:[{name:"Javelina Jundred",distance:"100 Miler",when:"October"}]},
  { city:"Moab",state:"UT",lat:38.5733,lng:-109.5498,events:[{name:"Moab Trail Marathon",distance:"Trail Marathon",when:"November"},{name:"Moab 240",distance:"250 Miler",when:"October"}]},
  { city:"Snowbird",state:"UT",lat:40.5830,lng:-111.6538,events:[{name:"Speedgoat Mountain Races",distance:"50K",when:"July"}]},
  { city:"Steamboat Springs",state:"CO",lat:40.4850,lng:-106.8317,events:[{name:"Run Rabbit Run 100",distance:"100 Miler",when:"September"}]},
  { city:"West Windsor",state:"VT",lat:43.4687,lng:-72.4573,events:[{name:"Vermont 100",distance:"100 Miler",when:"July"}]},
  { city:"Buena Vista",state:"CO",lat:38.8422,lng:-106.1311,events:[{name:"High Lonesome 100",distance:"100 Miler",when:"July"}]},
  { city:"Ouray",state:"CO",lat:38.0228,lng:-107.6714,events:[{name:"Ouray 100 Mile Endurance Run",distance:"100 Miler",when:"July"}]},
  { city:"Virgin",state:"UT",lat:37.2041,lng:-113.1833,events:[{name:"Zion Ultras",distance:"100 Miler",when:"April"}]},
  { city:"Bryce Canyon City",state:"UT",lat:37.6739,lng:-112.1511,events:[{name:"Bryce Canyon Ultras",distance:"100 Miler",when:"May"}]},
  { city:"Manitou Springs",state:"CO",lat:38.8586,lng:-104.9175,events:[{name:"Pikes Peak Marathon",distance:"Trail Marathon",when:"September"}]},
  { city:"Randle",state:"WA",lat:46.5296,lng:-121.9487,events:[{name:"Bigfoot 200",distance:"200 Miler",when:"August"}]},
  { city:"Homewood",state:"CA",lat:39.0871,lng:-120.1610,events:[{name:"Tahoe 200",distance:"200 Miler",when:"September"}]},
  { city:"Healdsburg",state:"CA",lat:38.6107,lng:-122.8692,events:[{name:"Lake Sonoma 50",distance:"50 Miler",when:"April"}]},
  { city:"Fruita",state:"CO",lat:39.1588,lng:-108.7290,events:[{name:"Desert Rats Trail Running Festival",distance:"100K",when:"April"}]},
  { city:"Gould",state:"CO",lat:40.5194,lng:-106.0200,events:[{name:"Never Summer 100K",distance:"100K",when:"July"}]},
  { city:"Mesa",state:"CO",lat:39.1541,lng:-108.0959,events:[{name:"Grand Mesa Ultras",distance:"50 Miler",when:"July"}]},
];

// ── Cycling races (placeholder) ──────────────────────────────────────────────
const CYCLING = [
  { city:"Emporia",state:"KS",lat:38.4039,lng:-96.1817,events:[{name:"UNBOUND Gravel",distance:"200 Miler",when:"June"}]},
  { city:"Fayetteville",state:"AR",lat:36.0822,lng:-94.1719,events:[{name:"Big Sugar Gravel",distance:"100 Miler",when:"October"}]},
  { city:"Leadville",state:"CO",lat:39.2508,lng:-106.2925,events:[{name:"Leadville Trail 100 MTB",distance:"100 Miler",when:"August"}]},
  { city:"Steamboat Springs",state:"CO",lat:40.4850,lng:-106.8317,events:[{name:"SBT GRVL",distance:"100 Miler",when:"August"}]},
  { city:"Stillwater",state:"OK",lat:36.1156,lng:-97.0584,events:[{name:"Mid South Gravel",distance:"100 Miler",when:"March"}]},
  { city:"Bentonville",state:"AR",lat:36.3729,lng:-94.2088,events:[{name:"Oz Trails Off-Road",distance:"100K",when:"October"}]},
];

// Tag each event with its sport type
const tagSport = (cities, sportTag) =>
  cities.map(c => ({ ...c, events: c.events.map(e => ({ ...e, sport: sportTag })) }));

const RUNNING_TAGGED = tagSport(RUNNING, "Runner");
const CYCLING_TAGGED = tagSport(CYCLING, "Cyclist");

const DIST_COLORS = {
  "100 Miler":     { bg:"#EDE9FE", color:"#7C3AED", border:"#C4B5FD" },
  "200 Miler":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "250 Miler":     { bg:"#FCE7F3", color:"#DB2777", border:"#F9A8D4" },
  "100K":          { bg:"#DBEAFE", color:"#2563EB", border:"#93C5FD" },
  "50 Miler":      { bg:"#D1FAE5", color:"#059669", border:"#6EE7B7" },
  "50K":           { bg:"#FEF3C7", color:"#D97706", border:"#FCD34D" },
  "Trail Marathon":{ bg:"#FEE2E2", color:"#DC2626", border:"#FCA5A5" },
  "Ultra":         { bg:"#E0E7FF", color:"#4338CA", border:"#A5B4FC" },
};

const SPORT_BADGE = {
  "Runner":  { bg:"#D1FAE5", color:"#065F46" },
  "Cyclist": { bg:"#DBEAFE", color:"#1E40AF" },
};

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const ALL_DISTANCES = ["All","100 Miler","200 Miler","250 Miler","100K","50 Miler","50K","Trail Marathon"];

// Dot colors per sport
const COLORS = {
  Runner:  { main:"#7C3AED", glow:"rgba(124,58,237," },
  Cyclist: { main:"#3B82F6", glow:"rgba(59,130,246," },
};

export default function Heatmap({ onOpenEvent }) {
  const mapRef = useRef(null);
  const leafletReady = useRef(false);
  const mapInstance = useRef(null);
  const markersRef = useRef([]);
  const [selected, setSelected] = useState(null);
  const [sport, setSport] = useState("Runner");
  const [filterState, setFilterState] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [filterDist, setFilterDist] = useState("All");

  // Merge data based on sport
  const sourceData = useMemo(() => {
    const tagCities = (cities, sp) => cities.map(c => ({ ...c, _sport: sp }));
    if (sport === "Runner") return tagCities(RUNNING_TAGGED, "Runner");
    if (sport === "Cyclist") return tagCities(CYCLING_TAGGED, "Cyclist");
    // Multisport: merge both, track dominant sport per city
    const merged = {};
    RUNNING_TAGGED.forEach(c => {
      const key = `${c.city},${c.state}`;
      merged[key] = { ...c, _sport: "Runner", events: [...c.events] };
    });
    CYCLING_TAGGED.forEach(c => {
      const key = `${c.city},${c.state}`;
      if (!merged[key]) {
        merged[key] = { ...c, _sport: "Cyclist", events: [...c.events] };
      } else {
        merged[key].events = [...merged[key].events, ...c.events.filter(e => !merged[key].events.some(x => x.name === e.name))];
        // Keep _sport as "Runner" if has both — or mark as mixed but color by first
      }
    });
    return Object.values(merged);
  }, [sport]);

  // Unique states from source data, sorted
  const stateOptions = useMemo(() => {
    const s = [...new Set(sourceData.map(c => c.state))].sort();
    return s;
  }, [sourceData]);

  // Available distances from source data
  const distOptions = useMemo(() => {
    const d = new Set();
    sourceData.forEach(c => c.events.forEach(e => { if (e.distance) d.add(e.distance); }));
    return ALL_DISTANCES.filter(dd => dd === "All" || d.has(dd));
  }, [sourceData]);

  const filtered = useMemo(() => {
    return sourceData.map(c => {
      if (filterState !== "All" && c.state !== filterState) return { ...c, filteredEvents: [] };
      const me = c.events.filter(e => {
        if (filterMonth !== "All" && e.when !== filterMonth) return false;
        if (filterDist !== "All" && e.distance !== filterDist) return false;
        return true;
      });
      return { ...c, filteredEvents: me };
    }).filter(c => c.filteredEvents.length > 0);
  }, [sourceData, filterState, filterMonth, filterDist]);

  // Load Leaflet
  useEffect(() => {
    if (leafletReady.current) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.onload = () => { leafletReady.current = true; initMap(); };
    document.head.appendChild(script);
    return () => { if (mapInstance.current) { mapInstance.current.remove(); mapInstance.current = null; } };
  }, []);

  const initMap = () => {
    if (!mapRef.current || !window.L || mapInstance.current) return;
    const L = window.L;
    const map = L.map(mapRef.current, {
      center: [39, -98], zoom: 4, minZoom: 3, maxZoom: 12,
      zoomControl: true, attributionControl: false, scrollWheelZoom: true,
      maxBounds: [[15, -180], [72, -50]], maxBoundsViscosity: 1.0,
    });
    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 18, subdomains: "abcd",
    }).addTo(map);
    mapInstance.current = map;
    updateMarkers();
  };

  useEffect(() => {
    if (leafletReady.current && mapRef.current && !mapInstance.current) initMap();
  });

  const updateMarkers = () => {
    if (!mapInstance.current || !window.L) return;
    const L = window.L;
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    filtered.forEach((c, idx) => {
      const intensity = c.filteredEvents.length;
      const r = 7 + intensity * 5;
      const opacity = 0.55 + Math.min(intensity / 3, 0.45);
      const clr = COLORS[c._sport] || COLORS.Runner;

      const icon = L.divIcon({
        className: "",
        html: `<div style="
          width:${r*2}px;height:${r*2}px;border-radius:50%;
          background:radial-gradient(circle,${clr.glow}${opacity}) 0%,${clr.glow}${opacity*0.4}) 55%,${clr.glow}0) 100%);
          box-shadow:0 0 ${r+4}px ${r/2}px ${clr.glow}${opacity*0.35});
          cursor:pointer;
        "></div>`,
        iconSize: [r*2, r*2],
        iconAnchor: [r, r],
      });

      const marker = L.marker([c.lat, c.lng], { icon }).addTo(mapInstance.current);
      marker.bindTooltip(
        `<div style="font-family:Inter,sans-serif;font-weight:700;font-size:12px;color:#1E1B4B;">${c.city}, ${c.state}</div>
         <div style="font-family:Inter,sans-serif;font-size:11px;color:#6B7280;">${c.filteredEvents.length} race${c.filteredEvents.length!==1?"s":""}</div>`,
        { direction:"top", offset:[0,-r], className:"boundless-tooltip" }
      );
      marker.on("click", () => setSelected(idx));
      markersRef.current.push(marker);
    });
  };

  useEffect(() => { updateMarkers(); }, [filtered]);

  useEffect(() => {
    if (document.getElementById("boundless-leaflet-css")) return;
    const style = document.createElement("style");
    style.id = "boundless-leaflet-css";
    style.textContent = `
      .boundless-tooltip { background:#fff !important; border:1.5px solid #E9E4FF !important; border-radius:10px !important; padding:8px 12px !important; box-shadow:0 4px 16px rgba(124,58,237,0.12) !important; }
      .boundless-tooltip::before { border-top-color:#E9E4FF !important; }
      .leaflet-container { border-radius:20px; font-family:Inter,sans-serif; }
    `;
    document.head.appendChild(style);
  }, []);

  const handleSportChange = (s) => { setSport(s); setFilterDist("All"); setFilterState("All"); setSelected(null); };
  const clearAll = () => { setFilterState("All"); setFilterMonth("All"); setFilterDist("All"); setSelected(null); };
  const activeFilters = (filterState !== "All" ? 1 : 0) + (filterMonth !== "All" ? 1 : 0) + (filterDist !== "All" ? 1 : 0);
  const selectedCity = selected !== null ? filtered[selected] : null;

  return (
    <div style={S.root}>
      <div style={S.pageHeader}>
        <div>
          <h2 style={S.title}>Race Heatmap</h2>
          <p style={S.sub}>Ultra & trail races across the USA</p>
        </div>
        {activeFilters > 0 && (
          <button style={S.clearAllBtn} onClick={clearAll}>
            Clear filters <span style={S.filterBadge}>{activeFilters}</span>
          </button>
        )}
      </div>

      <div style={S.filterPanel}>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Sport</label>
          <select style={S.select} value={sport} onChange={e => handleSportChange(e.target.value)}>
            <option value="Runner">Runner</option>
            <option value="Cyclist">Cyclist</option>
            <option value="Multisport">Multisport</option>
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>State</label>
          <select style={S.select} value={filterState} onChange={e => { setFilterState(e.target.value); setSelected(null); }}>
            <option value="All">All states</option>
            {stateOptions.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Month</label>
          <select style={S.select} value={filterMonth} onChange={e => { setFilterMonth(e.target.value); setSelected(null); }}>
            <option value="All">All months</option>
            {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
        <div style={S.filterGroup}>
          <label style={S.filterLabel}>Distance</label>
          <select style={S.select} value={filterDist} onChange={e => { setFilterDist(e.target.value); setSelected(null); }}>
            <option value="All">All distances</option>
            {distOptions.filter(d => d !== "All").map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>

      <div style={S.mapContainer}>
        <div ref={mapRef} style={S.mapInner} />
      </div>

      {selectedCity && (
        <div style={S.detailCard}>
          <div style={S.detailTop}>
            <div>
              <h3 style={S.detailCity}>{selectedCity.city}, {selectedCity.state}</h3>
              <p style={S.detailSub}>{selectedCity.filteredEvents.length} race{selectedCity.filteredEvents.length!==1?"s":""}</p>
            </div>
            <button style={S.closeBtn} onClick={() => setSelected(null)}>
              <Icon.X style={{width:16,height:16}}/>
            </button>
          </div>
          <div style={S.eventList}>
            {selectedCity.filteredEvents.map((e, i) => {
              const dc = DIST_COLORS[e.distance] || DIST_COLORS["Ultra"];
              const sb = SPORT_BADGE[e.sport] || { bg:"#EDE9FE", color:"#7C3AED" };
              return (
                <div key={i} style={S.eventRow}>
                  <div style={S.eventLeft}>
                    <span style={S.eventName}>{e.name}</span>
                    <div style={S.eventMeta}>
                      <Icon.Flag style={{width:11,height:11,color:T.muted}}/> {e.when}
                    </div>
                  </div>
                  <div style={S.pillRow}>
                    <span style={{...S.sportPill, background:sb.bg, color:sb.color}}>{e.sport}</span>
                    {e.distance && (
                      <span style={{...S.distPill, background:dc.bg, color:dc.color, borderColor:dc.border}}>{e.distance}</span>
                    )}
                    <button style={S.forumBtn} onClick={() => onOpenEvent && onOpenEvent(e.name)}>
                      Open Forum <Icon.ChevronRight style={{width:13,height:13}}/>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

const S = {
  root: { paddingBottom: 60 },
  pageHeader: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:18, flexWrap:"wrap", gap:12 },
  title: { fontSize:22, fontWeight:800, margin:"0 0 3px", color:T.dark },
  sub: { fontSize:14, color:T.muted, margin:0 },
  clearAllBtn: { display:"flex", alignItems:"center", gap:7, background:"none", border:"none", color:T.danger, fontSize:13, fontWeight:600, cursor:"pointer", padding:0 },
  filterBadge: { background:T.danger, color:"#fff", borderRadius:T.rPill, padding:"1px 6px", fontSize:11, fontWeight:700 },

  filterPanel: {
    background:"#fff", borderRadius:T.rXL, padding:"16px 24px", marginBottom:18,
    boxShadow:T.shadowSm, border:`1.5px solid ${T.border}`,
    display:"flex", flexWrap:"wrap", gap:16, alignItems:"flex-end",
  },
  filterGroup: { display:"flex", flexDirection:"column", gap:4 },
  filterLabel: { fontSize:11, fontWeight:700, color:T.dark, textTransform:"uppercase", letterSpacing:"0.04em" },
  select: {
    padding:"9px 14px", borderRadius:T.r, border:`1.5px solid ${T.border}`,
    fontSize:13, background:T.bg, color:T.dark, outline:"none", fontFamily:T.fontBase, minWidth:150,
    cursor:"pointer",
  },

  mapContainer: { background:"#fff", borderRadius:T.rXL, overflow:"hidden", boxShadow:T.shadow, border:`1.5px solid ${T.border}`, marginBottom:18 },
  mapInner: { width:"100%", height:520, borderRadius:20 },

  detailCard: { background:"#fff", borderRadius:T.rXL, padding:"20px 24px", boxShadow:T.shadow, border:`1.5px solid ${T.border}`, marginBottom:18 },
  detailTop: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 },
  detailCity: { fontSize:18, fontWeight:800, color:T.dark, margin:0 },
  detailSub: { fontSize:13, color:T.primary, margin:"3px 0 0", fontWeight:600 },
  closeBtn: { background:"none", border:"none", cursor:"pointer", color:T.muted, padding:4 },
  eventList: { display:"flex", flexDirection:"column", gap:8 },
  eventRow: { display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, padding:"10px 14px", background:T.bg, borderRadius:T.r, flexWrap:"wrap" },
  eventLeft: { display:"flex", flexDirection:"column", gap:3, flex:1, minWidth:0 },
  eventName: { fontSize:14, fontWeight:700, color:T.dark },
  eventMeta: { display:"flex", alignItems:"center", gap:5, fontSize:12, color:T.muted },
  pillRow: { display:"flex", gap:6, alignItems:"center", flexShrink:0 },
  sportPill: { fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:T.rPill, textTransform:"uppercase", letterSpacing:"0.03em" },
  distPill: { fontSize:11, fontWeight:700, padding:"3px 10px", borderRadius:T.rPill, border:"1.5px solid", whiteSpace:"nowrap" },
  forumBtn: { display:"flex", alignItems:"center", gap:4, background:T.grad, color:"#fff", border:"none", borderRadius:T.rPill, padding:"7px 14px", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" },
};
