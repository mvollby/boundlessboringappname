import { useState } from "react";
import { T } from "../theme";
import { Icon } from "../Icons";
import LocationInput from "../components/LocationInput";

const DISCIPLINES = ["Runner", "Cyclist", "Multisport"];
const DISC_META = {
  Runner:     { icon: Icon.Run,  label: "Runner",     desc: "Road, trail, track" },
  Cyclist:    { icon: Icon.Bike, label: "Cyclist",    desc: "Road, MTB, velodrome" },
  Multisport: { icon: Icon.Swim, label: "Multisport", desc: "Tri, duathlon & more" },
};

const COACHES_BY_DISCIPLINE = {
  Runner:     ["James Mitchell", "Sarah O'Connor", "Viktor Petrov", "Ana García"],
  Cyclist:    ["Liam Henderson", "Marie Dubois", "Hans Müller"],
  Multisport: ["David Chen", "Elsa Johansen", "Paolo Rossi"],
};
const EVENTS_BY_DISCIPLINE = {
  Runner:     ["London Marathon 2026", "Oxford Half Marathon", "Parkrun Series Summer", "Cross Country Nationals", "Track & Field Open"],
  Cyclist:    ["Tour of Britain Stage", "Cotswolds Sportive", "Velodrome Cup", "Hill Climb Championship"],
  Multisport: ["Blenheim Triathlon", "Ironman 70.3 Staffordshire", "Aquathlon Series", "Duathlon National Champs", "SwimRun Cotswolds"],
};

export default function ProfileSetup({ user, onComplete }) {
  const [form, setForm] = useState({
    discipline: "", location: "", lat: null, lng: null,
    city: "", state: "", country: "",
    coach: "", events: [], bio: "", gender: "",
  });
  const [step, setStep] = useState(1);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const toggleEvent = (ev) => setForm((f) => {
    if (f.events.includes(ev)) return { ...f, events: f.events.filter((e) => e !== ev) };
    if (f.events.length >= 3) return f;
    return { ...f, events: [...f.events, ev] };
  });

  const handleLocationSelect = (item) => {
    if (!item) {
      setForm((f) => ({ ...f, location: "", lat: null, lng: null, city: "", state: "", country: "" }));
      return;
    }
    setForm((f) => ({
      ...f,
      location: item.shortName || item.label || "",
      lat:      item.lat,
      lng:      item.lng,
      city:     item.city || "",
      state:    item.state || "",
      country:  item.country || "",
    }));
  };

  const handleNext = () => {
    if (!form.discipline) return;
    setStep(2);
  };

  const handleSubmit = () => {
    onComplete({ ...form, email: user.email, name: user.name, userId: user.id });
  };

  const coaches = COACHES_BY_DISCIPLINE[form.discipline] || [];
  const events  = EVENTS_BY_DISCIPLINE[form.discipline]  || [];
  const dc      = T.disc[form.discipline];

  return (
    <div style={S.page}>
      <div style={S.blob1} /><div style={S.blob2} />

      <div style={S.card}>
        {/* Logo */}
        <div style={S.logoRow}>
          <svg viewBox="0 0 32 32" width="26" height="26" fill="none">
            <circle cx="16" cy="16" r="16" fill="url(#lgps)"/>
            <defs><linearGradient id="lgps" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
              <stop stopColor="#7C3AED"/><stop offset="1" stopColor="#EC4899"/>
            </linearGradient></defs>
            <path d="M11 22l2-5 3 2 3-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <circle cx="19" cy="10" r="2" fill="#fff"/>
          </svg>
          <span style={S.logoText}>Boundless</span>
        </div>

        {/* Step progress */}
        <div style={S.progressWrap}>
          {[1, 2].map((n) => (
            <div key={n} style={{ display: "flex", alignItems: "center", gap: 8, flex: n < 2 ? 1 : undefined }}>
              <div style={{ ...S.stepDot, background: step >= n ? T.grad : T.border, color: step >= n ? "#fff" : T.muted }}>
                {step > n ? <Icon.Check style={{ width: 12, height: 12 }} /> : n}
              </div>
              <span style={{ ...S.stepLabel, color: step >= n ? T.dark : T.muted }}>
                {n === 1 ? "Your sport" : "Details"}
              </span>
              {n < 2 && <div style={{ ...S.stepLine, background: step > 1 ? T.primary : T.border }} />}
            </div>
          ))}
        </div>

        {step === 1 && (
          <>
            <h2 style={S.heading}>What's your discipline?</h2>
            <p style={S.sub}>This determines who you'll see in the directory.</p>

            <div style={S.discGrid}>
              {DISCIPLINES.map((d) => {
                const meta = DISC_META[d];
                const active = form.discipline === d;
                const ddc = T.disc[d];
                return (
                  <button key={d} onClick={() => { set("discipline", d); set("coach", ""); set("events", []); }}
                    style={{ ...S.discCard, ...(active ? { ...S.discCardActive, background: ddc.bg, borderColor: ddc.color } : {}) }}>
                    <div style={{ ...S.discIcon, background: active ? ddc.grad : T.bg, color: active ? "#fff" : ddc.color }}>
                      <meta.icon style={{ width: 22, height: 22 }} />
                    </div>
                    <div style={S.discLabel}>{meta.label}</div>
                    <div style={{ ...S.discDesc, color: active ? ddc.color : T.muted }}>{meta.desc}</div>
                  </button>
                );
              })}
            </div>

            <div style={S.fieldGroup}>
              <label style={S.label}>Your location</label>
              <LocationInput
                value={form.location}
                onSelect={handleLocationSelect}
                placeholder="e.g. Boulder, CO or London, UK"
                inputStyle={{ background: T.bg, borderColor: T.border, borderRadius: T.r }}
              />
              {form.lat && <p style={S.geoTag}>Geocoded · {form.lat.toFixed(3)}, {form.lng.toFixed(3)}</p>}
            </div>

            <div style={S.fieldGroup}>
              <label style={S.label}>Gender <span style={S.optional}>optional</span></label>
              <div style={S.chipRow}>
                {["Man","Woman","Non-binary","Prefer not to say"].map((g) => (
                  <button key={g} onClick={() => set("gender", form.gender === g ? "" : g)}
                    style={{ ...S.chip, ...(form.gender === g ? S.chipActive : {}) }}>
                    {form.gender === g && <Icon.Check style={{ width: 10, height: 10 }} />}{g}
                  </button>
                ))}
              </div>
            </div>

            <button style={{ ...S.btnPri, opacity: !form.discipline ? 0.5 : 1 }}
              onClick={handleNext} disabled={!form.discipline}>
              Continue
              <Icon.ChevronRight style={{ width: 16, height: 16 }} />
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <h2 style={S.heading}>A few more details</h2>
            <p style={S.sub}>Help the community get to know you.</p>

            <div style={S.fieldGroup}>
              <label style={S.label}>Coach <span style={S.optional}>optional</span></label>
              <select style={S.select} value={form.coach} onChange={(e) => set("coach", e.target.value)}>
                <option value="">No coach / not listed</option>
                {coaches.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div style={S.fieldGroup}>
              <label style={S.label}>Top races <span style={S.optional}>pick up to 3</span></label>
              <div style={S.chipRow}>
                {events.map((ev) => {
                  const sel = form.events.includes(ev);
                  const dis = !sel && form.events.length >= 3;
                  return (
                    <button key={ev} disabled={dis} onClick={() => toggleEvent(ev)}
                      style={{ ...S.chip, ...(sel ? S.chipActive : dis ? S.chipDis : {}) }}>
                      {sel && <Icon.Check style={{ width: 10, height: 10 }} />}{ev}
                    </button>
                  );
                })}
              </div>
            </div>

            <div style={S.fieldGroup}>
              <label style={S.label}>Bio <span style={S.optional}>optional</span></label>
              <textarea style={S.textarea} placeholder="Tell the community a bit about yourself…"
                value={form.bio} onChange={(e) => set("bio", e.target.value)} />
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
              <button onClick={() => setStep(1)} style={S.btnSec}>← Back</button>
              <button onClick={handleSubmit} style={{ ...S.btnPri, flex: 1 }}>
                Enter Community <Icon.ChevronRight style={{ width: 16, height: 16 }} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

const S = {
  page: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: T.bg, padding: 20, position: "relative", overflow: "hidden", fontFamily: T.fontBase },
  blob1: { position: "absolute", top: -150, right: -100, width: 440, height: 440, borderRadius: "50%", background: "radial-gradient(circle, rgba(124,58,237,0.13) 0%, transparent 70%)", pointerEvents: "none" },
  blob2: { position: "absolute", bottom: -120, left: -80, width: 380, height: 380, borderRadius: "50%", background: "radial-gradient(circle, rgba(236,72,153,0.10) 0%, transparent 70%)", pointerEvents: "none" },
  card: { background: "#fff", borderRadius: T.rXL, padding: "40px 36px", width: "100%", maxWidth: 500, boxShadow: T.shadowLg, position: "relative", zIndex: 1 },
  logoRow: { display: "flex", alignItems: "center", gap: 10, marginBottom: 28 },
  logoText: { fontSize: 20, fontWeight: 800, background: T.grad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  progressWrap: { display: "flex", alignItems: "center", marginBottom: 28 },
  stepDot: { width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 },
  stepLabel: { fontSize: 13, fontWeight: 600, whiteSpace: "nowrap" },
  stepLine: { flex: 1, height: 2, borderRadius: 2, margin: "0 8px" },
  heading: { fontSize: 22, fontWeight: 800, color: T.dark, margin: "0 0 6px" },
  sub: { fontSize: 14, color: T.muted, margin: "0 0 24px" },
  discGrid: { display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 22 },
  discCard: { background: T.bg, border: `2px solid ${T.border}`, borderRadius: T.rL, padding: "16px 10px", cursor: "pointer", textAlign: "center", transition: "border 0.15s" },
  discCardActive: { boxShadow: T.shadow },
  discIcon: { width: 48, height: 48, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 10px", transition: "background 0.15s" },
  discLabel: { fontSize: 13, fontWeight: 700, color: T.dark, marginBottom: 3 },
  discDesc: { fontSize: 11, fontWeight: 500, transition: "color 0.15s" },
  fieldGroup: { display: "flex", flexDirection: "column", gap: 6, marginBottom: 18 },
  label: { fontSize: 13, fontWeight: 700, color: T.dark },
  optional: { fontSize: 11, fontWeight: 500, color: T.muted, marginLeft: 4 },
  select: { padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, background: T.bg, color: T.dark, outline: "none", fontFamily: T.fontBase },
  geoTag: { fontSize: 11, color: T.primary, fontWeight: 600, margin: "4px 0 0" },
  chipRow: { display: "flex", flexWrap: "wrap", gap: 8 },
  chip: { display: "flex", alignItems: "center", gap: 5, padding: "7px 14px", borderRadius: T.rPill, border: `1.5px solid ${T.border}`, background: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", color: T.dark },
  chipActive: { background: "#EDE9FE", borderColor: T.primary, color: T.primary },
  chipDis: { opacity: 0.4, cursor: "not-allowed" },
  textarea: { padding: "11px 14px", borderRadius: T.r, border: `1.5px solid ${T.border}`, fontSize: 14, background: T.bg, color: T.dark, outline: "none", fontFamily: T.fontBase, minHeight: 80, resize: "vertical" },
  btnPri: { width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: T.grad, color: "#fff", border: "none", borderRadius: T.r, padding: "14px", fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 16px rgba(124,58,237,0.3)" },
  btnSec: { background: T.bg, color: T.dark, border: `1.5px solid ${T.border}`, borderRadius: T.r, padding: "14px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
};
