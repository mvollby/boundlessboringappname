import { useState, useEffect } from "react";
import { authStorage, profileStorage, storage, conversationStorage } from "./utils/storage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfileSetup from "./pages/ProfileSetup";
import MainApp from "./pages/MainApp";

// Demo profiles — other athletes visible in the community
const DEMO_PROFILES = [
  { userId: "demo_alice", name: "Alice Turner", discipline: "Runner", gender: "Woman", location: "Oxford, UK", lat: 51.752, lng: -1.2577, bio: "Marathon runner training for London 2026", coach: "Dave Smith", events: ["London Marathon 2026","Oxford Half Marathon","Parkrun Series Summer"], photoUrl: "" },
  { userId: "demo_bob", name: "Bob Chen", discipline: "Cyclist", gender: "Man", location: "Cambridge, UK", lat: 52.2053, lng: 0.1218, bio: "Road cyclist & gravel enthusiast", coach: "", events: ["Tour of Britain Stage","Cotswolds Sportive","UNBOUND Gravel"], photoUrl: "" },
  { userId: "demo_clara", name: "Clara Osei", discipline: "Multisport", gender: "Woman", location: "London, UK", lat: 51.5074, lng: -0.1278, bio: "Triathlete aiming for Ironman 70.3", coach: "Anna Lee", events: ["Blenheim Triathlon","Ironman 70.3 Staffordshire","SwimRun Cotswolds","Leadville Trail 100 Run"], photoUrl: "" },
  { userId: "demo_dan", name: "Dan Morales", discipline: "Runner", gender: "Man", location: "Bristol, UK", lat: 51.4545, lng: -2.5879, bio: "Ultra runner, mountain lover", coach: "", events: ["Leadville Trail 100 Run","Cross Country Nationals","Parkrun Series Summer"], photoUrl: "" },
  { userId: "demo_eva", name: "Eva Novak", discipline: "Cyclist", gender: "Woman", location: "Bath, UK", lat: 51.3811, lng: -2.3590, bio: "Track & road cyclist", coach: "Mark Hall", events: ["Velodrome Cup","Hill Climb Championship","Big Sugar"], photoUrl: "" },
  { userId: "demo_fran", name: "Fran Dupont", discipline: "Multisport", gender: "Non-binary", location: "Brighton, UK", lat: 50.8225, lng: -0.1372, bio: "Duathlon & aquathlon lover", coach: "", events: ["Duathlon National Champs","Aquathlon Series","SPT GRVL"], photoUrl: "" },
];

function seedDemoProfiles() {
  // Seed demo athletes (not the current user) so the community isn't empty
  const existingUsers = authStorage.getUsers();
  const demoIds = DEMO_PROFILES.map(p => p.userId);
  const alreadySeeded = demoIds.every(id => existingUsers.some(u => u.id === id));
  if (alreadySeeded) return;

  const demoUsers = DEMO_PROFILES.map(p => ({
    id: p.userId, name: p.name,
    email: p.name.toLowerCase().replace(/ /g, ".") + "@demo.com",
  }));
  const merged = [...existingUsers.filter(u => !demoIds.includes(u.id)), ...demoUsers];
  authStorage.saveUsers(merged);
  DEMO_PROFILES.forEach(p => profileStorage.set(p.userId, p));
}

export default function App() {
  const [session, setSession] = useState(null);
  const [hasProfile, setHasProfile] = useState(false);
  const [authView, setAuthView] = useState("register");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Seed demo community members on first launch
    seedDemoProfiles();

    const saved = authStorage.getSession();
    if (saved) {
      setSession(saved);
      setHasProfile(!!profileStorage.get(saved.id));
    }
    setReady(true);
  }, []);

  const handleLogin = (user) => {
    setSession(user);
    setHasProfile(!!profileStorage.get(user.id));
  };

  const handleProfileComplete = (profileData) => {
    profileStorage.set(session.id, profileData);
    setHasProfile(true);
  };

  const handleLogout = () => {
    authStorage.clearSession();
    setSession(null);
    setHasProfile(false);
    setAuthView("register");
  };

  if (!ready) return null;

  if (!session) {
    return authView === "login"
      ? <LoginPage onLogin={handleLogin} onGoRegister={() => setAuthView("register")} />
      : <RegisterPage onLogin={handleLogin} onGoLogin={() => setAuthView("login")} />;
  }

  if (!hasProfile) {
    return <ProfileSetup user={session} onComplete={handleProfileComplete} />;
  }

  return <MainApp user={session} onLogout={handleLogout} />;
}
