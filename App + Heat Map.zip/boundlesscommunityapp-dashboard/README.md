# Boundless Community App

A React-based community platform for athletes with events, forums, messaging, athlete directory, and a race heatmap across the USA.

## Requirements

- **Node.js** 18+ (recommended 20+)
- **npm** 9+

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev
```

The app will open at **http://localhost:5173**

## Build for Production

```bash
npm run build
npm run preview
```

## Features

- **Events** — Boundless featured events with forums
- **Heatmap** — Interactive USA map with race locations (Leaflet/OpenStreetMap)
- **Communities** — Find and connect with athletes
- **Messages** — Direct messaging system
- **My Profile** — Profile management

## Tech Stack

- React 18
- Vite 5
- Leaflet (loaded via CDN for heatmap)
- localStorage for data persistence
